#!/bin/sh
killall -9 ezserver
cd /usr/local/bin/ezserver/
./ezserver &

