var xmlHttp = new XMLHttpRequest();
var g_token=0;
var g_item=0;
var g_ch_src;
var g_status_item;
var g_refresh_item;
var g_chtype_item;
var g_ch_play_id_item;
var g_Channel_Edit_Mode=0;
var g_Channel_Updated=0;
var HTML_Menu_Bar_Str;
var g_content;
var g_blacklist_remove_item;
var total_player_no=1000;
var g_macid;
var g_user_id;
var g_password;
var g_ch_no;
var g_video_itemid= Array();
var g_file_path;
var vlc_monitorTimerId = 0; 
var prevState = 0; 
var g_channel_no=1;
var g_remove_all_button;
var g_username;
var g_groupname_array = new Array();
var g_paymodel_array = Array("pre","post","free");
var g_total_group_no=0;
var g_timer;
var g_current_timestamp;
var g_dvr_timestamp=0;
var bdvr_on;
var g_video_path;
var g_server_dvr_sec;
var g_cur_sec;
var g_dvr_sec;
var g_delaytime_array = Array("Delay 5 sec.","Delay 10 sec.","Delay 20 sec.","Delay 30 sec.","Delay 40 sec.","Delay 50 sec.",
				"Delay 1 min.","Delay 3 min.","Delay 5 min.","Delay 10 min.","Delay 20 min.","Delay 30 min.","Delay 40 min.","Delay 50 min.",
				"Delay 1 hr.","Delay 2 hr.","Delay 3 hr.","Delay 4 hr.","Delay 5 hr.","Delay 6 hr.","Delay 7 hr.","Delay 8 hr.","Delay 9 hr.","Delay 10 hr.","Delay 11 hr.","Delay 12 hr.")
var g_delayvalue_array = Array("delay,5,sec.","delay,10,sec.","delay,20,sec.","delay,30,sec.","delay,40,sec.","delay,50,sec.",
				 "delay,1,min.","delay,3,min.","delay,5,min.","delay,10,min.","delay,20,min.","delay,30,min.","delay,40,min.","delay,50,min.",
				"delay,1,hr.","delay,2,hr.","delay,3,hr.","delay,4,hr.","delay,5,hr.","delay,6,hr.","delay,7,hr.","delay,8,hr.","delay,9,hr.","delay,10,hr.","delay,11,hr.","delay,12,hr.")
var g_server_timer;
var g_user_authorization_mode=1;
var g_httpport;
var g_System_timer=0;
var bSystem_Inquery_Panel=0;

var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "an unknown version";
		this.OS = this.searchString(this.dataOS) || "an unknown OS";
	},
	searchString: function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	},
	dataBrowser: [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{ 	string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera",
			versionSearch: "Version"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{		// for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "Explorer",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{ 		// for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
	],
	dataOS : [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			   string: navigator.userAgent,
			   subString: "iPhone",
			   identity: "iPhone/iPod"
	    },
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
	]


};
function change_link(new_url, new_width, new_height)
{
   var content= document.getElementById("content");
	if ((new_width>0) && (new_height>0))
	{
		content.innerHTML='<iframe frameborder="0" width='+new_width+' height='+new_height+' src="'+new_url+'"></iframe>';	
	} else
	{
		content.innerHTML='<iframe frameborder="0"'+new_url+'"></iframe>';	
	}
	

 
}


function find_cookie_value(keystr)
{ 
	var restring;
	var str;
	var substr1;
	var pos1, pos2;
	
	str=document.cookie;
	//alert(str);
	//alert(keystr);
	pos1=str.indexOf(keystr);
	//alert(pos1);
	subchar=str.substring(pos1+keystr.length,pos1+keystr.length+1);
	//alert(subchar);
	if (subchar==';')
	{
		return 0;
	}else
	{
		substr1=str.substring(pos1+keystr.length+2,str.length);
		//alert(substr1);
		pos1=substr1.indexOf(']');
		restring=substr1.substring(0,pos1);
		//alert(restring);
		return restring;
	}
	
	
}
function add_cookie_value(keystr,keyvalue)
{
	document.cookie=keystr+'=['+keyvalue+']';
}
function Clear_cookie()
{
	document.cookie='token'+'=';
	document.cookie='userid'+'=';
	document.cookie='password'+'=';
	document.cookie='dir_path'+'=';
	document.cookie='video_path'+'=';

}

function encode64(input) {  

 var keyStr = "ABCDEFGHIJKLMNOP" +  

              "QRSTUVWXYZabcdef" +  

              "ghijklmnopqrstuv" +  

              "wxyz0123456789+/" +  

              "=";  
  // input = escape(input);  

    var output = "";  

    var chr1, chr2, chr3 = "";  

    var enc1, enc2, enc3, enc4 = "";  

    var i = 0; 
  
 
    do {  

       chr1 = input.charCodeAt(i++);  

       chr2 = input.charCodeAt(i++);  

       chr3 = input.charCodeAt(i++);  

  

       enc1 = chr1 >> 2;  

       enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);  

       enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);  

       enc4 = chr3 & 63;  

  

    /*   if (isNaN(chr2)) {  

          enc3 = enc4 = 64;  

       } else if (isNaN(chr3)) {  

          enc4 = 64;  

       }  
*/
  

       output = output +  

          keyStr.charAt(enc1) +  

          keyStr.charAt(enc2) +  

          keyStr.charAt(enc3) +  

          keyStr.charAt(enc4);  
  
       chr1 = chr2 = chr3 = "";  

       enc1 = enc2 = enc3 = enc4 = "";  

    } while (i < input.length);  

  

    return output;  

}  

function Init_System_Setting()
{
  if (xmlHttp.readyState == 4) {
    var response= xmlHttp.responseText.split("\r\n");

     document.getElementById("http_base_port").value =response[0];
     document.getElementById("http_apps_port").value =response[1];
    document.getElementById("httpport").value =response[2];
    g_httpport=response[2];
    document.getElementById("rtsp_base_port").value =response[3];
   document.getElementById("igmpip").value =response[4];
    document.getElementById("igmpport").value =response[5];
     document.getElementById("rtmpport").value =response[6];
 //   call_user_authorization_mode();

  //   show_uptime();
 
 	//g_server_timer=setInterval(function(){show_uptime()},300*1000);
 
  }
}
function callServer_Setting()
{
	
//	  var url = "/cgi-bin/cgi_ezserver?token="+escape(g_token)+"&value_creation"+"&flag="+Math.random();
	  var url = "/server/get_config?token="+escape(g_token)+"&flag="+Math.random();
var str;
  var streaming_port = parent.document.getElementById("content");
bSystem_Inquery_Panel=0;
	str='<p align="left" style="margin-top: 35; margin-left: 25"><table border="0" cellpadding="0" cellspacing="5" border>'+
		'<tr><td colspan="2">'+
		'<p align="left"><font face="Arial" size="2" color="#ff0000">Protocol Port No.</font>'+
		'</td></tr>'+
		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">1. Panel port:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="80" height="23"><p align="center"> <font face="Arial"> <font size="3"> <input type="text" name="http_base_port" id="http_base_port" size="5"/></font>'+
		'</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">2. Apps port:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="80" height="23"><p align="center"> <font face="Arial"> <font size="2"> <input type="text" name="http_apps_port" id="http_apps_port" size="5"/></font>'+
		'</font>'+ 
		'</td>'+
		'</tr>'+
				
		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">3. HTTP port:</font></p>'+
		'</td>'+
		'<td width="80" height="23"><p align="center"> <font size="2"> <input type="text" name="httpport" id="httpport" size="5"/></font>'+
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">4. RTMP port:</font></p>'+
		'</td>'+
		'<td width="80" height="23"><p align="center"> <font size="2"> <input type="text" name="rtmpport" id="rtmpport" size="5"/></font>'+
		'</td>'+
		'</tr>'+




		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">5. RTSP port:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="80" height="23"><p align="center"> <font face="Arial"> <font size="2"> <input type="text" name="rtsp_base_port" id="rtsp_base_port" size="5"/></font>'+
		'</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">6. Multicast IP :</font>'+
		'</p>'+
		'</td>'+      
		'<td width="80" height="23"><p align="center" style="margin-left: 10"> <font face="Arial"> <font size="2"> <input type="text" name="igmpip" id="igmpip" size="16"/></font>'+
		'</font>'+ 
		'</td>'+
		'</tr>'+
		
		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">7. Multicast port:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="80" height="23"><p align="center"> <font face="Arial"> <font size="2"> <input type="text" name="igmpport" id="igmpport" size="5"/></font>'+
		'</font>'+ 
		'</td>'+
		'</tr>'+
		
		'<tr>'+
		'<td height="23">'+
		'</td>'+  
		'<td height="23">'+
		'<p align="left" style="margin-left: 13"><font face="Arial"><input type="button" value="Save" onclick="javascript:save_setting();" name="B1" />'+
		'</font>'+
		'</td>'+  
		'</tr>'+
		'</table>';
		streaming_port.innerHTML=str;

	   	g_token=find_cookie_value("token");
		if (g_token!=0)
		{
			 xmlHttp.open("GET", url, true);
			 xmlHttp.onreadystatechange = Init_System_Setting;
			 xmlHttp.send(null);
		}
	

}

function Init_Config()
{
  if (xmlHttp.readyState == 4) {
    var response= xmlHttp.responseText.split("\r\n");
    g_httpport=response[2];
    call_user_authorization_mode();
 
  }
}
function callServer_Init()
{	
	var url = "/server/get_config?token="+escape(g_token)+"&flag="+Math.random();
	
	g_token=find_cookie_value("token");
	if (g_token!=0)
	{
		 xmlHttp.open("GET", url, true);
		 xmlHttp.onreadystatechange = Init_Config;
		 xmlHttp.send(null);
	}
}

function login_return() {
  var login_msg = document.getElementById("login_msg");
  var login_area = document.getElementById("login_area");
  var login_status = parent.document.getElementById("login_status");
  var browser_name;
   	var content = parent.document.getElementById("content");

//  alert(login_status.innerHTML);
  
  // alert(id_check_flag);
  
  if (xmlHttp.readyState == 4) 
  {
    var response = xmlHttp.responseText;
   //alert(response);
  if (response.search("-1")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Arial"> <font size="2">*** parameter error***</font>';
    } else if (response.search("-2")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Arial"> <font size="2">*** Wrong User ID or Password***</font>';
    } else if (response.search("-3")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Arial"> <font size="2">*** User ID Time Expired***</font>';
    } 
    else
    {
  	g_token=response.slice(6,response.length-2);
  	//alert(g_token);
  	//  document.cookie="token="+ g_token+"userid="+g_user_id+"password="+g_password+"#";
   	add_cookie_value("token",g_token);
  	add_cookie_value("userid",g_user_id);
  	add_cookie_value("password",g_password);
  	
 	    id_check_flag=1;

   	  login_status.innerHTML="<a href='javascript:void(0)' onclick=logout()>"+
  	  '<font face="Arial" size="2">Logout</font></a>'; 
  	   callServer_Init();
  	  /*          content.innerHTML='<table border="1" cellpadding="0" cellspacing="0" width="100%" height="451"><tr>'+
              '<td width="100%" height="449"><p align="center"><font face="Arial" size="5">Welcome to EZserver Management</font></td>'+
              '</tr></table>';
 */
//  	   init_video();
 //  	   callServer_CH_Inquery();
  	/*  BrowserDetect.init();
  	  browser_name=BrowserDetect.browser;
 	if (browser_name.search("Explorer")==0)
	{
  	  change_link("ovs.htm",900,400);
  	} else 	if (browser_name.search("Safari")==0)
  	{
  	  change_link("ovs_html5.htm",900,400);
   	} else
  	{
  	  change_link("ovs_html5.htm",900,400);
  	} */

    }
  }

}

function login(){
 var cgi_url;
 var encrypt_str;
 var userid_pass;
 g_user_id = document.getElementById("user_id").value;
 g_password = document.getElementById("password").value;
 userid_pass=g_user_id+':'+g_password;

	// alert(userid_pass);
	 encrypt_str=encode64(userid_pass);
	cgi_url = "/token/createtokenbased64?encrpty="+escape(encrypt_str)+"&flag="+Math.random();
	 login_status.innerHTML='login...';
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = login_return;
	 xmlHttp.send(null);
}

function login_out_return() {
  
var ch_up_flag=0;
  
  if (xmlHttp.readyState == 4) 
  {
    var response = xmlHttp.responseText;
	//var content = parent.document.getElementById("content");
	//var detail = parent.document.getElementById("detail");

 /*        ch_up_flag=find_cookie_value("ch_up_flag");       
         if (ch_up_flag==1)
         {
         	callezserver_refresh_channel();
         	Clear_Channel_update();
         }*/
      /*   content.innerHTML='<table border="1" cellpadding="0" cellspacing="0" width="100%" height="451"><tr>'+
              '<td width="100%" height="449"><p align="center"><font face="Arial" size="5">EZserver Management</font></td>'+
              '</tr></table>';
         detail.innerHTML='';
*/
    	g_token=0;	
    	if (g_System_timer>0)
    	{
    		clearInterval(g_System_timer);
    	}
 	Clear_cookie();
     login_status.innerHTML="";
//     menu_main_title.innerHTML="";
	init();
 
   }

}
function logout()
{
	var cgi_url;
  var login_status = document.getElementById("login_status");
   var confirm_msg="Logout?";
  var cookieStr;
  var firstpos;
  var endpos;
 	var content = parent.document.getElementById("content");

	 if (confirm(confirm_msg))
	{
  
          // content.innerHTML='<p align="center" style="margin-top: 30"><font face="Arial" size="5">EZserver Management</font>';
	content.innerHTML='';
     	g_token=find_cookie_value("token");
  	g_user_id=find_cookie_value("userid");
  	g_password=find_cookie_value("password");
 	 cgi_url = "/token/destroytoken?token="+escape(g_token)+"&flag="+Math.random();
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = login_out_return;
	 xmlHttp.send(null);

	}
}

function init() {

       menu_top.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0">'+
	   '<tr><td>'+
	   '<p style="text-indent: 5"><font face="Arial" size="2">User ID: </font></p>'+
	   '</td>'+      
	   '<td>'+ 
	   '<font face="Arial"> <font size="2"> <input type="text" name="user_id" id="user_id" size="20" value="reseller"/></font></font>'+
	   '</td>'+
	   
	   
	   '<td>'+
	   '<p style="text-indent: 5"><font face="Arial" size="2">Password: </font></p>'+    
	   '</td>'+ 
	                                   
	   '<td> <font face="Arial" size="2"> <input type="password" name="password" id="password" size="20"/></font><font face="Arial"><font size="2"></font>'+
	   '<input type="button" value="OK" onclick="javascript:login();" name="B1" /></font>'+
	   '</td></tr>'+
	   '</table>';
	   Clear_cookie();
	 //  streaming_port();

}





function callServer_group_Inquery() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");

 cgi_url = "/server/group_query?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Group Information Loading...<p>';


 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = group_inquery;
 xmlHttp.send(null);

}




function Cancel_Add_User()
{
	call_get_all_user();

}

function Add_User_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    //	alert("Add User Sucessfully");
    } else if (response==0)
    {
   	alert("Failed to Add User");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    }else if (response==3)
    {
    	alert("The user is already in Database");
    }

	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	call_get_all_user();
    }
}

function call_Add_User(user_no)
{

 var username_id="username"+user_no; 
 var password_id="password"+user_no; 
 var group_id="group"+user_no; 
 var expired_time_id="expired_time"+user_no; 
// var paymodel_id="paymodel"+user_no; 
// var user_point_id="user_point"+user_no;
 var userip_id="userip"+user_no;
 var macid_id="macid"+user_no;
 var szpassword;
 var szgroup;
 var expired_time;
 var expired_YY;
 var expired_MM;
 var expired_DD;
 //var paymodel;
 //var user_point;
 var userip;
 var macid;
 var username;
 var d=new Date();
 var cur_year=d.getFullYear();
 var cur_month=d.getMonth()+1;
 var cur_date=d.getDate();



var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var pos;
	var expired_time_temp;
 	var pos;
	var expired_time_temp;
	var alert_message;


	g_item=document.getElementById(username_id);
	username=g_item.value;
	if (username.length==0)
	{
		alert("User name is empty");
		return;
	}
	g_item=document.getElementById(expired_time_id);
	expired_time=g_item.value;
	if (expired_time.length==0)
	{
		alert("Expired Time is empty");
		return;
	}else if (expired_time.length>10)
	{
		alert("Date Length is too long(>10)");
		return;
	}
	if (g_user_authorization_mode==1)
	{
		g_item=document.getElementById(password_id);
		szpassword=g_item.value;
		if (szpassword.length==0)
		{
			alert("Pawword is empty");
			return;
		}
		pos=expired_time.indexOf('/');
		expired_MM=expired_time.substring(0,pos);
		expired_time_temp=expired_time.substring(pos+1);
		pos=expired_time_temp.indexOf('/');	
		expired_DD=expired_time_temp.substring(0,pos);
		expired_YY=expired_time_temp.substring(pos+1);
		if (expired_YY<cur_year)
		{
			alert_message="Expired Year should be >="+cur_year;
			alert(alert_message);
			return;
		}
		if ((expired_MM<1)||(expired_MM>12))
		{
			alert("Exipred Month should be between 1 and 12");
			return;
		}
		if ((expired_YY==cur_year)&&(expired_MM<cur_month))
		{
			alert_message="Expired Month should be >"+cur_month;
			alert(alert_message);
			return;
			
		}
		if ((expired_DD<1)||(expired_DD>31))
		{
			alert("Exipred Date should be between 1 and 30");
			return;
		}
		if ((expired_YY==cur_year)&&(expired_MM==cur_month)&&(expired_DD<cur_date))
		{
			alert_message="Expired Date should be >"+cur_date;
			alert(alert_message);
			return;
		}
	}else if (g_user_authorization_mode==2)
	{
		szpassword=null;
	}

	
	g_item=document.getElementById(group_id);
	szgroup=g_item.value;
//	g_item=document.getElementById(paymodel_id);
//	paymodel=g_item.value;
//	g_item=document.getElementById(user_point_id);
//	user_point=g_item.value;
	g_item=document.getElementById(userip_id);
	userip=g_item.value;
	g_item=document.getElementById(macid_id);
	macid=g_item.value;


   	g_token=find_cookie_value("token");

 confirm_msg="Add User: "+username+" Information?";
 cgi_url = "/server/reseller_add_user?token="+escape(g_token)+"&username="+escape(username)+
  "&password="+szpassword+
  "&group="+szgroup+
  "&expired_time="+expired_time+
 // "&paymodel="+paymodel+
 // "&user_point="+user_point+
  "&userip="+userip+
  "&macid="+macid+
   "&flag="+Math.random();
 //  alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_User_Info;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (Adding...)";
	g_item.style.backgroundColor = "#ff0000";
 }


}
function call_Add_New_User() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
    	g_token=find_cookie_value("token");

 cgi_url = "/server/group_query?token="+escape(g_token)+"&flag="+Math.random();

 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = group_inquery_item_for_add;
 xmlHttp.send(null);

}

function call_Add_New_User_detail()
{

var HTML_str;
var user_no;
var len;
var paymodel;
var str;
  var content = parent.document.getElementById("content");
	

	g_user_no++;

	HTML_str=content.innerHTML;
	//alert(HTML_str);
	//len=HTML_str.length-16;
	len=HTML_str.lastIndexOf("<TABLE");
	
	if (len==-1)
	{
		len=HTML_str.lastIndexOf("<table");
	}
		
		//HTML_str=HTML_str.slice(800,len);
		//alert(HTML_str);
//	alert(len);
	//len+=6;
	HTML_str=HTML_str.slice(0,len);

	user_no=g_user_no;
//	alert(HTML_str);
	HTML_str=HTML_str+'<tr><td><table><tr>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">'+user_no+'</font></td>';
			if (g_user_authorization_mode==1)
 			{
			     HTML_str+='<td width="10%" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="username"'+
		 		' id=username'+user_no+' size="12"/></font></td>'+
	 		      '<td width="15%" align="center">'+
		 		'<font face="Arial" size="2">'+
		 		'<input type="text" name="password"'+
		 		'id=password'+user_no+' size="12"/></font></td>';
	 		}else if (g_user_authorization_mode==2)
 			{
			     HTML_str+='<td width="20%" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="username"'+
		 		' id=username'+user_no+' size="36"/></font></td>';
 			}
	 			

		      HTML_str+='<td width="15%" align="center">'+
	 		'<font face="Arial" size="2">'+
			'<select size="1" name="group" id=group'+user_no+'>';
			
	 		for (j=0;j<g_total_group_no;j++)
	 		{
	 			groupname=g_groupname_array[j];
 				HTML_str+='<option value="'+groupname+'">'+groupname+'</option>';
	 		}
	  		HTML_str+='</select></font></td>';
	  		
	  		HTML_str=HTML_str+'<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1">'+
 			'<option value="-1">--</option>'+
			'<option value="enigma">Enigma</option>'+
			'<option value="enigma16">Enigma 1.6</option>'+
			'<option value="enigma(RTMP)">Enigma(RTMP)</option>'+
			'<option value="enigma16(RTMP)">Enigma 1.6(RTMP)</option>'+
			'<option value="m3u_no">m3u(by chno)</option>'+
 			'<option value="m3u_name">m3u(by chname)</option>'+
 			'<option value="m3ue_no">m3u(by chno with suffix)</option>'+
 			'<option value="m3ue_name">m3u(by chname with suffix)</option>'+
			'<option value="octagon">octagon</option>'+
			'<option value="ariva">ariva</option>'+
 			'<option value="xbmc">XBMC</option>'+
 			'<option value="pure">Pure</option>'+
			'<option value="optumuss">Optumuss</option>'+
			'<option value="amiko">Amiko</option>'+
			'<option value="spark">Spark</option>'+
			'<option value="tiger">Tiger</option>'+
			'<option value="nstreamvod">nStreamVOD</option>'+
			'<option value="script_enigma">*Enigma Script*</option>'+
			'<option value="script_enigma16">*Enigma16 Script*</option>'+
			'<option value="script_mac_address">*MAC Address Script*</option>';
	  		HTML_str+='</select></font></td>';
	 		 		
		      HTML_str+='<td width="18%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="expired_time"'+
	 		' id=expired_time'+user_no+' size="12"/></font></td>'; 		

		      HTML_str+='<td width="18%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="userip"'+
	 		' id=userip'+user_no+' size="12"/></font></td>';

		      HTML_str+='<td width="18%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="macid"'+
	 		' id=macid'+user_no+' size="12"/></font></td>';
	 		
		      /* '<td width="15%" align="center">'+
	 		' <font face="Arial" size="2">'+
			' <select size="1" name="paymodel" id=paymodel'+user_no+'>';
			
	 		 for (j=0;j<3;j++)
	 		{
	 			paymodel=g_paymodel_array[j];
 				str+='<option value="'+paymodel+'">'+paymodel+'</option>';
	 		}
	  		HTML_str=HTML_str+str+'</select></font></td>';
	  		
	 		
		      HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="user_point"'+
	 		' id=user_point'+user_no+' size="12"/></font></td>'+
	 		*/
	 			 		
		       HTML_str+='<td id=add_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_User("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>'+
	      	      
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=Cancel_Add_User()>'+
	      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

		    '</tr></table></td></tr>';
	//alert(HTML_str);

	       content.innerHTML=HTML_str+'</table>';
  //      alert(user_list_info.innerHTML);
   
		
}
function Del_User_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Delete User Sucessfully");
    } else if (response==2)
    {
     	alert("Disk is error(FULL), Please contact administrator");  	
    } else if (response==0)
    {
   	alert("Failed to Delete User");
    }
    	call_get_all_user();
    }
}

//nction call_Del_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Del_User(user_no)
{
 var username_id="username"+user_no; 
 var username;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(username_id);
	username=g_item.value;
	
   	g_token=find_cookie_value("token");

 confirm_msg="Delete User: "+username+" Information?";
// cgi_url = "/server/del_user?token="+escape(g_token)+"&user_no="+escape(user_no)+"&username="+escape(username)+"&flag="+Math.random();
 cgi_url = "/server/del_user?token="+escape(g_token)+"&username="+escape(username)+"&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_User_Info;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}

function Save_User_More() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Save User More Sucessfully");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    } else if (response==0)
    {
   	alert("Failed to Save User More");
    }
   // call_get_all_user();
  }
}

function callServer_Save_More(user_no,username)
{

   var rating_password_id="rating_password";
   var paymodel_id="paymodel";
   var user_point_id="user_point";
   var smart_phone_id="smart_phone";
   var tablet_id="tablet";
   var desktop_id="desktop";
   var tv_id="tv";
   var first_name_id="first_name";
   var last_name_id="last_name";
   var address_id="address";
   var city_id="city";
   var zip_id="zip";
   var tel_id="tel";
   var email_id="email";
   
   var rating_password;
   var paymodel;
   var user_point;
  var smart_phone;
   var tablet;
   var desktop;
   var tv;
   var first_name;
   var last_name;
   var address;
   var city;
   var zip;
   var tel;
   var email;
 

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 

	g_item=document.getElementById(rating_password_id);
	rating_password=g_item.value;

	g_item=document.getElementById(paymodel_id);
	paymodel=g_item.value;

	g_item=document.getElementById(user_point_id);
	user_point=g_item.value;

	g_item=document.getElementById(smart_phone_id);
//	alert(g_item);
	smart_phone=g_item.value;
	
	g_item=document.getElementById(tablet_id);
	tablet=g_item.value;
	g_item=document.getElementById(desktop_id);
	desktop=g_item.value;
	g_item=document.getElementById(tv_id);
	tv=g_item.value;
	g_item=document.getElementById(first_name_id);
	first_name=g_item.value;
	g_item=document.getElementById(last_name_id);
	last_name=g_item.value;
	g_item=document.getElementById(address_id);
	address=g_item.value;
	g_item=document.getElementById(city_id);
	city=g_item.value;
	g_item=document.getElementById(zip_id);
	zip=g_item.value;
	g_item=document.getElementById(tel_id);
	tel=g_item.value;
	g_item=document.getElementById(email_id);
	email=g_item.value;

   	g_token=find_cookie_value("token");

 confirm_msg="Save User: "+username+" Information?";
// cgi_url = "/server/save_user_more?token="+escape(g_token)+"&user_no="+escape(user_no)+"&username="+escape(username)+
 cgi_url = "/server/save_user_more?token="+escape(g_token)+"&username="+escape(username)+
  "&rating_password="+rating_password+
  "&paymodel="+paymodel+
  "&user_point="+user_point+
  "&smart_phone="+smart_phone+
  "&tablet="+tablet+
  "&desktop="+desktop+
  "&tv="+tv+
  "&first_name="+first_name+
  "&last_name="+last_name+
  "&address="+address+
  "&city="+city+
  "&zip="+zip+
  "&tel="+tel+
  "&email="+email+
   "&flag="+Math.random();
 //  alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Save_User_More;
	 xmlHttp.send(null);

 }


}
function Query_User_More() {
   var str;
   var i;
   var username;
   var rating_password;
   var paymodel;
   var paymodel_option;
   var user_point;
   
   var smart_phone;
   var tablet;
   var desktop;
   var tv;
   var first_name;
   var last_name;
   var address;
   var city;
   var zip;
   var tel;
   var email;
   var UserDetailWindow
   // var detail = parent.document.getElementById("detail");
	

	// detail.innerHTML="";

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText.split("\r\n");
     str="<head><title>EZserver Subscriber</title><link rel='stylesheet' type='text/css' href='menu.css'/>"+'<script src="menu.js"></script></head><body><table align="center">';
  //   str='';
 //		alert(response[0]);
 		i=0;
	 	strlength=response[i].length;
   	    	username=response[i].slice(9,strlength);
   	    	
  	    	i++;
    	 	strlength=response[i].length;
   	    	rating_password=response[i].slice(16,strlength);

   	    	i++;
    	 	strlength=response[i].length;
   	    	paymodel=response[i].slice(9,strlength);
   	    	
   	    	i++;
	 	strlength=response[i].length;
   	    	user_point=response[i].slice(11,strlength);
 	    	
   	    	i++;
	 	strlength=response[i].length;
   	    	smart_phone=response[i].slice(12,strlength);
   	    	
   	    	i++;
     	 	strlength=response[i].length;
   	    	tablet=response[i].slice(7,strlength);
   	    	
   	    	i++;
     	 	strlength=response[i].length;
   	    	desktop=response[i].slice(8,strlength);
   	    	
   	    	i++;
     	 	strlength=response[i].length;
   	    	tv=response[i].slice(3,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	first_name=response[i].slice(11,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	last_name=response[i].slice(10,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	address=response[i].slice(8,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	city=response[i].slice(5,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	zip=response[i].slice(4,strlength);
   	    	 	    	
   	    	i++;
   	 	strlength=response[i].length;
   	    	tel=response[i].slice(4,strlength);
   	    	
   	    	i++;
   	 	strlength=response[i].length;
   	    	email=response[i].slice(6,strlength);
 
 		str+='<tr><td><font face="Arial"> <font size="2">User: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		username+
 		'</font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">Rating Password: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="rating_password"'+
 		' id="rating_password"'+
 		' size="16" value="'+
 		rating_password+
 		'"/></font></td></tr>';
 		
  		
 		 str+='<tr><td><font face="Arial"> <font size="2">Pay Model: </font></td><td width="350" height="23">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="paymodel" id="paymodel">';
	 		for (j=0;j<3;j++)
	 		{
	 			paymodel_option=g_paymodel_array[j];
	 			if (paymodel.search(paymodel_option)==-1)
	 			{
	 				str+='<option value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}
	 			else
	 			{
	 				str+='<option selected="selected" value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}	 			
	 		}
 		str+='</select></font></td></tr>';

		str+='<tr><td><font face="Arial"> <font size="2">User Point.: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="user_point"'+
 		' id="user_point"'+
 		' size="16" value="'+
 		user_point+
 		'"/></font></td></tr>';

 		str+='<tr><td><font face="Arial"> <font size="2">Smart Phone No.: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="smart_phone"'+
 		' id="smart_phone"'+
 		' size="16" value="'+
 		smart_phone+
 		'"/></font></td></tr>';

 		str+='<tr><td><font face="Arial"> <font size="2">Tablet ID: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="tablet"'+
 		' id="tablet"'+
 		' size="16" value="'+
 		tablet+
 		'"/></font></td></tr>';

		str+='<tr><td><font face="Arial"> <font size="2">Desktop ID: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="desktop"'+
 		' id="desktop"'+
 		' size="16" value="'+
 		desktop+
 		'"/></font></td></tr>';

 		str+='<tr><td><font face="Arial"> <font size="2">TV ID: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="tv"'+
 		' id="tv"'+
 		' size="16" value="'+
 		tv+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">First Name: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="first_name"'+
 		' id="first_name"'+
 		' size="16" value="'+
 		first_name+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">Last Name: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="last_name"'+
 		' id="last_name"'+
 		' size="16" value="'+
 		last_name+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">Adress: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="address"'+
 		' id="address"'+
 		' size="50" value="'+
 		address+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">City: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="city"'+
 		' id="city"'+
 		' size="16" value="'+
 		city+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">ZIP: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="zip"'+
 		' id="zip"'+
 		' size="16" value="'+
 		zip+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">Tel: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="tel"'+
 		' id="tel"'+
 		' size="16" value="'+
 		tel+
 		'"/></font></td></tr>';
  
  		str+='<tr><td><font face="Arial"> <font size="2">Email: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="email"'+
 		' id="email"'+
 		' size="30" value="'+
 		email+
 		'"/></font></td></tr>';
 		
//    str+='<tr><td><input type="button" value="Cancel" onclick=call_get_all_user() name="B1" />';  
    str+='<tr><td><input type="button" value="Save" onclick=callServer_Save_More("'+g_user_no+'"'+','+'"'+g_username+'") name="B2" /></td></tr></table></body>';  
   /*  detail.innerHTML='<table align="center"><tr><td>'+
  	'<p align="center" style="margin-top: 10"><font face="Arial"> <font size="2"> User Name: '+
  	'<font face="Arial"> <font size="2">'+username+'</font></td></tr></table>'+str;
  */
 /* str+='<table align="center"><tr><td>'+
  	'<font face="Arial"> <font size="2"> User Name: '+
  	'<font face="Arial"> <font size="2">'+username+'</font></td></tr>'+str+'</table>';
        alert(str);
        */
       	 UserDetailWindow= window.open("", "", "top=100, left=100, width=600, height=500"); 
	UserDetailWindow.document.write(str); 

  }
}

function call_Query_User_More(user_no)
{
 var username_id="username"+user_no; 
 var username;

var confirm_msg;
 	var cgi_url;
	var cookieStr;

 

	g_item=document.getElementById(username_id);
	username=g_item.value;
	g_username=username;
	g_user_no=user_no;
	
   	g_token=find_cookie_value("token");

// confirm_msg="Get User: "+username+" more Information?";
 cgi_url = "/server/query_user_more?token="+escape(g_token)+"&username="+escape(username)+"&flag="+Math.random();
  // alert(cgi_url);
// if (confirm(confirm_msg))
// {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Query_User_More;
	 xmlHttp.send(null);
 //}
 

}
function Update_User_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Update User Sucessfully");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    } else if (response==0)
    {
   	alert("Failed to Update User");
    }else if (response==3)
    {
   	alert("Primay Key can not be changed");
	call_get_all_user();
    }
	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
    }
}

//function call_Update_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Update_User(user_no)
{
 var username_id="username"+user_no; 
 var password_id="password"+user_no; 
 var group_id="group"+user_no; 
 var expired_time_id="expired_time"+user_no; 
 //var paymodel_id="paymodel"+user_no; 
 //var user_point_id="user_point"+user_no;
 var userip_id="userip"+user_no;
 var macid_id="macid"+user_no;

 var szpassword;
 var szgroup;
 var expired_time;
 //var paymodel;
 //var user_point;
 var username;
 var userip;
 var macid;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 var d=new Date();
 var cur_year=d.getFullYear();
 var cur_month=d.getMonth()+1;
 var cur_date=d.getDate();
 var alert_message;
 
	g_item=document.getElementById(username_id);
	username=g_item.value;
	if (username.length==0)
	{
		alert("User name is empty");
		return;
	}	
	g_item=document.getElementById(expired_time_id);
	expired_time=g_item.value;
	if (expired_time.length==0)
	{
		alert("Expired Time is empty");
		return;
	}else if (expired_time.length>10)
	{
		alert("Date Length is too long(>10)");
		return;
	}
	
	if (g_user_authorization_mode==1)
	 {
		g_item=document.getElementById(password_id);
		szpassword=g_item.value;
		if (szpassword.length==0)
		{
			alert("Pawword is empty");
			return;
		}
		pos=expired_time.indexOf('/');
		expired_MM=expired_time.substring(0,pos);
		expired_time_temp=expired_time.substring(pos+1);
		pos=expired_time_temp.indexOf('/');	
		expired_DD=expired_time_temp.substring(0,pos);
		expired_YY=expired_time_temp.substring(pos+1);
		
			//	alert_message=cur_year+'/'+cur_month+'/'+cur_date+'--'+expired_YY+'/'+expired_MM+'/'+expired_DD;
	   	    	//alert(alert_message);
	
		if (expired_YY<cur_year)
		{
			alert_message="Expired Year should be >="+cur_year;
			alert(alert_message);
			return;
		}
		if ((expired_MM<1)||(expired_MM>12))
		{
			alert("Exipred Month should be between 1 and 12");
			return;
		}
		if ((expired_YY==cur_year)&&(expired_MM<cur_month))
		{
			alert_message="Expired Month should be >"+cur_month;
			alert(alert_message);
			return;
			
		}
		if ((expired_DD<1)||(expired_DD>31))
		{
			alert("Exipred Date should be between 1 and 30");
			return;
		}
		if ((expired_YY==cur_year)&&(expired_MM==cur_month)&&(expired_DD<cur_date))
		{
			alert_message="Expired Date should be >"+cur_date;
			alert(alert_message);
			return;
		}		
		
	}else if (g_user_authorization_mode==2)
	{
		szpassword=null;
	}
		


	
	g_item=document.getElementById(group_id);
	szgroup=g_item.value;
//	g_item=document.getElementById(paymodel_id);
//	paymodel=g_item.value;
//	g_item=document.getElementById(user_point_id);
//	user_point=g_item.value;
	g_item=document.getElementById(userip_id);
	userip=g_item.value;
	g_item=document.getElementById(macid_id);
	macid=g_item.value;
	
   	g_token=find_cookie_value("token");

 confirm_msg="Update User: "+username+" Information?";
// cgi_url = "/server/update_user?token="+escape(g_token)+"&user_no="+escape(user_no)+"&username="+escape(username)+
 cgi_url = "/server/update_user?token="+escape(g_token)+"&username="+escape(username)+
  "&password="+szpassword+
  "&group="+szgroup+
  "&expired_time="+expired_time+
//  "&paymodel="+paymodel+
//  "&user_point="+user_point+
  "&userip="+userip+
  "&macid="+macid+
   "&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Update_User_Info;
	 xmlHttp.send(null);
	 g_item=document.getElementById(expired_time_id);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (updating...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}


//function call_get_all_user() {
function call_get_all_user_detail() {
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
   var content = parent.document.getElementById("content");
 // var detail = parent.document.getElementById("detail");
	

	content.innerHTML="";
//	detail.innerHTML="";

  	
  	g_token=find_cookie_value("token");

 cgi_url = "/server/query_reseller_users?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">User Information Loading...<p>';

 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = get_all_user;
 xmlHttp.send(null);

}
function user_authorization_mode()
{
if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
	    g_user_authorization_mode=response;
	    callServer_System_Inquery();
	    g_System_timer=setInterval(function(){callServer_System_Inquery_Timer()},60*1000);
	  //  alert(g_user_authorization_mode);
	  //  show_uptime();
    }
}

function call_user_authorization_mode() {
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
  	
  	g_token=find_cookie_value("token");

	 cgi_url = "/server/query_user_authorization?token="+escape(g_token)+"&flag="+Math.random();
	  xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = user_authorization_mode;
	 xmlHttp.send(null);

}  

function call_get_all_user() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
   	g_token=find_cookie_value("token");
	
	bSystem_Inquery_Panel=0;
	if (g_token!=0)
	{
		cgi_url = "/server/group_query?token="+escape(g_token)+"&flag="+Math.random();
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = group_inquery_item;
		xmlHttp.send(null);
	}

}


/* function get_all_user()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var username;
    var szpassword;
    var szgroup;
    var expired_timel
    var paymodel;
    var paymodel_option;
    var user_point;
    var userip;

    var user_title="<p>"+"User List"+"</p>";
    var user_list;
    var i=0;
    var user_no=1;
	var total_user_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
   var content = parent.document.getElementById("content");
  //var detail = parent.document.getElementById("detail");
  var expired_YY;
  var expired_MM;
  var expired_DD;
  var d=new Date();
  	var cur_year=d.getFullYear();
  	var cur_month=d.getMonth()+1;
  	var cur_day=d.getDate();
  	var bexpired=0;
  	var pos;
  	var expired_time_temp;
  	var yearmsg;
  	var menustr;

	content.innerHTML="";
	//detail.innerHTML="";
	
	content.innerHTML="";
	 HTML_str= '<table border="0 align="center">'+
	  '<tr>'+
	      '<td width="10%" align="center"><font face="Arial" size="2">User no</font></td>';
	      if (g_user_authorization_mode==1)
	      {
		     HTML_str+='<td width="10%" align="center"><font face="Arial" size="2">User Name<br>(Primary Key)</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">Password</font></td>';
	      }else if (g_user_authorization_mode==2)
	      {
	      	HTML_str+='<td width="20%" align="center"><font face="Arial" size="2">PIN No.(Primary Key)</font></td>';
	      }
	      	
	      HTML_str+='<td width="15%" align="center"><font face="Arial" size="2">Bouquet</font></td>'+
	      '<td width="15%" align="center"><font face="Arial" size="2">CH List</font></td>'+
	      '<td width="15%" align="center"><font face="Arial" size="2">Expired Time / Paid Days<br>(MM/DD/YYYY)/ (Number)</font></td>'+
	      '<td width="10%" align="center"><font face="Arial" size="2">IP</font></td>'+
	      '<td width="10%" align="center"><font face="Arial" size="2">DRM Model</font></td>'+
	      '<td width="5%" align="center"><font face="Arial" size="2">DRM Points</font></td>'+
 	 '</tr>'+'<tr><td  colspan="9"><hr size="1" color="#66FFFF"></td></tr>';
 	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
	 	strlength=response[i].length;
   	    	username=response[i].slice(9,strlength);
     	 	strlength=response[i+1].length;
   	    	szpassword=response[i+1].slice(9,strlength);
    	 	strlength=response[i+2].length;
   	    	szgroup=response[i+2].slice(6,strlength);
	 	strlength=response[i+3].length;
   	    	expired_time=response[i+3].slice(13,strlength);

	 	pos=expired_time.indexOf('/');
		expired_MM=expired_time.substring(0,pos);
		expired_time_temp=expired_time.substring(pos+1);
		pos=expired_time_temp.indexOf('/');	
		expired_DD=expired_time_temp.substring(0,pos);
		expired_YY=expired_time_temp.substring(pos+1);
		//yearmsg=cur_year+'/'+cur_month+'/'+cur_day+'--'+expired_YY+'/'+expired_MM+'/'+expired_DD;
   	    	//alert(yearmsg);

   	    	bexpired=0;
   	    	if (cur_year<expired_YY)
   	    	{
   	    		bexpired=0;
   	    	}else if (cur_year==expired_YY)
   	    	{
	   	    	if (cur_month<expired_MM)
	   	    	{
	   	    		bexpired=0;
	   	    	}else if (cur_month==expired_MM)
	   	    	{	
		   	    	if (cur_day>expired_DD)
		   	    	{
		   	    		bexpired=1;
		   	    	}else
	   	    		{
	   	    			bexpired=0;
	   	    		}
	   	    	}else if (cur_month>expired_MM)
	   	    	{
	   	    		bexpired=1;
	   	    	}
	   	    	
   	    	}else if (cur_year>expired_YY)
    		{
    			bexpired=1;
    		}
    	
   	    	
   	    	
     	 	strlength=response[i+4].length;
     	 	
   	    	paymodel=response[i+4].slice(9,strlength);
	 	strlength=response[i+5].length;
   	    	user_point=response[i+5].slice(11,strlength);
		strlength=response[i+6].length;
   	    	userip=response[i+6].slice(7,strlength);
 
 		i=i+7;
		HTML_str=HTML_str+
		   '<tr>';
		   if (g_user_authorization_mode==1)
		   {
		      HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
		      '<td width="10%" align="center">'+
	 		' <font face="Arial" font size="2">'+
	 		' <input type="text" name="username"'+
	 		' id=username'+user_no+' size="12" value="'+
	 		username+'"/></font></td>'+
	 		
		      '<td width="10%" align="center">'+
	 		' <font face="Arial" font size="2">'+
	 		' <input type="text" name="password"'+
	 		' id=password'+user_no+' size="12" value="'+
	 		szpassword+'"/></font></td>';
		   }else if (g_user_authorization_mode==2)
	 		{
		 		HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
			      '<td width="20%" align="center">'+
		 		' <font face="Arial" font size="2">'+
		 		' <input type="text" name="username"'+
		 		' id=username'+user_no+' size="36" value="'+
		 		username+'"/></font></td>';
	 		}
	 		

		      HTML_str=HTML_str+'<td width="15%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="group" id=group'+user_no+'>';
	 		for (j=0;j<g_total_group_no;j++)
	 		{
	 			groupname=g_groupname_array[j];
	 			if (szgroup.search(groupname)==-1)
	 			{
	 				HTML_str+='<option value="'+groupname+'">'+groupname+'</option>';
	 			}
	 			else 
	 			{
	 				if (szgroup.length==groupname.length)
	 				{
	 					HTML_str+='<option selected="selected" value="'+groupname+'">'+groupname+'</option>';
	 				}else
	 				{
	 					HTML_str+='<option value="'+groupname+'">'+groupname+'</option>';
	 				}
	 			}	 			
	 		}
	  		HTML_str+='</select></font></td>';
	  		
	  		HTML_str=HTML_str+'<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" onchange="call_download_user_chlist('+user_no+','+'chlist'+user_no+')" name="ch_list" id=chlist'+user_no+'>'+
 			'<option value="-1">--</option>'+
			'<option value="enigma">Enigma</option>'+
			'<option value="enigma16">Enigma 1.6</option>'+
			'<option value="enigma(RTMP)">Enigma(RTMP)</option>'+
			'<option value="enigma16(RTMP)">Enigma 1.6(RTMP)</option>'+
 			'<option value="m3u_no">m3u(by chno)</option>'+
 			'<option value="m3u_name">m3u(by chname)</option>'+
 			'<option value="m3ue_no">m3u(by chno with suffix)</option>'+
 			'<option value="m3ue_name">m3u(by chname with suffix)</option>'+
			'<option value="octagon">octagon</option>'+
			'<option value="ariva">ariva</option>'+
 			'<option value="xbmc">XBMC</option>'+
 			'<option value="pure">Pure</option>'+
			'<option value="optumuss">Optumuss</option>'+
			'<option value="amiko">Amiko</option>'+
			'<option value="spark">Spark</option>'+
			'<option value="tiger">Tiger</option>'+
			'<option value="nstreamvod">nStreamVOD</option>'+
			'<option value="script_enigma">*Enigma Script*</option>'+
			'<option value="script_enigma16">*Enigma16 Script*</option>';
			HTML_str+='</select></font></td>';		
	  		                         
 
	  		
	  		
	  		if (bexpired==0)
	  		{	 		 		
			      HTML_str+='<td width="18%" align="center">'+
		 		' <font face="Arial"> <font size="2">'+
		 		' <input type="text" name="expired_time"'+
		 		' id=expired_time'+user_no+' size="12" value="'+
		 		expired_time+'"/></font></td>';		
	 		}else
	 		{
	 			
	 			HTML_str+='<td width="18%" align="center">'+
		 		' <font face="Arial"> <font size="2">'+
		 		' <input type="text" name="expired_time"  style="background:#ff0000"'+
		 		' id=expired_time'+user_no+' size="12" value="'+
		 		expired_time+'"/></font></td>';		

	 		}
	 			
	 	HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		' <input type="text" name="userip"'+
	 		' id=userip'+user_no+' size="12" value="'+
	 		userip+'"/></font></td>';
	 		
		      HTML_str+='<td width="15%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="paymodel" id=paymodel'+user_no+'>';
	 		for (j=0;j<3;j++)
	 		{
	 			paymodel_option=g_paymodel_array[j];
	 			if (paymodel.search(paymodel_option)==-1)
	 			{
	 				HTML_str+='<option value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}
	 			else
	 			{
	 				HTML_str+='<option selected="selected" value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}	 			
	 		}
	  		HTML_str+='</select></font></td>';
	 		
		      HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		' <input type="text" name="user_point"'+
	 		' id=user_point'+user_no+' size="12" value="'+
	 		user_point+'"/></font></td>'+
	 		
	 			 		
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Update_User("'+user_no+'")>'+
	      	      ' <font face="Arial"" size="2">Save</font></a></td>'+
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Del_User("'+user_no+'")>'+
	      	      ' <font face="Arial"" size="2">Del</font></a></td>'+
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Query_User_More("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">More</font></a></td>'+
		    '</tr>';
		total_user_no++;
		user_no++;
		//alert(HTML_str);
    }
        HTML_str=HTML_str+'</table>';
       //  alert(user_list_info.innerHTML);
   	menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td>'+
 	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_get_all_user()>"+
 	      ' <font face="Arila" size="2">Refresh</font></a>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_Add_New_User()>"+
	      ' <font face="Arila" size="2">Add</font></a>'+
	      //'&nbsp&nbsp&nbsp'+
	      // "<a href='javascript:void(0)' onclick=callServer_group_Inquery()>"+
	      // '<font size="2" face="Arial">Group</font></a>'+
	      '</td></tr></table>';
	 content.innerHTML=menustr+HTML_str+menustr;
	g_user_no=total_user_no;
 }

 
}
*/
function get_all_user()
{
 
  if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
     var username;
    var szpassword;
    var szgroup;
    var expired_timel
   // var paymodel;
  //  var paymodel_option;
  //  var user_point;
    var userip;
    var macid;
  //  var reseller;
    var user_title="<p>"+"User List"+"</p>";
    var user_list;
    var i=0;
    var user_no=1;
	var total_user_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
   var content = parent.document.getElementById("content");
  //var detail = parent.document.getElementById("detail");
  var expired_YY;
  var expired_MM;
  var expired_DD;
  var d=new Date();
  	var cur_year=d.getFullYear();
  	var cur_month=d.getMonth()+1;
  	var cur_day=d.getDate();
  	var bexpired=0;
  	var pos;
  	var expired_time_temp;
  	var yearmsg;
  	var menustr;

	content.innerHTML="";
	//detail.innerHTML="";
	
	content.innerHTML="";
	 HTML_str= '<table border="0 align="center">'+
	  '<tr>'+
	      '<td width="10%" align="center"><font face="Arial" size="2">User no</font></td>';
	      if (g_user_authorization_mode==1)
	      {
		     HTML_str+='<td width="10%" align="center"><font face="Arial" size="2">User Name<br>(Primary Key)</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">Password</font></td>';
		      HTML_str+='<td width="15%" align="center"><font face="Arial" size="2">Bouquet</font></td>'+
		      '<td width="15%" align="center"><font face="Arial" size="2">CH List</font></td>'+
		      '<td width="15%" align="center"><font face="Arial" size="2">Expired Time / Paid Days<br>(MM/DD/YYYY)/ (Number)</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">IP</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">MAC ID</font></td>'+
	//	      '<td width="5%" align="center"><font face="Arial" size="2">Reseller</font></td>'+
	//	      '<td width="10%" align="center"><font face="Arial" size="2">DRM Model</font></td>'+
	//	      '<td width="5%" align="center"><font face="Arial" size="2">DRM Points</font></td>'+
	 	 '</tr>'+'<tr><td  colspan="9"><hr size="1" color="#66FFFF"></td></tr>';
	      }else if (g_user_authorization_mode==2)
	      {
	      	HTML_str+='<td width="20%" align="center"><font face="Arial" size="2">PIN No.(Primary Key)</font></td>';
		      HTML_str+='<td width="15%" align="center"><font face="Arial" size="2">Bouquet</font></td>'+
		      '<td width="15%" align="center"><font face="Arial" size="2">CH List</font></td>'+
		      '<td width="15%" align="center"><font face="Arial" size="2">Expired Time / Paid Days<br>(MM/DD/YYYY)/ (Number)</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">IP</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">MAC ID</font></td>'+
//		      '<td width="5%" align="center"><font face="Arial" size="2">Reseller</font></td>'+
//		      '<td width="10%" align="center"><font face="Arial" size="2">DRM Model</font></td>'+
//		      '<td width="5%" align="center"><font face="Arial" size="2">DRM Points</font></td>'+
	 	 '</tr>'+'<tr><td  colspan="8"><hr size="1" color="#66FFFF"></td></tr>';
	      }
	      	
 	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
	 	strlength=response[i].length;
   	    	username=response[i].slice(9,strlength);
     	 	strlength=response[i+1].length;
   	    	szpassword=response[i+1].slice(9,strlength);
    	 	strlength=response[i+2].length;
   	    	szgroup=response[i+2].slice(6,strlength);
	 	strlength=response[i+3].length;
   	    	expired_time=response[i+3].slice(13,strlength);

	 	pos=expired_time.indexOf('/');
		expired_MM=expired_time.substring(0,pos);
		expired_time_temp=expired_time.substring(pos+1);
		pos=expired_time_temp.indexOf('/');	
		expired_DD=expired_time_temp.substring(0,pos);
		expired_YY=expired_time_temp.substring(pos+1);
		//yearmsg=cur_year+'/'+cur_month+'/'+cur_day+'--'+expired_YY+'/'+expired_MM+'/'+expired_DD;
   	    	//alert(yearmsg);

   	    	bexpired=0;
   	    	if (cur_year<expired_YY)
   	    	{
   	    		bexpired=0;
   	    	}else if (cur_year==expired_YY)
   	    	{
	   	    	if (cur_month<expired_MM)
	   	    	{
	   	    		bexpired=0;
	   	    	}else if (cur_month==expired_MM)
	   	    	{	
		   	    	if (cur_day>expired_DD)
		   	    	{
		   	    		bexpired=1;
		   	    	}else
	   	    		{
	   	    			bexpired=0;
	   	    		}
	   	    	}else if (cur_month>expired_MM)
	   	    	{
	   	    		bexpired=1;
	   	    	}
	   	    	
   	    	}else if (cur_year>expired_YY)
    		{
    			bexpired=1;
    		}
    	
   	    	
   	    	
     	 	//strlength=response[i+4].length;
     	 	
   	    	//paymodel=response[i+4].slice(9,strlength);
	 	//strlength=response[i+5].length;
   	    	//user_point=response[i+5].slice(11,strlength);
	 	strlength=response[i+4].length;
   	    	userip=response[i+4].slice(7,strlength);
	 	strlength=response[i+5].length;
   	    	macid=response[i+5].slice(6,strlength);
 
 		i=i+6;
		HTML_str=HTML_str+
		   '<tr>';
		   if (g_user_authorization_mode==1)
		   {
		      HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
		      '<td width="10%" align="center">'+
	 		' <font face="Arial" font size="2">'+
	 		' <input type="text" name="username"'+
	 		' id=username'+user_no+' size="12" value="'+
	 		username+'"/></font></td>'+
	 		
		      '<td width="10%" align="center">'+
	 		' <font face="Arial" font size="2">'+
	 		' <input type="text" name="password"'+
	 		' id=password'+user_no+' size="12" value="'+
	 		szpassword+'"/></font></td>';
		   }else if (g_user_authorization_mode==2)
	 		{
		 		HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
			      '<td width="20%" align="center">'+
		 		' <font face="Arial" font size="2">'+
		 		' <input type="text" name="username"'+
		 		' id=username'+user_no+' size="36" value="'+
		 		username+'"/></font></td>';
	 		}
	 		

		      HTML_str=HTML_str+'<td width="15%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="group" id=group'+user_no+'>';
	 		for (j=0;j<g_total_group_no;j++)
	 		{
	 			groupname=g_groupname_array[j];
	 			if (szgroup.search(groupname)==-1)
	 			{
	 				HTML_str+='<option value="'+groupname+'">'+groupname+'</option>';
	 			}
	 			else 
	 			{
	 				if (szgroup.length==groupname.length)
	 				{
	 					HTML_str+='<option selected="selected" value="'+groupname+'">'+groupname+'</option>';
	 				}else
	 				{
	 					HTML_str+='<option value="'+groupname+'">'+groupname+'</option>';
	 				}
	 			}	 			
	 		}
	  		HTML_str+='</select></font></td>';
	  		
	  		HTML_str=HTML_str+'<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" onchange="call_download_user_chlist('+user_no+','+'chlist'+user_no+')" name="ch_list" id=chlist'+user_no+'>'+
 			'<option value="-1">--</option>'+
			'<option value="enigma">Enigma</option>'+
			'<option value="enigma16">Enigma 1.6</option>'+
			'<option value="enigma(RTMP)">Enigma(RTMP)</option>'+
			'<option value="enigma16(RTMP)">Enigma 1.6(RTMP)</option>'+
 			'<option value="m3u_no">m3u(by chno)</option>'+
 			'<option value="m3u_name">m3u(by chname)</option>'+
 			'<option value="m3ue_no">m3u(by chno with suffix)</option>'+
 			'<option value="m3ue_name">m3u(by chname with suffix)</option>'+
			'<option value="octagon">octagon</option>'+
			'<option value="ariva">ariva</option>'+
 			'<option value="xbmc">XBMC</option>'+
 			'<option value="pure">Pure</option>'+
			'<option value="optumuss">Optumuss</option>'+
			'<option value="amiko">Amiko</option>'+
			'<option value="spark">Spark</option>'+
			'<option value="tiger">Tiger</option>'+
			'<option value="nstreamvod">nStreamVOD</option>'+
			'<option value="script_enigma">*Enigma Script*</option>'+
			'<option value="script_enigma16">*Enigma16 Script*</option>'+
			'<option value="script_mac_address">*MAC Address Script*</option>';
	  		HTML_str+='</select></font></td>';		
	  		                         
 
	  		
	  		
	  		if (bexpired==0)
	  		{	 		 		
			      HTML_str+='<td width="18%" align="center">'+
		 		' <font face="Arial"> <font size="2">'+
		 		' <input type="text" name="expired_time"'+
		 		' id=expired_time'+user_no+' size="12" value="'+
		 		expired_time+'"/></font></td>';		
	 		}else
	 		{
	 			
	 			HTML_str+='<td width="18%" align="center">'+
		 		' <font face="Arial"> <font size="2">'+
		 		' <input type="text" name="expired_time"  style="background:#ff0000"'+
		 		' id=expired_time'+user_no+' size="12" value="'+
		 		expired_time+'"/></font></td>';		

	 	}
	 	
	 		HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		' <input type="text" name="userip"'+
	 		' id=userip'+user_no+' size="12" value="'+
	 		userip+'"/></font></td>';	 			

	 		HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		' <input type="text" name="macid"'+
	 		' id=macid'+user_no+' size="12" value="'+
	 		macid+'"/></font></td>'+	 			

	 	//	HTML_str+='<td id=reseller'+user_no+' width="10%" align="center">'+
	 	//	' <font face="Arial"> <font size="2">'+
	 	//	reseller+'</font></td>'+	 			
	 		
		    /*  HTML_str+='<td width="15%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="paymodel" id=paymodel'+user_no+'>';
	 		for (j=0;j<3;j++)
	 		{
	 			paymodel_option=g_paymodel_array[j];
	 			if (paymodel.search(paymodel_option)==-1)
	 			{
	 				HTML_str+='<option value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}
	 			else
	 			{
	 				HTML_str+='<option selected="selected" value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}	 			
	 		}
	  		HTML_str+='</select></font></td>';
	 		*/
		      /* HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		' <input type="text" name="user_point"'+
	 		' id=user_point'+user_no+' size="12" value="'+
	 		user_point+'"/></font></td>'+
	 		*/
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Update_User("'+user_no+'")>'+
	      	      ' <font face="Arial"" size="2">Save</font></a></td>';
		      if (username!="root")
		      {
			      	HTML_str+='<td width="80" align="center">'+
			      "<a href='javascript:void(0)'"+
			      ' onclick=call_Del_User("'+user_no+'")>'+
		      	      ' <font face="Arial"" size="2">Del</font></a></td>';
	      	      }
	      	      
		      HTML_str+='<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Query_User_More("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">More</font></a></td>'+
		    '</tr>';
		total_user_no++;
		user_no++;
		//alert(HTML_str);
    }
        HTML_str=HTML_str+'</table>';
       //  alert(user_list_info.innerHTML);
   	menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td>'+
 	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_get_all_user()>"+
 	      ' <font face="Arila" size="2">Refresh</font></a>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_Add_New_User()>"+
	      ' <font face="Arila" size="2">Add</font></a>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_export_user_profile()>"+
	      ' <font face="Arila" size="2">Export</font></a>'+
	      //'&nbsp&nbsp&nbsp'+
	      // "<a href='javascript:void(0)' onclick=callServer_group_Inquery()>"+
	      // '<font size="2" face="Arial">Group</font></a>'+
	      '</td></tr></table>';
	 content.innerHTML=menustr+HTML_str+menustr;
	g_user_no=total_user_no;
 }

 
}

function group_inquery()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var group_no;
    var group_name;
    var group_concurrent_connection;
    var group_src;
    var group_title="<p>"+"Group List"+"</p>";
    var group_list;
    var i=0;
 	var group_active_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
 //   var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
	

	//content.innerHTML="";
	 HTML_str= '<table border="0" align="center">'+
	  '<tr>'+
	      '<td width="100" align="center"><font face="Arila" size="2">Bouquet</font></td>'+
	      '<td width="150" align="cneter"><font face="Arila" size="2">Bouquet Name</font></td>'+
	      '<td width="200" align="center"><font face="Arila" size="2">Channel No.</font></td>'+
 	      '<td width="200" align="center"><font face="Arila" size="2"> User Multiple Connection</font></td>'+
 	 '</tr>'+'<tr><td  colspan="4"><hr size="1" color="#66FFFF"></td></tr>';
 	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
	 	strlength=response[i].length;
	 	//alert(strlength);
   	    	group_no=response[i].slice(3,strlength);
     	 	strlength=response[i+1].length;
   	    	group_name=response[i+1].slice(5,strlength);
    	 	
    	 	strlength=response[i+2].length;
   	    	group_concurrent_connection=response[i+2].slice(11,strlength);
   	    	
     	 	strlength=response[i+3].length;
   	    	group_src=response[i+3].slice(4,strlength);

 		i=i+4;
		group_active_no++;
		HTML_str=HTML_str+
		   '<tr>'+
		      '<td width="100" align="center"><font face="Arila" size="2">'+group_no+'</font></td>'+
		      '<td width="150" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="groupname"'+
	 		' id=groupname'+group_no+
	 		' size="20" value="'+
	 		group_name+'"/></font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="groupsrc"'+
	 		' id=groupsrc'+group_no+
	 		' size="35" value="'+
	 		group_src+'"/></font></td>'+
	 		'<td width="150" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="groupconcurrentconnection"'+
	 		' id=groupconcurrentconnection'+group_no+
	 		' size="3" value="'+
	 		group_concurrent_connection+'"/></font></td>'+

		      '<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=callServer_update_group("'+group_no+'")>'+
	      	      ' <font face="Arila" size="2">Save</font></a></td>'+
		      '<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Del_group("'+group_no+'")>'+
	      	      ' <font face="Arila" size="2">Del</font></a></td>'+
		    '</tr>';
     }
        //detail.innerHTML=HTML_str;
      // alert(menu_main.innerHTML);
  
  	content.innerHTML='<table cellspacing="10" width=99%><tr><td width=20%>'+
  	'<font face="Arial" size="2">Total: '+ group_active_no+'</td>'+
 	      '<td width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_Add_New_group()>"+
	      '<font face="Arila" size="2">Add Bouquet</font></a></td>'+
 	      '<td width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_create_enigma_chlist()>"+
	      '<font face="Arila" size="2">Create Enigma CHlist</font></a></td>'+
 	      '<td width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_create_m3u8_chlist()>"+
	      '<font face="Arila" size="2">Create M3U8 CHlist</font></a></td>'+
 	      '<td width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_create_xbmc_chlist()>"+
	      '<font face="Arila" size="2">Create XBMC CHlist</font></a></td>'+
	      '</tr></table>'+HTML_str;
	g_total_group_no=group_active_no;
 
 }

 
}

function callServer_group_Inquery() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");
  	bSystem_Inquery_Panel=0;

 cgi_url = "/server/group_query?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Group Information Loading...<p>';


 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = group_inquery;
 xmlHttp.send(null);

}
function group_inquery_item()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var group_name;
    var i=0;
	var group_active_no=0;
	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
    	 	strlength=response[i+1].length;
   	    	g_groupname_array[group_active_no]=response[i+1].slice(5,strlength);
 // 	    	alert(g_groupname_array[group_active_no]);
 		i=i+4;
		group_active_no++;
	}
	g_total_group_no=group_active_no;
 	call_get_all_user_detail();
 }

 
}

function group_inquery_item_for_add()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var group_name;
    var i=0;
	var group_active_no=0;
	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
    	 	strlength=response[i+1].length;
   	    	g_groupname_array[group_active_no]=response[i+1].slice(5,strlength);
 // 	    	alert(g_groupname_array[group_active_no]);
 		i=i+4;
		group_active_no++;
	}
	g_total_group_no=group_active_no;
 	call_Add_New_User_detail();
 }

 
}


function system_info_inquery()
{
    
	if (xmlHttp.readyState == 4) 
	{
    		var response = xmlHttp.responseText.split("\r\n");
		var str;
		var i=0;
  		var content = parent.document.getElementById("content");
  		
   		if (response[0].search("ezhometech")==0)
  		{
	  		str='<p align="left" style="margin-top: 35; margin-left: 25"><table border="0" cellpadding="0" cellspacing="10" border>';
	  		str+='<tr><td><p align="left" style="text-indent: 5"><font face="Arial" size="2" color="#ff0000">System Information</td></tr>';
	  		while(1)
	  		{
				if (response[i]==0) break;
				str+='<tr>'+
				'<td>'+
				'<p align="left" style="text-indent: 5"><font face="Arial" size="2">'+'<b>*</b> '+response[i]+'</font>'+
				'</p>'+
				'</td>'+      
				'</tr>';
				i++;
			}
			str+='</table>';
			content.innerHTML=str;	
		}else
		{
  			bSystem_Inquery_Panel=0;
  			clearInterval(g_System_timer);	
		    	g_token=find_cookie_value("token");
		  	g_user_id=find_cookie_value("userid");
		  	g_password=find_cookie_value("password");
		 	 cgi_url = "/token/destroytoken?token="+escape(g_token)+"&flag="+Math.random();
			 xmlHttp.open("GET", cgi_url, true);
			 xmlHttp.onreadystatechange = login_out_return;
			 xmlHttp.send(null);
		}
			

	}

}
function callServer_System_Inquery_Timer()
{
	var time_delay=5000;

	if (bSystem_Inquery_Panel==1)
	{
	    	cgi_url= "/server/system_info_inquery?token="+escape(g_token)+"&flag="+Math.random();
	
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange =system_info_inquery ;
		xmlHttp.send(null);
	}	
	//setTimeout("show_uptime()",time_delay);
}

function callServer_System_Inquery()
{
	bSystem_Inquery_Panel=1;
	callServer_System_Inquery_Timer();
	
}
function Download_User_Chlist() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
       if ((response==1))
    {
	    		alert("For security, root can not create channel list");
    }else if ((response==0))
    {
	    		alert("Can not create channel list");
    }else
    {
	    if (response.length>0)
	    
	    {
	    	window.location =response; 
	    }else
	    	{
	    		alert("Can not create channel list");
	    	}
	    	
    }
}
}
function call_download_user_chlist(user_no,sObj)
{
 var username_id="username"+user_no; 
 var username;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(username_id);
	username=g_item.value;
	
   	g_token=find_cookie_value("token");
	//alert(user_no);
	//alert(sObj.value);
  	cgi_url = "/server/call_download_user_chlist?token="+escape(g_token)+"&hostname="+location.hostname+"&username="+escape(username)+"&ch_list_type="+sObj.value+"&flag="+Math.random();
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Download_User_Chlist;
	 xmlHttp.send(null); 

}
function list_active_player_info(){
  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText.split("\r\n");
    var sessionnotext;
    var sessionno;
    var username;
    var playername;
    var watching_ch;
    var box_time;
    var box_ip;
    var box_country;
    var box_group;
    var box_group_text;
    var eztbox_title="<p>"+"macid IP name"+"</p>";
    var eztbox_list;
    var i=0;
    var box_no=1;
	var eztbox_active_no=0;
	var ret=0;
	var HTML_title_str='';
	var HTML_str='';
	var macid_value;
  var content = parent.document.getElementById("content");
  // var detail = parent.document.getElementById("detail");
	

	content.innerHTML="";
//	detail.innerHTML="";
	

	 HTML_title_str= '<table border="0" align="center" height="53">'+
	  '<tr>'+
	      '<td width="50" height="17" align="center"><font face="Arila" size="2">No.</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Subscriber</font></td>'+
	      '<td width="100 height="17" align="center"><font face="Arila" size="2">Session No.</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Player Name</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Watching CH/Moive</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Starting Time</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">IP</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">MAC Address</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Country</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Protocol</font></td>'+
	   //   '<td width="100" height="17" align="center">'+
	    //  " <a href='javascript:void(0)' onclick=callServer_Reboot_All_Player()>"+
	    // ' <font face="Arial" size="2">Reboot All</font></a></td>'+
 	 '</tr>'+'<tr><td  colspan="10"><hr size="1" color="#66FFFF"></td></tr>';
	
	while (1)
	{
		if (response[i]==0) break;
		//alert(response[i]);
		sessionnotext=response[i];
		sessionno=sessionnotext.slice(10);
		//alert(sessionno);
		username=response[i+1];
//		alert(username);
		ret=username.indexOf("username",0);
		//if (ret==-1) break;
		playername=response[i+2];
		watching_ch=response[i+3];
		
		box_time=response[i+4];
//		alert(box_time);
		box_ip=response[i+5];
//		alert(box_ip)
		box_macid=response[i+6];
		box_country=response[i+7];
		box_group_text=response[i+8];
		box_group=box_group_text.slice(6);
//		alert(box_group);
		i=i+9;
		eztbox_active_no++;
		HTML_str='<tr>'+
		      '<td width="50" height="18" align="center"><font face="Arila" size="2">'+box_no+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+username.slice(9)+'</font></td>'+
		      '<td width="50" height="18" align="center"><font face="Arila" size="2">'+sessionno+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+playername.slice(11)+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+watching_ch.slice(12)+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+box_time.slice(12)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_ip.slice(10)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_macid.slice(13)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_country.slice(8)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_group+'</font></td>'+
		      '<td width="50" height="18" align="center">'+
		      '</tr>'+HTML_str;
		      
		box_no++;
     }
       // contentinnerHTML=HTML_str;
       HTML_str=HTML_title_str+HTML_str;
        
  	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font face="Arial" size="2">Total: '+ eztbox_active_no+'</font></td>'+
  	'<td width=70% align="right">'+"<a href='javascript:void(0)'"+
	' onclick=calllist_active_player_info()>'+
	' <font face="Arial" size="2">Query</font></a></td>'+
	'</tr></table>'+HTML_str;
	
	//alert(content.innerHTML);
    
 }
 
 
}
function calllist_active_player_info(){

	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;

   	g_token=find_cookie_value("token");
   	bSystem_Inquery_Panel=0;
 	bQuery_Channel_Status=0;
	var content = parent.document.getElementById("content");

	if (g_token!=0)
	{
		cgi_url= "/player/get_reseller_player_list?token="+escape(g_token)+"&flag="+Math.random();
		content.innerHTML='<p align="center"><font face="Arila" color="#FF0000" size="4">Player Information Loading...<p>';
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = list_active_player_info;
		xmlHttp.send(null);
	}
 
 

}