var xmlHttp = new XMLHttpRequest();
var g_token=0;
var g_item=0;
var total_player_no=1000;
var g_macid;
var g_user_id;
var g_password;
var g_ch_no;
var g_video_itemid= Array();
var g_file_path;
var vlc_monitorTimerId = 0; 
var prevState = 0; 
var g_channel_no=1;
var g_channel_max_no=5;
var g_userid_password_exist=0;
var g_skip_value;
var g_timer;
var g_current_timestamp;
var g_dvr_timestamp=0;
var bdvr_on;
var g_server_dvr_sec;
var g_cur_sec;
var g_dvr_sec;


var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "an unknown version";
		this.OS = this.searchString(this.dataOS) || "an unknown OS";
	},
	searchString: function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	},
	dataBrowser: [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{ 	string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera",
			versionSearch: "Version"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{		// for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "Explorer",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{ 		// for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
	],
	dataOS : [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			   string: navigator.userAgent,
			   subString: "iPhone",
			   identity: "iPhone/iPod"
	    },
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
	]

};
function change_link(new_url, new_width, new_height)
{
   var menu_main= document.getElementById("menu_main");
   menu_main.innerHTML='<iframe frameborder="0" width='+new_width+' height='+new_height+' src="'+new_url+'"></iframe>';	
 
}

function find_cookie_value(keystr)
{ 
	var restring;
	var str;
	var substr1;
	var pos1, pos2;
	
	str=document.cookie;
	//alert(str);
	//alert(keystr);
	pos1=str.indexOf(keystr);
	//alert(pos1);
	subchar=str.substring(pos1+keystr.length,pos1+keystr.length+1);
	//alert(subchar);
	if (subchar==';')
	{
		return 0;
	}else
	{
		substr1=str.substring(pos1+keystr.length+2,str.length);
		//alert(substr1);
		pos1=substr1.indexOf(']');
		restring=substr1.substring(0,pos1);
		//alert(restring);
		return restring;
	}
	
	
}
function add_cookie_value(keystr,keyvalue)
{
	document.cookie=keystr+'=['+keyvalue+']';
}
function add_cookie_date(exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
document.cookie='expires='+exdate.toUTCString();
//alert(document.cookie);
}
function Clear_cookie()
{
	document.cookie='token'+'=';
	//document.cookie='userid'+'=';
	//document.cookie='password'+'=';
	document.cookie='dir_path'+'=';
	document.cookie='video_path'+'=';
	document.cookie='httpport'+'=';
	document.cookie='';

}

function encode64(input) {  

 var keyStr = "ABCDEFGHIJKLMNOP" +  

              "QRSTUVWXYZabcdef" +  

              "ghijklmnopqrstuv" +  

              "wxyz0123456789+/" +  

              "=";  
  // input = escape(input);  

    var output = "";  

    var chr1, chr2, chr3 = "";  

    var enc1, enc2, enc3, enc4 = "";  

    var i = 0; 
  
 
    do {  

       chr1 = input.charCodeAt(i++);  

       chr2 = input.charCodeAt(i++);  

       chr3 = input.charCodeAt(i++);  

  

       enc1 = chr1 >> 2;  

       enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);  

       enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);  

       enc4 = chr3 & 63;  

  

    /*   if (isNaN(chr2)) {  

          enc3 = enc4 = 64;  

       } else if (isNaN(chr3)) {  

          enc4 = 64;  

       }  
*/
  

       output = output +  

          keyStr.charAt(enc1) +  

          keyStr.charAt(enc2) +  

          keyStr.charAt(enc3) +  

          keyStr.charAt(enc4);  
  
       chr1 = chr2 = chr3 = "";  

       enc1 = enc2 = enc3 = enc4 = "";  

    } while (i < input.length);  

  

    return output;  

 }  
function Init_System_Setting()
{
  if (xmlHttp.readyState == 4) {
    var response= xmlHttp.responseText.split("\r\n");
    var httpport;
    var strlength;
    	strlength=response[0].length;
	httpport=response[0].slice(9,strlength);
     add_cookie_value("httpport",httpport);
   
  }
}
function streaming_port()
{
	
	  var url = "/server/inquery_server_httpport?token="+escape(g_token)+"&flag="+Math.random();
   	g_token=find_cookie_value("token");
	if (g_token!=0)
	{
		 xmlHttp.open("GET", url, true);
		 xmlHttp.onreadystatechange = Init_System_Setting;
		 xmlHttp.send(null);
	}
}
	

function login_return() {
  var login_msg = document.getElementById("login_msg");
  var login_area = document.getElementById("login_area");
  var login_status = parent.document.getElementById("login_status");
  var browser_name;


  
//  alert(login_status.innerHTML);
  
  // alert(id_check_flag);
  
  if (xmlHttp.readyState == 4) 
  {
    var response = xmlHttp.responseText;
  // alert(response);
  if (response.search("-1")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Verdana"> <font color="#FFFFFF" size="2">*** parameter error***</font>';
    } else if (response.search("-2")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Verdana"> <font color="#FFFFFF" size="2">*** Wrong User ID or Password***</font>';
    } else if (response.search("-3")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Verdana"> <font color="#FFFFFF" size="2">*** User ID Time Expired***</font>';
    } 
    else
    {
  	g_token=response.slice(6,response.length);
  	//  document.cookie="token="+ g_token+"userid="+g_user_id+"password="+g_password+"#";
   	add_cookie_value("token",g_token);
  	add_cookie_value("userid",g_user_id);
  	add_cookie_value("password",g_password);
 	add_cookie_date(365);
  	
 	    id_check_flag=1;

   	  login_status.innerHTML="<a href='javascript:void(0)' onclick=logout()>"+
  	  '<font face="Verdana" color="#FFFFFF" size="4">Logout</font></a>'; 
  	 get_channel_link("middleware/videos/Channel");
  	 streaming_port();
  	/*  BrowserDetect.init();
  	  browser_name=BrowserDetect.browser;
 	if (browser_name.search("Explorer")==0)
	{
  	  change_link("ovs.htm",900,400);
  	} else 	if (browser_name.search("Safari")==0)
  	{
  	  change_link("ovs_html5.htm",900,400);
   	} else
  	{
  	  change_link("ovs_html5.htm",900,400);
  	} */

    }
  }

}

function login(){
 var cgi_url;
 var encrypt_str;
 var userid_pass;
 var t_user_id;
 var t_password;
// if (g_userid_password_exist==0)
// {
	 t_user_id = document.getElementById("user_id").value;
	 t_password = document.getElementById("password").value;
	 if ((t_user_id.length==0)&&(t_password.length==0))
	 {
		  g_user_id=find_cookie_value("userid");
	  	  g_password=find_cookie_value("password");
	  	//  alert(g_user_id);
	  	 // alert(g_password);
  	  }else
  	{
  		g_user_id=t_user_id;
  		g_password=t_password;
  	}
  	  	
  /*	  if ((g_user_id!=0)&&(g_password!=0))
  	  {
 		 if ((g_user_id!=t_user_id) && (t_user_id.length>0))
		 {
 		 	g_user_id=t_user_id;
		}
		 if ((g_password!=t_password)&&(t_password.length>0))
		 {
 		 	g_password=t_password;
		}
		
		
	 } 
	 */
	 document.getElementById("user_id").value=g_user_id;
	 document.getElementById("password").value=g_password;
	
 	
 userid_pass=g_user_id+':'+g_password;
//alert(userid_pass);
 encrypt_str=encode64(userid_pass);
cgi_url = "/token/createtokenbased64?encrpty="+escape(encrypt_str)+"&flag="+Math.random();
 login_status.innerHTML='login...';
 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = login_return;
 xmlHttp.send(null);


}

function login_out_return() {
  
//var ch_up_flag=0;
  
  if (xmlHttp.readyState == 4) 
  {
    var response = xmlHttp.responseText;

         //ch_up_flag=find_cookie_value("ch_up_flag");       
         //if (ch_up_flag==1)
         //{
         //	callezserver_refresh_channel();
         //	Clear_Channel_update();
         //}
    	g_token=0;	
 	Clear_cookie();
     login_status.innerHTML="";
     menu_main.innerHTML='<p align="center"><b><i><font face="Arial" color="#FFFF00" size="6">Welcome to EZhometech IPTV</font></i></b></p>'+
     '<p align="center"><font face="Arial" size="6" color="#FFFF00">Enjoy Internet Videos</font></p><p align="center">';
	//init();
 
   }

}
function logout()
{
	var cgi_url;
  var login_status = document.getElementById("login_status");
   var confirm_msg="Logout?";
  var cookieStr;
  var firstpos;
  var endpos;
  
	 if (confirm(confirm_msg))
	{
  
     	g_token=find_cookie_value("token");
  	g_user_id=find_cookie_value("userid");
  	g_password=find_cookie_value("password");
 	 cgi_url = "/token/destroytoken?token="+escape(g_token)+"&userid="+escape(g_user_id)+ "&password=" + escape(g_password)+"&flag="+Math.random();
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = login_out_return;
	 xmlHttp.send(null);

	}
}
function init() {

       menu_top.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0">'+
	   '<tr><td>'+
	   '<p style="text-indent: 5"><font color="#FFFFFF" face="Verdana" size="2">User ID: </font></p>'+
	   '</td>'+      
	   '<td>'+ 
//	   '<font face="Verdana"> <font size="2"> <input type="text" name="user_id" id="user_id" size="20" value="root"/></font></font>'+
	   '<font face="Verdana"> <font size="2"> <input type="text" name="user_id" id="user_id" size="20"/></font></font>'+
	   '</td>'+
	   
	   
	   '<td>'+
	   '<p style="text-indent: 5"><font color="#FFFFFF" face="Verdana" size="2">Password: </font></p>'+    
	   '</td>'+ 
	                                   
	   '<td> <font face="Verdana" size="2"> <input type="password" name="password" id="password" size="20"/></font><font face="Verdana"><font size="2"></font>'+
	   '<input type="button" value="OK" onclick="javascript:login();" name="B1" /></font>'+
	   '</td></tr>'+
	   '</table>';
	   Clear_cookie();
	   
	  //  g_user_id=find_cookie_value("userid");
  	  //  g_password=find_cookie_value("password");
  	   //// if ((g_user_id!=0)&&(g_password!=0))
  	   // {
  	    //	g_userid_password_exist=1;
  	    	login();
  	  //  }
  	

	  // get_channel_link("middleware/videos/Channel");
//	   BrowserDetect.init();
//	   alert(BrowserDetect.browser);

	  // alert( menu_main.innerHTML);
}
/*
function first_page() {
                
       menu_main.innerHTML='<p style="margin-top: -10; margin-bottom: 20" align="center"><font face="Verdana" color="#0000FF" size="6"><b>EZserver</b></font><table border="0" cellpadding="0" cellspacing="0>'+
	   '<tr><td width=100% colspan="2"></td></tr>'+
       	 '<tr>'+
   
         '<td width="50%" valign="middle" align="center" height="155"><a href='+"'javascript:void(0)'"+' onclick=system_setting()><img border="0" src="pictures/setting.PNG"></a></td>'+
         '<td width="50%" valign="middle" align="center" height="155"><a href='+"'javascript:void(0)'"+' onclick=callServer_CH_Inquery()><img border="0" src="pictures/channel_management.PNG"></a></td>'+
         '</tr>'+
 
    	 '<tr>'+
           '<td width="50%" valign="middle" align="center" height="155"><a href='+"'javascript:void(0)'"+' onclick=calleztbox_info()><img border="0" src="pictures/player_management.PNG"></a></td>'+
       	  '<td width="50%" valign="middle" align="center" height="155"><a href='+"'javascript:void(0)'"+' onclick=callratings_points()><img border="0" src="pictures/audience_measurement.PNG"></a></td>'+
    	'</tr>'+
      	'</table>';
    	back_status.innerHTML="";
  //  	menu_main_title.innerHTML="";

}
*/

function Get_File_List()
{
  var picture_menu = document.getElementById("picture_menu");
   var str;
   var buffer;
   var i;
   var path;
   var trstart=0;
   var strtext;
   var video_path;
   var browser_name;
   var buffer_video_text;
   var media_text;
   var media_text_path;
 
 
  if (xmlHttp.readyState == 4) {
  var response = xmlHttp.responseText.split("\n");
   // alert(g_file_path);
     str='';
     strtext='';
      	  BrowserDetect.init();
  	  browser_name=BrowserDetect.browser;
 	g_token=find_cookie_value("token");
 	if (g_token==0) return; 
 	//alert(g_token);


        for (i=0;;i++)
  	{
	  // alert(response[i]);
	    if (response[i]==0)
  	    {
  	    	break;
 	    } else
  	    {
  	    	if ((response[i].search("flv")>0) || (response[i].search("mp4")>0))
  	    	{
	  	    	strlength=response[i].length;
	  	    	strlength-=1;
	  	    	buffer=response[i].slice(0,strlength);
	  	    	path='/'+g_file_path+'/'+buffer;
    	  	    	buffer_picture=response[i].substring(0,strlength-3)+'jpg';
	  	    	media_text=response[i].substring(0,strlength-3)+'htm';
	  	    	buffer_video_text=response[i].substring(0,strlength-4);
	  	    	picture_path='/'+g_file_path.replace("videos","pictures")+'/'+buffer_picture;
	  	    	//alert(picture_path);
	  	    	//alert(media_text);
	  	    	media_text_path='/'+g_file_path.replace("videos","text")+'/'+media_text;
	  	    	//alert(media_text_path);
	  	    	
	  	    	if (trstart==0)
	  	    	{
	  	    		str+='<tr>';
	  	    		strtext+='<tr>';
	  	    	} 
	 		
 			if ((path.search(".mp4")>0))
 			{
				//if (g_token==0)
				//{
				//	str+='<td width="16%" valign="middle" align="center" height="185">'+
				//	'<img border="0" src="'+picture_path+'" width="150" height="213"></td>';
				//} else
				//{
		  	    	
					str+='<td onmouseover=call_show_text("'+media_text_path+'") width="16%" valign="middle" align="center" height="185">'+
					'<a style="text-decoration:none"'+ 
					"href='javascript:void(0)'"+
					' onclick=call_play_video("'+path+'")>'+
					'<img border="0" src="'+picture_path+'" width="150" height="213"></a></td>';
					strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#FFFFFF" face="Verdana">'+buffer_video_text+'</font></td>';
				//}
			}else if ((browser_name.search("Safari")!=0) && (path.search(".flv")>0))
			{
				//if (g_token==0)
				//{
				//	str+='<td width="16%" valign="middle" align="center" height="185">'+
				//	'<img border="0" src="'+picture_path+'" width="150" height="213"></td>';
				//} else
				//{
		  	    	
					str+='<td onmouseover=call_show_text("'+media_text_path+'") width="16%" valign="middle" align="center" height="185">'+
					'<a style="text-decoration:none"'+ 
					"href='javascript:void(0)'"+
					' onclick=call_play_video("'+path+'")>'+
					'<img border="0" src="'+picture_path+'" width="150" height="213"></a></td>';
					strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#FFFFFF" face="Verdana">'+buffer_video_text+'</font></td>';
				//}
			}
				
			

			trstart++;
			if (trstart==5)
	  	    	{
	  	    		str+='</tr>';
	  	    		strtext+='</tr>';
	  	    		str+=strtext;
	  	    		strtext='';
	  	    		trstart=0;
	 	    		
	  	    	}
	 		//alert(str);
 		}
  	    } 
      }
  	if (trstart!=0)
 	{
 	  	    		str+='</tr>';
	  	    		strtext+='</tr>';
	  	    		str+=strtext;
	}
	if (i==0)
	{
		str='<tr><td><p align="center"><b><i><font face="Arial" color="#FFFFFF" size="5">No Content</font></i></b></p>'+
     		'</td></tr>';
	}
	
 	picture_menu.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%">'+str+'</table></center>';
      //alert(menu_main.innerHTML);
     //  title_text.innerHTML= '<p align="center"><font size="3">'+g_file_path+'</font>'
   }
  	
}


function callServer_Get_File_List(){
 var  cgi_url;
 var path;
 // var keyword_buffer= parent.parent.document.getElementById("keyword_buffer").innerHTML;
var home_field = parent.parent.document.getElementById("home_field");

	//home_field.innerHTML="<a href='javascript:void(0)' "+'onclick=backtovs()>'+'<font face="Verdana" color="#FF0000" size="4">Home</font></a>'; 
	path=find_cookie_value("dir_path");
	g_file_path=path;
	g_token=find_cookie_value("token");
 
//	alert(g_file_path);
 // cgi_url= "/cgi-bin/cgi_ezserver?get_file_list="+path+"&flag="+Math.random();
  cgi_url= "/server/get_folder_filelist?token="+escape(g_token)+ "&path=" +path+"&flag="+Math.random();
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Get_File_List;
	 xmlHttp.send(null);
}
function change_movie_link(path)
{
	var vlc;
//	var keyword_buffer= parent.document.getElementById("keyword_buffer");
	var browser_name;

//	keyword_buffer.innerHTML= '<p align="center"><font color="#FFFFFF" size="3">'+path+'</font>';
	add_cookie_value("dir_path",path);
     	menu_main.innerHTML='<iframe frameborder="0" width=100% height=800 src="'+"pictures.htm"+'"></iframe>';
 
}
function Get_Dvr_Starting_Time()
{
 if (xmlHttp.readyState == 4) {
  	var response = xmlHttp.responseText;
  	var d=new Date(response);
 //	alert(response);

  	g_server_dvr_sec=d.getTime();
  //	alert(g_server_dvr_sec);
  	
   	
  }
}

function play_channel(path, ch_no,dvr_on)
{
	var vlc;
	var vlc_id;
	var flash_video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var ch_picture_menu = document.getElementById("ch_picture_menu");
	var  cgi_url;
	var d=new Date();
   	var httpport;
	
 	cgi_url= "/server/query_dvr_starting_time?token="+escape(g_token)+ "&ch_no=" +ch_no+"&flag="+Math.random();
	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange = Get_Dvr_Starting_Time;
	xmlHttp.send(null);

	
	g_cur_sec=d.getTime();
	g_dvr_sec=g_cur_sec;
	
	ch_picture_menu.innerHTML='<table  align="center" border="0" cellpadding="0" cellspacing="0" height="36" width="100%">'+
                '<tr>'+
		'<td id=back width="91" height="31" rowspan="2" align="left"><p align="left"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p></td>'+
		'<td id=backword_button_id width="146" height="31" rowspan="2"></td>'+
		'<td id=time_text_id width="143" height="16"></td>'+
		'<td id=forward_button_id width="35" height="31" rowspan="2" width="75"></td>'+
		'<td id=to_live_button_id width="148" height="31" rowspan="2"></td>'+
		'<td id=cur_video_time width="51" height="31" rowspan="2"><p align="left"></td>'+
        	'</tr>'+
                '<tr>'+
		'<td id=dvr_video_time width="143" height="15"><p align="center"></td>'+
        	'</tr>'+
                '<tr>'+
                '<td id="video_area" width="100%" height="185" align="center" colspan="6"></td>'+
                '</tr>'+
                '</table>';
	
	g_dvr_timestamp=0;
	bdvr_on=0;
	g_token=find_cookie_value("token");
	httpport=find_cookie_value("httpport");
	
 // 	video_path="http://"+location.host+path+'?token='+g_token;
   	video_path="http://"+location.hostname+":"+httpport+path+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
 	g_video_path=video_path;
 //	alert(video_path);
 
 	BrowserDetect.init();
	browser_name=BrowserDetect.browser;
	if (path.search(".flv")>0)
	{
		if (browser_name.search("Explorer")==0)
		{
			str='<object width="640" height="480">'+
			'<param name="allowFullScreen" value="true" />'+
			'<param name="allowscriptaccess" value="always" />'+
			'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" width="640" height="480" allowscriptaccess="always" allowfullscreen="true" flashvars="src='+video_path+'&autoPlay=true">'+ 
			'</embed>'+
			'</object>';	
		} else 
		{
			str='<param name="allowFullScreen" value="true"></param>'+
			'<param name="allowscriptaccess" value="always"></param>'+
			'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" autoplay="yes" type="application/x-shockwave-flash" width="640" height="480" allowscriptaccess="always" allowfullscreen="true" flashvars="src='+video_path+'&autoPlay=true">';
		
	
		}
	} else if (path.search(".m3u8")>0)
	{
		str='<video width="640" height="480" src="'+video_path+'" controls autoplay>';
	}else if (path.search(".ch")>0)
	{
		 if (browser_name.search("Explorer")==0)
 		 {
 		 	str='<OBJECT id="VIDEO" width="640" height="480" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
			'<PARAM NAME="URL" VALUE="'+video_path+'">'+
			'<PARAM NAME="AutoStart" VALUE="True">'+
			'</OBJECT>';
			 
    		}else
		{
			str='<embed type="application/x-vlc-plugin" width="640" height="480" name="player" autoplay="yes" loop="no" '+
			'target="'+video_path+'">';
		}	
	}
	
	
	time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>Current Time</b></font></p>';
	if (dvr_on)
	{
		backword_button_id.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		//forward_button_id.innerHTML='<p align="left"><input type="button" value=">>" onclick="javascript:dvr_for_backward(1);" name="B2" /></p>';
	}else
		{
			backword_button_id.innerHTML='';
			forward_button_id.innerHTML='';
			to_live_button_id.innerHTML='';
			cur_video_time.innerHTML='';
		}
		
	//g_current_timestamp=0;
	g_timer=setInterval(function(){show_drv_time_cur_time(0)},1000);

	//flash_video_window=document.getElementById("flash_video_window");

	//alert(str);
	video_area.innerHTML=str;
	
	
}
function Get_Channel_List()
{
  var picture_menu = document.getElementById("picture_menu");
   var str;
   var buffer;
   var i;
   var path;
   var trstart=0;
   var strtext;
   var video_path;
   var browser_name;
   var buffer_video_text;
   var media_text;
   var media_text_path;
     var ch_no;
    var ch_name;
    var ch_src;
   var ch_type;
     var dvr_folder_on=0;

 
  if (xmlHttp.readyState == 4) {
  var response = xmlHttp.responseText.split("\r\n");
   // alert(g_file_path);
     str='';
     strtext='';
      	  BrowserDetect.init();
  	  browser_name=BrowserDetect.browser;
 	g_token=find_cookie_value("token");
 	//alert(g_token);
	if (g_token==0) return; 


        for (i=0;;i=i+6)
  	{
	 // alert(response[i]);
	    if (response[i]==0)
  	    {
  	    	break;
 	    } else
  	    {
 	 	strlength=response[i].length;
	 	//alert(strlength);
   	    	ch_no=response[i].slice(3,strlength);
   	    	//alert(ch_no);
     	 	strlength=response[i+1].length;
   	    	ch_name=response[i+1].slice(5,strlength);
     	 	strlength=response[i+2].length;
   	    	ch_src=response[i+2].slice(4,strlength);
   	    	//alert(ch_src);
     	 	strlength=response[i+4].length;
   	    	ch_type=response[i+4].slice(5,strlength);
  	    	picture_path='/'+g_file_path.replace("videos","pictures")+'/ch'+ch_no+'.jpg';;
	  	media_text_path='/'+g_file_path.replace("videos","text")+'/ch'+ch_no+'.htm';;
	    	if (trstart==0)
  	    	{
  	    		str+='<tr>';
  	    		strtext+='<tr>';
  	    	} 
  		if (ch_type.search("dvr")>=0)
   	    	{
   	    		dvr_folder_on=1;
   	    	}else
   	    	{
   	    		dvr_folder_on=0;
   	    	}
 		if (ch_src.search("rtmp")==0)
  	    	{
	  	    	path='/ch'+ch_no+'.flv';
	  	} else
  		{
  			if (browser_name.search("Safari")==0)
  			{
	  	    		path='/ch'+ch_no+'.m3u8';
	  	    	}else
	  	    	{
	  	    		path='/'+ch_no+'.ch';
	  	    	}  	    	
		}
		str+='<td onmouseover=call_show_text("'+media_text_path+'") width="16%" valign="middle" align="center" height="185">'+
		'<a style="text-decoration:none"'+ 
		"href='javascript:void(0)'"+
		' onclick=play_channel("'+path+'",'+ch_no+','+dvr_folder_on+')>'+
		'<img border="0" src="'+picture_path+'" width="150" height="213"></a></td>';
		strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#FFFFFF" face="Arail">'+ch_name+'</font></td>';

  
 /*		if ((browser_name.search("Safari")==0) && (path.search(".m3u8")>0))
		{
    			str+='<td onmouseover=call_show_text("'+media_text_path+'") width="16%" valign="middle" align="center" height="185">'+
			'<a style="text-decoration:none"'+ 
			"href='javascript:void(0)'"+
			' onclick=play_channel("'+path+'",'+ch_no+','+dvr_folder_on+')>'+
			'<img border="0" src="'+picture_path+'" width="150" height="213"></a></td>';
			strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#FFFFFF" face="Arail">'+ch_name+'</font></td>';
		}else if ((browser_name.search("Safari")!=0) && (path.search(".flv")>0))
		{
			str+='<td onmouseover=call_show_text("'+media_text_path+'") width="16%" valign="middle" align="center" height="185">'+
			'<a style="text-decoration:none"'+ 
			"href='javascript:void(0)'"+
			' onclick=play_channel("'+path+'",'+ch_no+','+dvr_folder_on+')>'+
			'<img border="0" src="'+picture_path+'" width="150" height="213"></a></td>';
			strtext+='<td width="16%" valign="middle" align="center" height="23"><font size="2" color="#FFFFFF" face="Arail">'+ch_name+'</font></td>';
		}
*/		

		trstart++;
		if (trstart==5)
  	    	{
  	    		str+='</tr>';
  	    		strtext+='</tr>';
  	    		str+=strtext;
  	    		strtext='';
  	    		trstart=0;
 	    		
  	    	}
 		//alert(str);
 		
  	    } 
      }
  	if (trstart!=0)
 	{
 	  	    		str+='</tr>';
	  	    		strtext+='</tr>';
	  	    		str+=strtext;
	}
 	ch_picture_menu.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0" width="100%">'+str+'</table></center>';
      //alert(menu_main.innerHTML);
     //  title_text.innerHTML= '<p align="center"><font size="3">'+g_file_path+'</font>'
   }
  	
}
function callServer_Get_Channel_List(){
 var  cgi_url;
 var path;
 // var keyword_buffer= parent.parent.document.getElementById("keyword_buffer").innerHTML;
var home_field = parent.parent.document.getElementById("home_field");

	if (g_timer>0) clearInterval(g_timer);



	//home_field.innerHTML="<a href='javascript:void(0)' "+'onclick=backtovs()>'+'<font face="Verdana" color="#FF0000" size="4">Home</font></a>'; 
	path=find_cookie_value("dir_path");
	g_token=find_cookie_value("token");
 
	g_file_path=path;
	//alert(g_file_path);
 // cgi_url= "/cgi-bin/cgi_ezserver?get_file_list="+path+"&flag="+Math.random();
  //cgi_url= "/server/get_folder_filelist?token="+escape(g_token)+ "&path=" +path+"&flag="+Math.random();
	cgi_url = "/server/channel_list_query?token="+escape(g_token)+"&flag="+Math.random();
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Get_Channel_List;
	 xmlHttp.send(null);
}
function get_channel_link(path)
{
	var vlc;
//	var keyword_buffer= parent.document.getElementById("keyword_buffer");
	var browser_name;

//	keyword_buffer.innerHTML= '<p align="center"><font color="#FFFFFF" size="3">'+path+'</font>';
	add_cookie_value("dir_path",path);
     	menu_main.innerHTML='<iframe frameborder="0" width=100% height=800 src="'+"ch_pictures.htm"+'"></iframe>';
 
}
function play_video()
{
 //  var v_url= parent.parent.document.getElementById("v_url");
   var menu_main= parent.document.getElementById("menu_main");
   var path;
   var strlength;
   var ezserver_ip_path;
   var pos;
   var str;
	var httpport;

   
	if (xmlHttp.readyState == 4) 
	{
		var response = xmlHttp.responseText;
		strlength=response.length;
//Windows and Linux difference	 
		strlength-=2;
//Windows and Linux difference	 
		//alert(response);
//		ezserver_ip_path=response.slice(0,strlength);

		httpport=find_cookie_value("httpport");

		ezserver_ip_path="http://"+location.hostname+":"+httpport;
//alert(ezserver_ip_path);
		pos=g_video_path.search("/Channel/");
		if (pos>0)
		{
			str=g_video_path.substring(pos+9,g_video_path.length);
//			path=ezserver_ip_path+'/'+str;
			path=ezserver_ip_path+str;
		}else
		{
//			path=ezserver_ip_path+'/'+g_video_path;
			path=ezserver_ip_path+g_video_path;
		}
//		alert(path);
	  	add_cookie_value("video_path",path);
   		menu_main.innerHTML='<iframe frameborder="0" width=99.8% height=800 src="'+"video.htm"+'"></iframe>';

	}

}

function call_play_video(path)
{
 
  //alert(path);

	g_video_path=path;
    	//var url = "/cgi-bin/cgi_ezserver?http_server_ip_port_inquery"+"&flag="+Math.random();
   	cgi_url= "/server/inquery_server_ip_htpport?token="+escape(g_token)+"&flag="+Math.random();

	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange =play_video ;
	xmlHttp.send(null);

 

}


function call_show_text(path)
{
 
     var menu_text= parent.document.getElementById("menu_text");
   //  alert(path);

  menu_text.innerHTML='<iframe frameborder="0" width=99.8% height=800 src="'+path+'"></iframe>';


 

}
function video_control_init() {
  // 1. Check for video support
 alert("11111");
  if( !document.createElement('video').canPlayType ) return;
  // 2. Get all video containers on the page
  alert("2222");
  var videos = document.querySelectorAll( 'div.video' ),
  videosLength = videos.length;
  // 3. Get every single video instance
  for( var i=0; i < videosLength; i++ ) {
    var root = videos[i];
    // 4. Get and create all needed elements
    video = root.querySelector( 'video' ),
    play = document.createElement( 'button' ),
    mute = document.createElement( 'button' );
    // 5. Turn off native video controls
    video.controls = false;
    // 6. Customise Play button behaviour
    play.innerHTML = play.title = 'Play';
    play.onclick = function() {
      if( video.paused ) {
        video.play();
        play.innerHTML = play.title = 'Pause';
      } else {
        video.pause();
        play.innerHTML = play.title = 'Play';
      }
    }
    // 7. Customise Mute button behaviour
    mute.innerHTML = mute.title = 'Mute';
    mute.onclick = function() {
      if( video.muted ) {
        video.muted = false;
        mute.innerHTML = mute.title = 'Mute';
      } else {
        video.muted = true;
        mute.innerHTML = mute.title = 'Unmute';
      }
    }
    // 8. Add custom controls to the video container
    root.appendChild( play );
    root.appendChild( mute );
  }
}

function show_drv_time_cur_time(timestamp)
{
	var cur_video_time=document.getElementById("cur_video_time");
	var dvr_video_time=document.getElementById("dvr_video_time");
	var d=new Date();
	
	var cur_sec=d.getTime();
//	alert(cur_sec);
	var cur_hours=d.getHours();
	var cur_minutes=d.getMinutes();
	var cur_seconds=d.getSeconds();
	var cur_time;

	var dvr_sec;
	var dvr_d;
	var dvr_hours;
	var dvr_minutes;
	var dvr_seconds;
	var dvr_time;
	g_cur_sec=cur_sec;

	g_dvr_sec+=1000;
	//dvr_sec=cur_sec-(g_current_timestamp-g_dvr_timestamp);
	dvr_d=new Date(g_dvr_sec);
	dvr_hours=dvr_d.getHours();
	dvr_minutes=dvr_d.getMinutes();
	dvr_seconds=dvr_d.getSeconds();
	
	
	cur_time= (cur_hours < 10 ? "0" + cur_hours : cur_hours) + ":" + (cur_minutes < 10 ? "0" + cur_minutes : cur_minutes) + ":" + (cur_seconds  < 10 ? "0" + cur_seconds : cur_seconds);
	if (bdvr_on)
	{
		cur_video_time.innerHTML='<p align="right"><font face="Arial" size="2" color="#FFFFFF">'+cur_time+'</font>';
	}
	

	dvr_time= (dvr_hours < 10 ? "0" + dvr_hours : dvr_hours) + ":" + (dvr_minutes < 10 ? "0" + dvr_minutes : dvr_minutes) + ":" + (dvr_seconds  < 10 ? "0" + dvr_seconds : dvr_seconds);
	dvr_video_time.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFFFF">'+dvr_time+'</font>';
	//g_current_timestamp+=1000;
	//g_dvr_timestamp+=1000;

}

function init_video()
{
	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	var flashMovie;
	var soundlevel = 10;
	var backword_button_id=document.getElementById("backword_button_id");
	var forward_button_id=document.getElementById("forward_button_id");
	var time_text_id=document.getElementById("time_text_id");
	
//	video_path=path.substring(43,path.length-11)+'?u=root&p=1234';
	g_current_timestamp=0;
	g_dvr_timestamp=0;
	bdvr_on=0;
	
  	path=find_cookie_value("video_path");
  	
  	
	//alert(path);
 	//g_user_id=find_cookie_value("userid");
  	//g_password=find_cookie_value("password");

  	//video_path=path+'?u='+g_user_id+':p='+g_password;
	g_token=find_cookie_value("token");
  	video_path=path+'?token='+g_token;
 	//alert(video_path);
 
 	BrowserDetect.init();
	browser_name=BrowserDetect.browser;
	if (video_path.search("flv")>0)
	{
		if (browser_name.search("Explorer")==0)
		{
			str='<object id=objswf width="640" height="480">'+
			'<param name="allowFullScreen" value="true" />'+
			'<param name="allowscriptaccess" value="always" />'+
			'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">'+ 
			'</embed>'+
			'</object>';	
		} else if (browser_name.search("Safari")==0)
		{
	
		}else
		{			
			str='<param name="allowFullScreen" value="true"></param>'+
			'<param name="allowscriptaccess" value="always"></param>'+
			'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">';
		}
			
					
			

	} else if (video_path.search("mp4")>0)
	{
		str='<video width="640" height="480" src="'+video_path+'" controls autoplay>';
	} else if (video_path.search("m3u8")>0)
	{
		if (browser_name.search("Safari")==0)
		{
			str='<video id=m3u8_video_id width="640" height="480" src="'+video_path+':server_ip_port='+location.host+'" controls autoplay>';
			//alert(str);
		}
		
	} else if (video_path.search("ch")>0)
	{
		 if (browser_name.search("Explorer")==0)
 		 {
 		 	str='<OBJECT id="VIDEO" width="640" height="480" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
			'<PARAM NAME="URL" VALUE="'+video_path+'">'+
			'<PARAM NAME="AutoStart" VALUE="True">'+
			'</OBJECT>';
			 
    		}else
		{
			str='<embed type="application/x-vlc-plugin" width="640" height="480" name="player" autoplay="yes" loop="no" '+
			'target="'+video_path+'">';
		}	
	}
	
	
	if (video_path.search("/ch")>0)
	{
		backid.innerHTML='<p align="right"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p>';
		time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>Current Time</b></font></p>';
		backword_button_id.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		forward_button_id.innerHTML='<p align="left"><input type="button" value=">>" onclick="javascript:dvr_for_backward(1);" name="B2" /></p>';
		g_current_timestamp=0;
		g_timer=setInterval(function(){show_drv_time_cur_time(0)},1000);
	}else
	{
		backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p>';
	}
	
	video_window=document.getElementById("video_window");

	//alert(str);
	video_window.innerHTML=str;
	


	
 //   flashMovie=getFlashMovieObject("objswf");
 //     flashMovie.pause();
	
	
}


//function dvr_response()
function dvr_for_backward(sign)
{

  	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	var to_live_button_id=document.getElementById("to_live_button_id");
	var time_text_id=document.getElementById("time_text_id");
	var timestamp;
	
	bdvr_on=1;
	
	//if (xmlHttp.readyState == 4) 
	//{	
	//	var response = xmlHttp.responseText;
		if (sign==0)
		{
			g_dvr_sec-=30*1000;
			forward_button_id.innerHTML='<p align="left"><input type="button" value=">>" onclick="javascript:dvr_for_backward(1);" name="B2" /></p>';

		}
		
		else if (sign==1)
		{
			g_dvr_sec+=30*1000;
			backword_button_id.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		}

	//	var request_time_stamp;
	//	alert(g_dvr_timestamp);
	//	alert(g_current_timestamp);
		//alert(g_skip_value);
		// FLV
//		request_time_stamp=parseFloat(response)+g_skip_value*1000;
//		g_dvr_timestamp=g_dvr_timestamp+g_skip_value*1000;
		if (g_dvr_sec>g_cur_sec)
		{
			g_dvr_sec=g_cur_sec;
			forward_button_id.innerHTML='';
			to_live_button_id.innerHTML='';
			cur_video_time.innerHTML='';
			time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>Cur Time</b></font></p>';
			bdvr_on=0;
		  	video_path=g_video_path;
		} else if (g_dvr_sec<=g_server_dvr_sec)
		{
			g_dvr_sec=g_server_dvr_sec;
			to_live_button_id.innerHTML='<p align="center"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
			time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>DVR Time</b></font></p>';
			//backword_button_id.innerHTML='';
			timestamp=g_dvr_sec-g_server_dvr_sec;
		  	video_path=g_video_path+":timestamp="+timestamp;
		}else
		{
			to_live_button_id.innerHTML='<p align="center"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
			time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>DVR Time</b></font></p>';
			timestamp=g_dvr_sec-g_server_dvr_sec;
		  	video_path=g_video_path+":timestamp="+timestamp;
		}
		
		
	//	alert(request_time_stamp);
		//path=find_cookie_value("video_path");
		//g_dvr_timestamp=request_time_stamp;
	  	
	  	
		//alert(path);
	 	//g_user_id=find_cookie_value("userid");
	  	//g_password=find_cookie_value("password");
	
	  	//video_path=path+'?u='+g_user_id+':p='+g_password;
		//g_token=find_cookie_value("token");
	 	//alert(video_path);
	 
	 	BrowserDetect.init();
		browser_name=BrowserDetect.browser;
		if (video_path.search("flv")>0)
		{
			if (browser_name.search("Explorer")==0)
			{
				str='<object width="640" height="480">'+
				'<param name="allowFullScreen" value="true" />'+
				'<param name="allowscriptaccess" value="always" />'+
				'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">'+ 
				'</embed>'+
				'</object>';	
			} else if (browser_name.search("Safari")==0)
			{
		
			}else
			{			
				str='<param name="allowFullScreen" value="true"></param>'+
				'<param name="allowscriptaccess" value="always"></param>'+
				'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">';
			}
				
						
				
	
		} else if (video_path.search("m3u8")>0)
		{
				str='<video width="640" height="480" src="'+video_path+':server_ip_port='+location.host+'" controls autoplay>';
			
		}else if (video_path.search("ch")>0)
		{
			 if (browser_name.search("Explorer")==0)
	 		 {
	 		 	str='<OBJECT id="VIDEO" width="640" height="480" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
				'<PARAM NAME="URL" VALUE="'+video_path+'">'+
				'<PARAM NAME="AutoStart" VALUE="True">'+
				'</OBJECT>';
				 
	    		}else
			{
				str='<embed type="application/x-vlc-plugin" width="640" height="480" name="player" autoplay="yes" loop="no" '+
				'target="'+video_path+'">';
			}	
		}
		
		
		if (video_path.search("/ch")>0)
		{
			backid.innerHTML='<p align="right"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p>';
		}else
		{
			backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p>';
		}
		
		video_window=document.getElementById("video_area");
	
		//alert(str);
		video_window.innerHTML=str;
		//to_live_button_id.innerHTML='<p align="right"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
		//time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>DVR Time</b></font></p>';
	//}

}
function dvr_to_live()
{

  	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	var time_text_id=document.getElementById("time_text_id");
	var cur_video_time=document.getElementById("cur_video_time");
	var timestamp;

	var to_live_button_id=document.getElementById("to_live_button_id");
	bdvr_on=0;
	//if (xmlHttp.readyState == 4) 
	//{	
	//	var response = xmlHttp.responseText;
	

		
	//	alert(request_time_stamp);
		//path=find_cookie_value("video_path");
		g_dvr_sec=g_cur_sec;
		timestamp=g_dvr_sec-g_server_dvr_sec;
		//g_token=find_cookie_value("token");
	  	//video_path=path+'?token='+g_token+":timestamp="+g_dvr_timestamp;
	 	//alert(video_path);
	  	//video_path=g_video_path+":timestamp="+timestamp;
	  	video_path=g_video_path;
	  	//alert(video_path);

	 
	 	BrowserDetect.init();
		browser_name=BrowserDetect.browser;
		if (video_path.search("flv")>0)
		{
			if (browser_name.search("Explorer")==0)
			{
				str='<object width="640" height="480">'+
				'<param name="allowFullScreen" value="true" />'+
				'<param name="allowscriptaccess" value="always" />'+
				'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">'+ 
				'</embed>'+
				'</object>';	
			} else if (browser_name.search("Safari")==0)
			{
		
			}else
			{			
				str='<param name="allowFullScreen" value="true"></param>'+
				'<param name="allowscriptaccess" value="always"></param>'+
				'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  width="640" height="480" flashvars="src='+video_path+'&autoPlay=true">';
			}
				
						
				
	
		} else if (video_path.search("m3u8")>0)
		{
			if (browser_name.search("Safari")==0)
			{
				str='<video width="640" height="480" src="'+video_path+':server_ip_port='+location.host+'" controls autoplay>';
				//alert(str);
			}
			
		}else if (video_path.search("ch")>0)
		{
			 if (browser_name.search("Explorer")==0)
	 		 {
	 		 	str='<OBJECT id="VIDEO" width="640" height="480" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
				'<PARAM NAME="URL" VALUE="'+video_path+'">'+
				'<PARAM NAME="AutoStart" VALUE="True">'+
				'</OBJECT>';
				 
	    		}else
			{
				str='<embed type="application/x-vlc-plugin" width="640" height="480" name="player" autoplay="yes" loop="no" '+
				'target="'+video_path+'">';
			}	
		}
		
		if (video_path.search("/ch")>0)
		{
			backid.innerHTML='<p align="right"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p>';
		}else
		{
			backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p>';
		}
		
		video_window=document.getElementById("video_area");
	
		//alert(str);
		video_window.innerHTML=str;
		to_live_button_id.innerHTML='';
		time_text_id.innerHTML='<p align="center"><font face="Arial" size="2" color="#FFFF00"><b>Current Time</b></font></p>';
		cur_video_time.innerHTML='';
		forward_button_id.innerHTML='';
	//}

}
/*
function dvr_for_backward(sign)
{
	//g_skip_value = parseInt(sign+document.getElementById("skip_value_id").value);
	g_skip_value = parseInt(sign+"10");

  	g_token=find_cookie_value("token");
    	cgi_url= "/player/query_player_timestamp?token="+escape(g_token)+"&flag="+Math.random();

	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange =dvr_response ;
	xmlHttp.send(null);
}
*/
/*
function init_video()
{
	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	
//	video_path=path.substring(43,path.length-11)+'?u=root&p=1234';
	
  	path=find_cookie_value("video_path");
  	
  	
	//alert(path);
 	//g_user_id=find_cookie_value("userid");
  	//g_password=find_cookie_value("password");

  	//video_path=path+'?u='+g_user_id+':p='+g_password;
	g_token=find_cookie_value("token");
  	video_path=path+'?token='+g_token;
 	//alert(video_path);
 
	str='<object width="720" height="480">'+
	'<param name="allowFullScreen" value="true" />'+
	'<param name="allowscriptaccess" value="always" />'+
	'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="720" height="480" flashvars="src='+video_path+'">'+ 
	'</embed>'+
	'</object>';	
	
//	str+='<param name="allowFullScreen" value="true"></param>'+
//	'<param name="allowscriptaccess" value="always"></param>'+
//	'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  width="720" height="480" flashvars="src='+video_path+'">';
	
//	str+='<source src="'+video_path+'" />';
	str+='<source src="'+video_path+'&server_ip_port='+location.host+'" />';
	
	if (video_path.search("/ch")>0)
	{
		backid.innerHTML='<p align="right"><a style="text-decoration: none" href="ch_pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p>';
	}else
	{
		backid.innerHTML='<p align="right"><a style="text-decoration: none" href="pictures.htm"><font face="Verdana" color="#FFFFFF" size="2">Back</font></a></p>';
	}
	
	video_window=document.getElementById("video_window");

	//alert(str);
	video_window.innerHTML='<video controls width="640" height="480">'+str+'</video>';
	video_control_init();
	
	
}
*/
/*
function dvr_for_backward(sign)
{
	var skip_value = document.getElementById("skip_value_id").value;
	var video_time=document.getElementById("video_time");

  	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	
	path=find_cookie_value("video_path");
  	
  	
	//alert(path);
 	//g_user_id=find_cookie_value("userid");
  	//g_password=find_cookie_value("password");

  	//video_path=path+'?u='+g_user_id+':p='+g_password;
	g_token=find_cookie_value("token");
  	video_path=path+'?token='+g_token+":skip="+sign+skip_value;
 	//alert(video_path);
   	//cgi_url= "/server/inquery_server_ip_htpport?token="+escape(g_token)+"&flag="+Math.random();

	xmlHttp.open("GET", video_path, true);
	//xmlHttp.onreadystatechange =play_video ;
	xmlHttp.send(null);
	video_time.innerHTML='<p align="right"><font face="Arial" size="2" color="#FFFF00"><b>DVR</b></font>';

 

}
*/