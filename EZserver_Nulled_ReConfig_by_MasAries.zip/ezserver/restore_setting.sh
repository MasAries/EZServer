#!/bin/sh
chmod 777 ezserver_config.txt
chmod 777 channel_definition.xml
chmod 777 auto_ezserver.sh
chmod 777 users/user_profile.xml
chmod 777 ch_config/group_definition.xml
tar xfvz ezserver_backup_setting.tar