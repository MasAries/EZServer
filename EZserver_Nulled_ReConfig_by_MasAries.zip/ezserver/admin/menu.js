var xmlHttp = new XMLHttpRequest();
var g_token=0;
var g_item=0;
var g_ch_src;
var g_status_item;
var g_refresh_item;
var g_chtype_item;
var g_ch_play_id_item;
var g_Channel_Edit_Mode=0;
var g_Channel_Updated=0;
var g_Movie_Edit_Mode=0;
var g_Movie_Updated=0;
var g_total_movie_no=1;
var HTML_Menu_Bar_Str;
var g_content;
var g_blacklist_remove_item;
var total_player_no=1000;
var g_macid;
var g_user_id;
var g_password;
var g_ch_no=1;
var g_video_itemid= Array();
var g_file_path;
var vlc_monitorTimerId = 0; 
var prevState = 0; 
var g_channel_no=1;
var g_remove_all_button;
var g_username;
var g_groupname_array = new Array();
var g_paymodel_array = Array("pre","post","free");
var g_total_group_no=0;
var g_timer;
var g_current_timestamp;
var g_dvr_timestamp=0;
var bdvr_on;
var g_video_path;
var g_server_dvr_sec;
var g_cur_sec;
var g_dvr_sec;
var g_delaytime_array = Array("Delay 5 sec.","Delay 10 sec.","Delay 20 sec.","Delay 30 sec.","Delay 40 sec.","Delay 50 sec.",
				"Delay 1 min.","Delay 3 min.","Delay 5 min.","Delay 10 min.","Delay 20 min.","Delay 30 min.","Delay 40 min.","Delay 50 min.",
				"Delay 1 hr.","Delay 2 hr.","Delay 3 hr.","Delay 4 hr.","Delay 5 hr.","Delay 6 hr.","Delay 7 hr.","Delay 8 hr.","Delay 9 hr.","Delay 10 hr.","Delay 11 hr.","Delay 12 hr.")
var g_delayvalue_array = Array("delay,5,sec.","delay,10,sec.","delay,20,sec.","delay,30,sec.","delay,40,sec.","delay,50,sec.",
				 "delay,1,min.","delay,3,min.","delay,5,min.","delay,10,min.","delay,20,min.","delay,30,min.","delay,40,min.","delay,50,min.",
				"delay,1,hr.","delay,2,hr.","delay,3,hr.","delay,4,hr.","delay,5,hr.","delay,6,hr.","delay,7,hr.","delay,8,hr.","delay,9,hr.","delay,10,hr.","delay,11,hr.","delay,12,hr.")
var g_server_timer;
var g_user_authorization_mode=1;
var g_httpport;
var g_System_timer=0;
var g_Query_Channel_Status_timer=0;
var bSystem_Inquery_Panel=0;
var g_reseller_no=0;
var g_player_filter_no=0;
var g_total_ch_no=0;
var g_balancer_server_no=0;
var g_edge_server_no=0;
var g_cur_year;
var g_cur_month;
var g_total_program_no=0;
var g_program_no=0;
var g_show_free_version=0;

var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "an unknown version";
		this.OS = this.searchString(this.dataOS) || "an unknown OS";
	},
	searchString: function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	},
	dataBrowser: [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{ 	string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera",
			versionSearch: "Version"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{		// for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "Explorer",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{ 		// for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
	],
	dataOS : [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			   string: navigator.userAgent,
			   subString: "iPhone",
			   identity: "iPhone/iPod"
	    },
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
	]


};
function change_link(new_url, new_width, new_height)
{
   var content= document.getElementById("content");
	if ((new_width>0) && (new_height>0))
	{
		content.innerHTML='<iframe frameborder="0" width='+new_width+' height='+new_height+' src="'+new_url+'"></iframe>';	
	} else
	{
		content.innerHTML='<iframe frameborder="0"'+new_url+'"></iframe>';	
	}
	

 
}


function find_cookie_value(keystr)
{ 
	var restring;
	var str;
	var substr1;
	var pos1, pos2;
	
	str=document.cookie;
	//alert(str);
	//alert(keystr);
	pos1=str.indexOf(keystr);
	//alert(pos1);
	subchar=str.substring(pos1+keystr.length,pos1+keystr.length+1);
	//alert(subchar);
	if (subchar==';')
	{
		return 0;
	}else
	{
		substr1=str.substring(pos1+keystr.length+2,str.length);
		//alert(substr1);
		pos1=substr1.indexOf(']');
		restring=substr1.substring(0,pos1);
		//alert(restring);
		return restring;
	}
	
	
}
function add_cookie_value(keystr,keyvalue)
{
	document.cookie=keystr+'=['+keyvalue+']';
}
function Clear_cookie()
{
	document.cookie='token'+'=';
	document.cookie='userid'+'=';
	document.cookie='password'+'=';
	document.cookie='dir_path'+'=';
	document.cookie='video_path'+'=';

}

function encode64(input) {  

 var keyStr = "ABCDEFGHIJKLMNOP" +  

              "QRSTUVWXYZabcdef" +  

              "ghijklmnopqrstuv" +  

              "wxyz0123456789+/" +  

              "=";  
  // input = escape(input);  

    var output = "";  

    var chr1, chr2, chr3 = "";  

    var enc1, enc2, enc3, enc4 = "";  

    var i = 0; 
  
 
    do {  

       chr1 = input.charCodeAt(i++);  

       chr2 = input.charCodeAt(i++);  

       chr3 = input.charCodeAt(i++);  

  

       enc1 = chr1 >> 2;  

       enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);  

       enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);  

       enc4 = chr3 & 63;  

  

    /*   if (isNaN(chr2)) {  

          enc3 = enc4 = 64;  

       } else if (isNaN(chr3)) {  

          enc4 = 64;  

       }  
*/
  

       output = output +  

          keyStr.charAt(enc1) +  

          keyStr.charAt(enc2) +  

          keyStr.charAt(enc3) +  

          keyStr.charAt(enc4);  
  
       chr1 = chr2 = chr3 = "";  

       enc1 = enc2 = enc3 = enc4 = "";  

    } while (i < input.length);  

  

    return output;  

}  
function Update_Setting() {
  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    alert(response);
   }
}     
function save_setting() {
  // Get the city and state from the web form
  var http_base_port = document.getElementById("http_base_port").value;
  var http_apps_port = document.getElementById("http_apps_port").value;
  var httpport = document.getElementById("httpport").value;
  var rtmpport = document.getElementById("rtmpport").value;
 //var vod_base_port = parent.document.getElementById("vod_base_port").value;
 var rtsp_base_port = document.getElementById("rtsp_base_port").value;
 var igmpip = document.getElementById("igmpip").value;
 var igmpport = document.getElementById("igmpport").value;
 
 var ch_input_buffer_no = document.getElementById("ch_input_buffer_no").value;
 var ch_streaming_prebuffer_no = document.getElementById("ch_streaming_prebuffer_no").value;
 var ch_streaming_bitrate_tolerance = document.getElementById("ch_streaming_bitrate_tolerance").value;
 var max_streaming_no = document.getElementById("max_streaming_no").value;
 var system_log = document.getElementById("system_log").value;
 var admin_system_log = document.getElementById("admin_system_log").value;
 
//  var url = "/cgi-bin/cgi_ezserver?httpport=" + escape(httpport)+
  	g_token=find_cookie_value("token");
  var url = "/server/save_config?token="+escape(g_token)+"&http_base_port=" + escape(http_base_port)+"&http_apps_port=" + escape(http_apps_port)+"&httpport=" + escape(httpport)+
  "&rtmpport=" + escape(rtmpport)+
  "&rtsp_base_port=" + escape(rtsp_base_port)+
  "&igmpip=" + igmpip+
  "&igmpport=" + escape(igmpport)+
  "&ch_input_buffer_no=" + escape(ch_input_buffer_no)+
  "&ch_streaming_prebuffer_no=" + escape(ch_streaming_prebuffer_no)+
  "&ch_streaming_bitrate_tolerance=" + escape(ch_streaming_bitrate_tolerance)+
  "&ch_streaming_bitrate_tolerance=" + escape(ch_streaming_bitrate_tolerance)+
  "&max_streaming_no=" + escape(max_streaming_no)+
  "&system_log=" + escape(system_log)+
  "&admin_system_log=" + escape(admin_system_log)+
  "&flag="+Math.random();
   var confirm_msg="Update Setting?";
	if (g_token!=0)
	{
		if (confirm(confirm_msg))
		{
		
		// Open a connection to the server
		xmlHttp.open("GET", url, true);
		
		// Setup a function for the server to run when it's done
		xmlHttp.onreadystatechange = Update_Setting;
		
		
		// Send the request
		xmlHttp.send(null);
		}
	}
}
function Init_System_Setting()
{
  if (xmlHttp.readyState == 4) {
    var response= xmlHttp.responseText.split("\r\n");

     document.getElementById("http_base_port").value =response[0];
     document.getElementById("http_apps_port").value =response[1];
    document.getElementById("httpport").value =response[2];
    g_httpport=response[2];
    document.getElementById("rtsp_base_port").value =response[3];
   document.getElementById("igmpip").value =response[4];
    document.getElementById("igmpport").value =response[5];
     document.getElementById("rtmpport").value =response[6];
    document.getElementById("ch_input_buffer_no").value =response[7];
    document.getElementById("ch_streaming_prebuffer_no").value =response[8];
    document.getElementById("ch_streaming_bitrate_tolerance").value =response[9];
    document.getElementById("max_streaming_no").value =response[10];
    document.getElementById("system_log").value =response[11];
    document.getElementById("admin_system_log").value =response[12];
 //   call_user_authorization_mode();

  //   show_uptime();
 
 	//g_server_timer=setInterval(function(){show_uptime()},300*1000);
 
  }
}
function callServer_Setting()
{
	
//	  var url = "/cgi-bin/cgi_ezserver?token="+escape(g_token)+"&value_creation"+"&flag="+Math.random();
	  var url = "/server/get_config?token="+escape(g_token)+"&flag="+Math.random();
var str;
  var streaming_port = parent.document.getElementById("content");
bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

	str='<p align="left" style="margin-top: 35; margin-left: 25"><table border="0" cellpadding="0" cellspacing="5" border>'+
		'<tr><td colspan="2">'+
		'<p align="left"><font face="Arial" size="2" color="#ff0000">Protocol Port No.</font>'+
		'</td></tr>'+
		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">1. Panel port:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="400" height="23"><p align="left"> <font face="Arial"> <font size="3"> <input type="text" name="http_base_port" id="http_base_port" size="5"/></font>'+
		'</font>'+ 
		'<font size="2">'+' --- Administrator Panel Port</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">2. Apps port:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="400" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="http_apps_port" id="http_apps_port" size="5"/></font>'+
		'</font>'+ 
		'<font size="2">'+' --- Rads Player Menu Port</font>'+ 
		'</td>'+
		'</tr>'+
				
		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">3. HTTP port:</font></p>'+
		'</td>'+
		'<td width="400" height="23"><p align="left"> <font size="2"> <input type="text" name="httpport" id="httpport" size="5"/></font>'+
		'<font size="2">'+' --- HTTP Streaming Port for players</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">4. RTMP port:</font></p>'+
		'</td>'+
		'<td width="400" height="23"><p align="left"> <font size="2"> <input type="text" name="rtmpport" id="rtmpport" size="5"/></font>'+
		'<font size="2">'+' --- RTMP Streaming Port for players</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">5. RTSP port:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="400" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="rtsp_base_port" id="rtsp_base_port" size="5"/></font>'+
		'</font>'+ 
		'<font size="2">'+' --- RTSP Streaming Port for players</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">6. Multicast IP :</font>'+
		'</p>'+
		'</td>'+      
		'<td width="500" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="igmpip" id="igmpip" size="16"/></font>'+
		'</font>'+ 
		'<font size="2">'+' --- Multicasting Streaming IP for players (0.0.0.0: disabled)</font>'+ 
		'</td>'+
		'</tr>'+
		
		'<tr>'+
		'<td width="120" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">7. Multicast port:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="400" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="igmpport" id="igmpport" size="5"/></font>'+
		'</font>'+ 
		'<font size="2">'+' --- Multicasting Streaming Port for players</font>'+ 
		'</td>'+
		'</tr>'+
		
		'<tr>'+
		'<td width="180" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">8. Channel Input Buffer No.:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="500" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="ch_input_buffer_no" id="ch_input_buffer_no" size="5"/></font>'+
		'</font>'+ 
		'<font size="2">'+' --- Panel will automatically refresh all channels after modification.</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="220" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">9. Channel Streaming Prebuffer No.:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="400" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="ch_streaming_prebuffer_no" id="ch_streaming_prebuffer_no" size="5"/></font>'+
		'</font>'+ 
		'<font size="2">'+' --- The value must be smaller than Channel Input Buffer No.</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="260" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">10. Channel Streaming Bitrate Tolerance:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="500" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="ch_streaming_bitrate_tolerance" id="ch_streaming_bitrate_tolerance" size="5"/></font>'+
		'</font>'+ 
		'<font size="2">'+' --- Value: 0.00~1.00 (ex. 0.00: SD video, 0.999: HD 25Mbps)</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="260" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">11. Max. Streaming No.:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="500" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="max_streaming_no" id="max_streaming_no" size="5"/></font>'+
		'</font>'+ 
		'<font size="2">'+
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="180" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">12. System Log Lines:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="400" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="system_log" id="system_log" size="5"/></font>'+
		'</font>'+
		'<font size="2">'+' --- Value: 0 (disabled), 1 (enabled), xxxx (xxxx lines)</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td width="260" height="23">'+
		'<p align="left" style="text-indent: 5"><font face="Arial" size="2">13. Admin. System Log Lines:</font>'+
		'</p>'+
		'</td>'+      
		'<td width="400" height="23"><p align="left"> <font face="Arial"> <font size="2"> <input type="text" name="admin_system_log" id="admin_system_log" size="5"/></font>'+
		'</font>'+
		'<font size="2">'+' --- Value: 0 (disabled), 1 (enabled), xxxx (xxxx lines)</font>'+ 
		'</td>'+
		'</tr>'+

		'<tr>'+
		'<td height="23">'+
		'</td>'+  
		'<td height="23">'+
		'<p align="left" style="margin-left: 13"><font face="Arial"><input type="button" value="Save" onclick="javascript:save_setting();" name="B1" />'+
		'</font>'+
		'</td>'+  
		'</tr>'+
		'</table>';
		streaming_port.innerHTML=str;

	   	g_token=find_cookie_value("token");
		if (g_token!=0)
		{
			 xmlHttp.open("GET", url, true);
			 xmlHttp.onreadystatechange = Init_System_Setting;
			 xmlHttp.send(null);
		}
	

}

function Init_Config()
{
  if (xmlHttp.readyState == 4) {
    var response= xmlHttp.responseText.split("\r\n");
    g_httpport=response[2];
    call_user_authorization_mode();
 
  }
}
function callServer_Init()
{	
	var url = "/server/get_config?token="+escape(g_token)+"&flag="+Math.random();
	
	g_token=find_cookie_value("token");
	if (g_token!=0)
	{
		 xmlHttp.open("GET", url, true);
		 xmlHttp.onreadystatechange = Init_Config;
		 xmlHttp.send(null);
	}
}

function login_return() {
  var login_msg = document.getElementById("login_msg");
  var login_area = document.getElementById("login_area");
  var login_status = parent.document.getElementById("login_status");
  var browser_name;
   	var content = parent.document.getElementById("content");

//  alert(login_status.innerHTML);
  
  // alert(id_check_flag);
  
  if (xmlHttp.readyState == 4) 
  {
    var response = xmlHttp.responseText;
   //alert(response);
  if (response.search("-1")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Arial"> <font size="2">*** parameter error***</font>';
    } else if (response.search("-2")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Arial"> <font size="2">*** Wrong User ID or Password***</font>';
    } else if (response.search("-3")>0)
    {
    	id_check_flag=0;
    	  login_status.innerHTML='<p><font face="Arial"> <font size="2">*** User ID Time Expired***</font>';
    } 
    else
    {
  	g_token=response.slice(6,response.length-2);
  	//alert(g_token);
  	//  document.cookie="token="+ g_token+"userid="+g_user_id+"password="+g_password+"#";
   	add_cookie_value("token",g_token);
  	add_cookie_value("userid",g_user_id);
  	add_cookie_value("password",g_password);
  	
 	    id_check_flag=1;

   	  login_status.innerHTML="<a href='javascript:void(0)' onclick=logout()>"+
  	  '<font face="Arial" size="2">Logout</font></a>'; 
  	   callServer_Init();
  	  /*          content.innerHTML='<table border="1" cellpadding="0" cellspacing="0" width="100%" height="451"><tr>'+
              '<td width="100%" height="449"><p align="center"><font face="Arial" size="5">Welcome to EZserver Management</font></td>'+
              '</tr></table>';
 */
//  	   init_video();
 //  	   callServer_CH_Inquery();
  	/*  BrowserDetect.init();
  	  browser_name=BrowserDetect.browser;
 	if (browser_name.search("Explorer")==0)
	{
  	  change_link("ovs.htm",900,400);
  	} else 	if (browser_name.search("Safari")==0)
  	{
  	  change_link("ovs_html5.htm",900,400);
   	} else
  	{
  	  change_link("ovs_html5.htm",900,400);
  	} */

    }
  }

}

function login(){
 var cgi_url;
 var encrypt_str;
 var userid_pass;
 g_user_id = document.getElementById("user_id").value;
 g_password = document.getElementById("password").value;
 userid_pass=g_user_id+':'+g_password;
 if (g_user_id=="root")
 {
	// alert(userid_pass);
	 encrypt_str=encode64(userid_pass);
	cgi_url = "/token/createtokenbased64?encrpty="+escape(encrypt_str)+"&flag="+Math.random();
	 login_status.innerHTML='login...';
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = login_return;
	 xmlHttp.send(null);
  }else
 {
 	alert("Non Adminstrator ID");
 }
 	


}

function login_out_return() {
  
var ch_up_flag=0;
  
  if (xmlHttp.readyState == 4) 
  {
    var response = xmlHttp.responseText;
	//var content = parent.document.getElementById("content");
	//var detail = parent.document.getElementById("detail");

 /*        ch_up_flag=find_cookie_value("ch_up_flag");       
         if (ch_up_flag==1)
         {
         	callezserver_refresh_channel();
         	Clear_Channel_update();
         }*/
      /*   content.innerHTML='<table border="1" cellpadding="0" cellspacing="0" width="100%" height="451"><tr>'+
              '<td width="100%" height="449"><p align="center"><font face="Arial" size="5">EZserver Management</font></td>'+
              '</tr></table>';
         detail.innerHTML='';
*/
    	g_token=0;	
    	if (g_System_timer>0)
    	{
    		clearInterval(g_System_timer);
    		clearInterval(g_Query_Channel_Status_timer);
    	}
 	Clear_cookie();
     login_status.innerHTML="";
//     menu_main_title.innerHTML="";
	init();
 
   }

}
function logout()
{
	var cgi_url;
  var login_status = document.getElementById("login_status");
   var confirm_msg="Logout?";
  var cookieStr;
  var firstpos;
  var endpos;
 	var content = parent.document.getElementById("content");

	 if (confirm(confirm_msg))
	{
  
          // content.innerHTML='<p align="center" style="margin-top: 30"><font face="Arial" size="5">EZserver Management</font>';
	content.innerHTML='';
     	g_token=find_cookie_value("token");
  	g_user_id=find_cookie_value("userid");
  	g_password=find_cookie_value("password");
 	 cgi_url = "/token/destroytoken?token="+escape(g_token)+"&flag="+Math.random();
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = login_out_return;
	 xmlHttp.send(null);

	}
}

function init() {

       menu_top.innerHTML='<center><table border="0" cellpadding="0" cellspacing="0">'+
	   '<tr><td>'+
	   '<p style="text-indent: 5"><font face="Arial" size="2">User ID: </font></p>'+
	   '</td>'+      
	   '<td>'+ 
	   '<font face="Arial"> <font size="2"> <input type="text" name="user_id" id="user_id" size="20" value="root"/></font></font>'+
	   '</td>'+
	   
	   
	   '<td>'+
	   '<p style="text-indent: 5"><font face="Arial" size="2">Password: </font></p>'+    
	   '</td>'+ 
	                                   
	   '<td> <font face="Arial" size="2"> <input type="password" name="password" id="password" size="20"/></font><font face="Arial"><font size="2"></font>'+
	   '<input type="button" value="OK" onclick="javascript:login();" name="B1" /></font>'+
	   '</td></tr>'+
	   '</table>';
	   Clear_cookie();
	 //  streaming_port();

}
function show_drv_time_cur_time(timestamp)
{
	var cur_video_time=document.getElementById("cur_video_time");
	var dvr_video_time=document.getElementById("dvr_video_time");
	var d=new Date();
	
	var cur_sec=d.getTime();
	var cur_hours=d.getHours();
	var cur_minutes=d.getMinutes();
	var cur_seconds=d.getSeconds();
	var cur_time;

	var dvr_sec;
	var dvr_d;
	var dvr_hours;
	var dvr_minutes;
	var dvr_seconds;
	var dvr_time;
	g_cur_sec=cur_sec;

	g_dvr_sec+=1000;
	//dvr_sec=cur_sec-(g_current_timestamp-g_dvr_timestamp);
	dvr_d=new Date(g_dvr_sec);
	dvr_hours=dvr_d.getHours();
	dvr_minutes=dvr_d.getMinutes();
	dvr_seconds=dvr_d.getSeconds();
		
	
	cur_time= (cur_hours < 10 ? "0" + cur_hours : cur_hours) + ":" + (cur_minutes < 10 ? "0" + cur_minutes : cur_minutes) + ":" + (cur_seconds  < 10 ? "0" + cur_seconds : cur_seconds);
	if (bdvr_on)
	{
		cur_video_time.innerHTML='<p align="center"><font face="Arial" size="2">'+cur_time+'</font>';
	}
	

	dvr_time= (dvr_hours < 10 ? "0" + dvr_hours : dvr_hours) + ":" + (dvr_minutes < 10 ? "0" + dvr_minutes : dvr_minutes) + ":" + (dvr_seconds  < 10 ? "0" + dvr_seconds : dvr_seconds);
	dvr_video_time.innerHTML='<p align="center"><font face="Arial" size="2">'+dvr_time+'</font>';
	//g_current_timestamp+=1000;
	//g_dvr_timestamp+=1000;

}
function Get_Dvr_Starting_Time()
{
 if (xmlHttp.readyState == 4) {
  	var response = xmlHttp.responseText;
  	var d=new Date(response);
 //	alert(response);

  	g_server_dvr_sec=d.getTime();
  //	alert(g_server_dvr_sec);
  	
   	
  }
}
function play_channel(chno,container,dvr_on)
{
	var vlc;
	var vlc_id;
	var flash_video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	//var video_area = parent.document.getElementById("video_area");
	//var backword_button_id = parent.document.getElementById("backword_button_id");
	//var forward_button_id = parent.document.getElementById("forward_button_id");
	//var to_live_button_id = parent.document.getElementById("to_live_button_id");
	//var cur_video_time = parent.document.getElementById("cur_video_time");
	//var time_text_id = parent.document.getElementById("time_text_id");
	var httpport = g_httpport;
//	var httpport = 8000;

	var  cgi_url;
	var d=new Date();
	var VideoWindow;

	bQuery_Channel_Status=0;
 	//cgi_url= "/server/query_dvr_starting_time?token="+escape(g_token)+ "&ch_no=" +chno+"&flag="+Math.random();
	//xmlHttp.open("GET", cgi_url, true);
	//xmlHttp.onreadystatechange = Get_Dvr_Starting_Time;
	//xmlHttp.send(null);
	//video_area.innerHTML='';
	
	//g_cur_sec=d.getTime();
	//g_dvr_sec=g_cur_sec;
//	video_path=path.substring(43,path.length-11)+'?u=root&p=1234';
	
  	//path=find_cookie_value("video_path");
  	
  	
	//alert(path);
 	//g_user_id=find_cookie_value("userid");
  	//g_password=find_cookie_value("password");

  	//video_path=path+'?u='+g_user_id+':p='+g_password;
	g_token=find_cookie_value("token");
 // 	video_path="http://"+location.host+"/ch"+chno+".flv"+'?token='+g_token;
 //alert(container);
	BrowserDetect.init();
	browser_name=BrowserDetect.browser;
	if (container.search("flv")>=0)
	{// flash	
  			video_path="http://"+location.hostname+":"+httpport+"/ch"+chno+"."+container+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
  		
	}	
	else if (container.search("ch")>=0)
	{
		if (browser_name.search("Safari")==0)
		{ // Apple	
 	 		video_path="http://"+location.hostname+":"+httpport+"/ch"+chno+"."+"m3u8"+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
 		} else
  		{ // VLC 
	 		video_path="http://"+location.hostname+":"+httpport+"/"+chno+"."+container+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
  		}
	}
  	g_video_path=video_path;
 	// alert(video_path);
 	//g_current_timestamp=0;
	//g_dvr_timestamp=0;
	//bdvr_on=0;
	 str="<head><title>CH "+chno+"</title><link rel='stylesheet' type='text/css' href='menu.css'/>"+'<script src="menu.js"></script></head><body>';
//	str='';
 	if (video_path.search("flv")>0)
	{
		if (browser_name.search("Explorer")==0)
		{
			str+='<object>'+
			'<param name="allowFullScreen" value="true" />'+
			'<param name="allowscriptaccess" value="always" />'+
			'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="300" height="220" flashvars="src='+video_path+'&autoPlay=true">'+ 
			'</embed>'+
			'</object>';	
		} else 
		{
			str+='<param name="allowFullScreen" value="true"></param>'+
			'<param name="allowscriptaccess" value="always"></param>'+
			'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" autoplay="yes" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="300" height="220" flashvars="src='+video_path+'&autoPlay=true">';
		
	
		}
	}else if (video_path.search("m3u8")>0)
	{ // APPLIE
	 	str+='<video src="'+video_path+'" controls autoplay>';
	 		//alert(str);

	}else if (video_path.search("ch")>0) 
	{ // VLC
		  
		 if (browser_name.search("Explorer")==0)
 		 {
 		 	str+='<OBJECT id="VIDEO" width="100%" height="100%" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
			'<PARAM NAME="URL" VALUE="'+video_path+'">'+
			'<PARAM NAME="AutoStart" VALUE="True">'+
			'</OBJECT>';
			 
    		}else
		{
			str+='<embed type="application/x-vlc-plugin" name="player" autoplay="yes" loop="no" '+
			'target="'+video_path+'">';
		}		

	}
	
	str+='</body>';
	
	/* 
	time_text_id.innerHTML='<p align="center"><font face="Arial" size="2">Current Time</font></p>';
	if (dvr_on)
	{
		backword_button_id.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		//forward_button_id.innerHTML='<p align="left"><input type="button" value=">>" onclick="javascript:dvr_for_backward(1);" name="B2" /></p>';
	}else
		{
			backword_button_id.innerHTML='';
			forward_button_id.innerHTML='';
			to_live_button_id.innerHTML='';
			cur_video_time.innerHTML='';
		}
		
	g_current_timestamp=0;
	g_timer=setInterval(function(){show_drv_time_cur_time(0)},1000);
	*/
	 VideoWindow= window.open("", "", "top=100, left=100, width=320, height=240"); 
	VideoWindow.document.write(str); 

	//flash_video_window=document.getElementById("flash_video_window");

	//alert(str);
	
	
}
function play_movie(movie_no)
{
	 var movie_src_id="moviesrc"+movie_no; 
	 var movie_src_name="moviename"+movie_no; 
	var movie_src;
	 var movie_name;
	var vlc;
	var vlc_id;
	var flash_video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	 g_item_name=document.getElementById(movie_src_id);
	 movie_src = g_item_name.value;
	 g_item_name=document.getElementById(movie_src_name);
	 movie_name = g_item_name.value;
	//var video_area = parent.document.getElementById("video_area");
	//var backword_button_id = parent.document.getElementById("backword_button_id");
	//var forward_button_id = parent.document.getElementById("forward_button_id");
	//var to_live_button_id = parent.document.getElementById("to_live_button_id");
	//var cur_video_time = parent.document.getElementById("cur_video_time");
	//var time_text_id = parent.document.getElementById("time_text_id");
	var httpport = g_httpport;
//	var httpport = 8000;

	var  cgi_url;
	var d=new Date();
	var VideoWindow;

 	//cgi_url= "/server/query_dvr_starting_time?token="+escape(g_token)+ "&ch_no=" +chno+"&flag="+Math.random();
	//xmlHttp.open("GET", cgi_url, true);
	//xmlHttp.onreadystatechange = Get_Dvr_Starting_Time;
	//xmlHttp.send(null);
	//video_area.innerHTML='';
	
	//g_cur_sec=d.getTime();
	//g_dvr_sec=g_cur_sec;
//	video_path=path.substring(43,path.length-11)+'?u=root&p=1234';
	
  	//path=find_cookie_value("video_path");
  	
  	
	//alert(path);
 	//g_user_id=find_cookie_value("userid");
  	//g_password=find_cookie_value("password");

  	//video_path=path+'?u='+g_user_id+':p='+g_password;
	g_token=find_cookie_value("token");
 // 	video_path="http://"+location.host+"/ch"+chno+".flv"+'?token='+g_token;
 //alert(container);
	BrowserDetect.init();
	browser_name=BrowserDetect.browser;
	video_path="http://"+location.hostname+":"+httpport+"/"+movie_name+'?token='+g_token+':server_ip_port='+location.hostname+":"+httpport;
  	g_video_path=video_path;
 	//alert(video_path);
 	//g_current_timestamp=0;
	//g_dvr_timestamp=0;
	//bdvr_on=0;
	 str="<head><title>Movie "+movie_no+"</title><link rel='stylesheet' type='text/css' href='menu.css'/>"+'<script src="menu.js"></script></head><body>';
//	str='';
//alert(movie_src);
 	if (movie_src.search("flv")>0)
	{
		if (browser_name.search("Explorer")==0)
		{
			str+='<object>'+
			'<param name="allowFullScreen" value="true" />'+
			'<param name="allowscriptaccess" value="always" />'+
			'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="300" height="220" flashvars="src='+video_path+'&autoPlay=true">'+ 
			'</embed>'+
			'</object>';	
		} else 
		{
			str+='<param name="allowFullScreen" value="true"></param>'+
			'<param name="allowscriptaccess" value="always"></param>'+
			'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" autoplay="yes" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="300" height="220" flashvars="src='+video_path+'&autoPlay=true">';
		
	
		}
	}else if (movie_src.search("mp4")>0)
	{ // APPLIE
	 	str+='<video src="'+video_path+'" controls autoplay>';
	 		//alert(str);

	}else if (movie_src.search("ts")>0) 
	{ // VLC
		  
		 if (browser_name.search("Explorer")==0)
 		 {
 		 	str+='<OBJECT id="VIDEO" width="100%" height="100%" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
			'<PARAM NAME="URL" VALUE="'+video_path+'">'+
			'<PARAM NAME="AutoStart" VALUE="True">'+
			'</OBJECT>';
			 
    		}else
		{
			str+='<embed type="application/x-vlc-plugin" name="player" autoplay="yes" loop="no" '+
			'target="'+video_path+'">';
		}		

	}
	
	str+='</body>';
	
	
	 VideoWindow= window.open("", "", "top=100, left=100, width=320, height=240"); 
	VideoWindow.document.write(str); 

	
	
}
//function dvr_response()
function dvr_for_backward(sign)
{

  	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	var to_live_button_id=document.getElementById("to_live_button_id");
	var time_text_id=document.getElementById("time_text_id");
	var cur_video_time=document.getElementById("cur_video_time");
	var timestamp;
	
	bdvr_on=1;
	
	//if (xmlHttp.readyState == 4) 
	//{	
	//	var response = xmlHttp.responseText;
		if (sign==0)
		{
			g_dvr_sec-=30*1000;
			forward_button_id.innerHTML='<p align="left"><input type="button" value=">>" onclick="javascript:dvr_for_backward(1);" name="B2" /></p>';

		}
		
		else if (sign==1)
		{
			g_dvr_sec+=30*1000;
			backword_button_id.innerHTML='<p align="right"><input type="button" value="<<" onclick="javascript:dvr_for_backward(0);" name="B1" /></p>';
		}


	//	var request_time_stamp;
	//	alert(g_dvr_timestamp);
	//	alert(g_current_timestamp);
		//alert(g_skip_value);
		// FLV
//		request_time_stamp=parseFloat(response)+g_skip_value*1000;
//		g_dvr_timestamp=g_dvr_timestamp+g_skip_value*1000;
		path=g_video_path;
		if (g_dvr_sec>g_cur_sec)
		{
			g_dvr_sec=g_cur_sec;
			forward_button_id.innerHTML='';
			to_live_button_id.innerHTML='';
			cur_video_time.innerHTML='';
			time_text_id.innerHTML='<p align="center"><font face="Arial" size="2">Cur Time</font></p>';
			bdvr_on=0;
		  	video_path=path;

		} else if (g_dvr_sec<=g_server_dvr_sec)
		{
			g_dvr_sec=g_server_dvr_sec;
			to_live_button_id.innerHTML='<p align="center"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
			time_text_id.innerHTML='<p align="center"><font face="Arial" size="2">DVR Time</font></p>';
			timestamp=g_dvr_sec-g_server_dvr_sec;	
		  	video_path=path+":timestamp="+timestamp;
			//backword_button_id.innerHTML='';
		}else
		{
			to_live_button_id.innerHTML='<p align="center"><input type="button" value="To Live" onclick="javascript:dvr_to_live();" name="B2" /></p>';
			time_text_id.innerHTML='<p align="center"><font face="Arial" size="2">DVR Time</font></p>';
			timestamp=g_dvr_sec-g_server_dvr_sec;
		  	video_path=path+":timestamp="+timestamp;

		}
		
	//	alert(request_time_stamp);
		//g_dvr_timestamp=request_time_stamp;
	  	
	  	
		//alert(path);
	 	//g_user_id=find_cookie_value("userid");
	  	//g_password=find_cookie_value("password");
	
	  	//video_path=path+'?u='+g_user_id+':p='+g_password;
		g_token=find_cookie_value("token");
		//timestamp=g_dvr_sec-g_server_dvr_sec;

	  	//video_path=path+":timestamp="+timestamp;
	 	//alert(video_path);
	 
	 	BrowserDetect.init();
		browser_name=BrowserDetect.browser;
		if (video_path.search("flv")>0)
		{
			if (browser_name.search("Explorer")==0)
			{
				str='<object>'+
				'<param name="allowFullScreen" value="true" />'+
				'<param name="allowscriptaccess" value="always" />'+
				'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" flashvars="src='+video_path+'&autoPlay=true">'+ 
				'</embed>'+
				'</object>';	
			} else if (browser_name.search("Safari")==0)
			{
		
			}else
			{			
				str='<param name="allowFullScreen" value="true"></param>'+
				'<param name="allowscriptaccess" value="always"></param>'+
				'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true"  flashvars="src='+video_path+'&autoPlay=true">';
			}
				
						
				
	
		} else if (video_path.search("m3u8")>0)
		{
			if (browser_name.search("Safari")==0)
			{
				str='<video src="'+video_path+':server_ip_port='+location.host+'" controls autoplay>';
			}
			
		}else if (video_path.search("ch")>0) 
		{
			 if (browser_name.search("Explorer")==0)
	 		 {
	 		 	str='<OBJECT id="VIDEO" width="100%" height="100%" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
				'<PARAM NAME="URL" VALUE="'+video_path+'">'+
				'<PARAM NAME="AutoStart" VALUE="True">'+
				'</OBJECT>';
				 
	    		}else
			{
				str='<embed type="application/x-vlc-plugin" name="player" autoplay="yes" loop="no" '+
				'target="'+video_path+'">';
			}	
		}
		
		

		
		video_window=document.getElementById("video_area");
	
		//alert(str);
		video_window.innerHTML=str;
	//}

}
function dvr_to_live()
{

  	var video_window;
	var path;
	var video_path;
	var browser_name;
	var str;
	var pos1;
	var browser_name;
	var backid=document.getElementById("back");
	var time_text_id=document.getElementById("time_text_id");
	var cur_video_time=document.getElementById("cur_video_time");
	var timestamp;

	var to_live_button_id=document.getElementById("to_live_button_id");
	bdvr_on=0;
	//if (xmlHttp.readyState == 4) 
	//{	
	//	var response = xmlHttp.responseText;
	

		
	//	alert(request_time_stamp);
		path=g_video_path;
		g_dvr_sec=g_cur_sec;
		timestamp=g_dvr_sec-g_server_dvr_sec;
		g_token=find_cookie_value("token");
//	  	video_path=path+":timestamp="+timestamp;
	  	video_path=path;
	 	//alert(video_path);

	 
	 	BrowserDetect.init();
		browser_name=BrowserDetect.browser;
		if (video_path.search("flv")>0)
		{
			if (browser_name.search("Explorer")==0)
			{
				str='<object>'+
				'<param name="allowFullScreen" value="true" />'+
				'<param name="allowscriptaccess" value="always" />'+
				'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" flashvars="src='+video_path+'&autoPlay=true">'+ 
				'</embed>'+
				'</object>';	
			} else if (browser_name.search("Safari")==0)
			{
		
			}else
			{			
				str='<param name="allowFullScreen" value="true"></param>'+
				'<param name="allowscriptaccess" value="always"></param>'+
				'<embed src="http://fpdownload.adobe.com/strobe/FlashMediaPlayback.swf" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" flashvars="src='+video_path+'&autoPlay=true">';
			}
				
						
				
	
		} else if (video_path.search("m3u8")>0)
		{
			if (browser_name.search("Safari")==0)
			{
				str='<video src="'+video_path+':server_ip_port='+location.host+'" controls autoplay>';
				//alert(str);
			}
			
		}else if (video_path.search("ch")>0) 
		{ // VLC
			  
			 if (browser_name.search("Explorer")==0)
	 		 {
	 		 	str='<OBJECT id="VIDEO" width="100%" height="100%" CLASSID="CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6" type="application/x-oleobject">'+
				'<PARAM NAME="URL" VALUE="'+video_path+'">'+
				'<PARAM NAME="AutoStart" VALUE="True">'+
				'</OBJECT>';
				 
	    		}else
			{
				str='<embed type="application/x-vlc-plugin" name="player" autoplay="yes" loop="no" '+
				'target="'+video_path+'">';
			}		
		}
		

		
		video_window=document.getElementById("video_area");
	
		//alert(str);
		video_window.innerHTML=str;
		to_live_button_id.innerHTML='';
		time_text_id.innerHTML='<p align="center"><font face="Arial" size="2">Current Time</font></p>';
		cur_video_time.innerHTML='';
		forward_button_id.innerHTML='';
	//}

}

function get_system_log()
{
    if (xmlHttp.readyState == 4) {

	var response = xmlHttp.responseText;
	var content = parent.document.getElementById("content");
	var str;
	var str1;
	var iret;
	var totalret=0;
	var HTML_str='';
	var i=1;
	

	str1=response;
	while (1)
	{
		iret=str1.search("\n");
		//alert(iret);
		totalret+=iret;
	 	if (iret==-1) break;
	 	str=str1.substring(0,iret);
	 	//alert(str);
	 	HTML_str=HTML_str+'<font face="Arial" size="2">'+str+'</font><br>';
	 	str1=response.substring(totalret+i,response.length);
	 	//alert(str1);
	 	i++;
	 	
	}
	
	
	content.innerHTML='<table><tr><td><p align="right"><font face="Arial" size="2"><a href='+"'javascript:void(0)'"+' onclick=callServer_get_system_log()>Refresh</a></font></td></tr>'+
	'<tr><td>'+HTML_str+'</td></tr>'+
	'<tr><td><p align="right"><font face="Arial" size="2"><a href='+"'javascript:void(0)'"+' onclick=callServer_get_system_log()>Refresh</a></font></td></tr>'+
	'</table>';
	//alert(content.innerHTML);
    }
}

function callServer_get_system_log() {
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 	var content = parent.document.getElementById("content");
	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

 	content.innerHTML='<table><tr><td><p align="right"><font face="Arial" size="2">Loading</font></p></td></tr></table>';
	if (g_token!=0)
	{
		cgi_url="/log/system.log"			
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = get_system_log;
		xmlHttp.send(null);
	}

}


function CH_inquery()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var ch_no;
    var ch_name;
    var ch_src;
    var ch_icon;
    var ch_category;
    var ch_type;
    var ch_play_id;
    var ch_title="<p>"+"Channel List"+"</p>";
    var ch_list;
    var i=0;
    var j=0;
    var box_no=1;
	var ch_active_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
    var content = parent.document.getElementById("content");
  //var detail = parent.document.getElementById("detail");
  var dvr_folder_on=0;
	var refresh_keyword=null;
	var play_keyword=null;
	var save_keyword=null;
	var add_keyword=null;
	var del_keyword=null;
	var more_keyword=null;


	content.innerHTML="";
//	detail.innerHTML="";
	

	 HTML_str= '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="20" align="center"><font face="Arial" size="2">No.</font></td>'+
	      '<td width="100" align="center"><font face="Arial" size="2">Channel Name</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Media Source</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Category</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Type</font></td>'+
	      '<td width="120" align="center"><font face="Arial" size="2">Status (per 10 sec.)</font></td>'+
 	 '</tr>'+'<tr><td  colspan="7"><hr size="1" color="#66FFFF"></td></tr>';
 	
	while (1)
	{
 	 	if (response[i]==0) break;
		//alert(response[i]);
	 	strlength=response[i].length;
	 	//alert(strlength);
   	    	ch_no=response[i].slice(3,strlength);
     	 	strlength=response[i+1].length;
   	    	ch_name=response[i+1].slice(5,strlength);
     	 	strlength=response[i+2].length;
   	    	ch_src=response[i+2].slice(4,strlength);
     	 	strlength=response[i+3].length;
   	    	ch_icon=response[i+3].slice(5,strlength);
     	 	strlength=response[i+4].length;
 	    	ch_category=response[i+4].slice(9,strlength);
     	 	strlength=response[i+5].length;
   	    	ch_type=response[i+5].slice(5,strlength);
   	    	if (ch_type.search("dvr")>=0)
   	    	{
   	    		dvr_folder_on=1;
   	    	}else
   	    	{
   	    		dvr_folder_on=0;
   	    	}
   	    	strlength=response[i+6].length;
  	    	ch_status=response[i+6].slice(7,strlength);
  	    	//alert(ch_status);
   	    		
   	    	

 		i=i+7;
		ch_active_no++;
		HTML_str=HTML_str+
		   '<tr>'+
		      '<td width="20" align="center"><font face="Arial" size="2">'+ch_no+'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="chname"'+
	 		' id=chname'+ch_no+
	 		' size="14" value="'+
	 		ch_name+'"/></font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="chsrc"'+
	 		' id=chsrc'+ch_no+
	 		' size="30" value="'+
	 		ch_src+'"/></font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="chicon"'+
	 		' id=chicon'+ch_no+
	 		' size="30" value="'+
	 		ch_icon+'"/></font></td>'+
		      '<td width="10" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="chcategory"'+
	 		' id=chcategory'+ch_no+
	 		' size="10" value="'+
	 		ch_category+'"/></font></td>'+
	 		
		      '<td width="60" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		
			' <select size="1" name="chtype" id=chtype'+ch_no+'>';
			//alert(ch_type);
			if (ch_type.search("live")>=0)
			{
				HTML_str+='<option selected="selected" value="live">'+"Live"+'</option>'+
				'<option value="movie">'+"Movie"+'</option>'+
				'<option value="dvr">'+"DVR"+'</option>'+
				'<option value="hls">'+"HLS"+'</option>'+
				'<option value="inactive">'+"Inactive"+'</option>';
				for (j=0;j<g_delaytime_array.length;j++)
				{
					
					HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
					
				}
			}else if (ch_type.search("delay")>=0)
			{
				for (k=0;k<g_delaytime_array.length;k++)
				{
					
					if (ch_type.search(g_delayvalue_array[k])==0)
					{
						break;
					}
				}
				//alert(k);
				HTML_str+='<option value="live">'+"Live"+'</option>'+
				'<option value="movie">'+"Movie"+'</option>'+
				'<option value="dvr">'+"DVR"+'</option>'+
				'<option value="hls">'+"HLS"+'</option>'+
				'<option value="inactive">'+"Inactive"+'</option>';
				for (j=0;j<g_delaytime_array.length;j++)
				{
					if (j!=k)
					{
						HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
					}else 
					{
						HTML_str+='<option selected="selected" value="'+g_delayvalue_array[k]+'">'+g_delaytime_array[k]+'</option>';
					}
											
				}
			}else if (ch_type.search("dvr")>=0)
			{
				HTML_str+='<option selected="selected" value="dvr">'+"DVR"+'</option>'+
				'<option value="live">'+"Live"+'</option>'+
				'<option value="movie">'+"Movie"+'</option>'+
				'<option value="hls">'+"HLS"+'</option>'+
				'<option value="inactive">'+"Inactive"+'</option>';
				for (j=0;j<g_delaytime_array.length;j++)
				{
					
					HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
					
				}
			}else if (ch_type.search("inactive")>=0)
			{
				HTML_str+='<option selected="selected" value="inactive">'+"Inactive"+'</option>'+
				'<option value="live">'+"Live"+'</option>'+
				'<option value="movie">'+"Movie"+'</option>'+
				'<option value="hls">'+"HLS"+'</option>'+
				'<option value="dvr">'+"DVR"+'</option>';
				for (j=0;j<g_delaytime_array.length;j++)
				{
					
					HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
					
				}
			}else if (ch_type.search("movie")>=0)
			{
				HTML_str+='<option selected="selected" value="movie">'+"Movie"+'</option>'+
				'<option value="live">'+"Live"+'</option>'+
				'<option value="dvr">'+"DVR"+'</option>'+
				'<option value="hls">'+"HLS"+'</option>'+
				'<option value="inactive">'+"Inactive"+'</option>';
				for (j=0;j<g_delaytime_array.length;j++)
				{
					
					HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
					
				}
			}else if (ch_type.search("hls")>=0)
			{
				HTML_str+='<option selected="selected" value="hls">'+"HLS"+'</option>'+
				'<option value="live">'+"Live"+'</option>'+
				'<option value="dvr">'+"DVR"+'</option>'+
				'<option value="movie">'+"Movie"+'</option>'+
				'<option value="inactive">'+"Inactive"+'</option>';
				for (j=0;j<g_delaytime_array.length;j++)
				{
					
					HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
					
				}
			}
			HTML_str+='</select></font></td>';
			
			//alert(ch_status);		

			if (ch_status.search("OFF")>=0)
			{
		      		HTML_str+='<td id=chstatus'+ch_no+' width="200" align="center"><font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font></td>';
			}else
			{
		      		HTML_str+='<td id=chstatus'+ch_no+' width="200" align="center"><font face="Arial" size="2">'+ch_status+'</font></td>';

			}
				
			if (g_Channel_Edit_Mode==0)
			{
				save_keyword="Save";
				refresh_keyword="Refresh";
				play_keyword="Play";
				more_keyword="More";
				
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=callServer_CH_Update("'+ch_no+'")>'+
				' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
				HTML_str+='<td id=refreshchannelbutton'+ch_no+' width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Refresh_A_Channel("'+ch_no+'")>'+
				' <font face="Arial" size="2">'+refresh_keyword+'</font></a></td>';
				
				HTML_str+='<td id=morechannelbutton'+ch_no+' width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Query_A_Channel_More("'+ch_no+'")>'+
				' <font face="Arial" size="2">'+more_keyword+'</font></a></td>';
				
				HTML_str+='<td width="150" align="left" id=ch_play_id'+ch_no+'>';
				if (ch_src.search("rtmp")==0)
				{
				    HTML_str+="<a href='javascript:void(0)'"+
				    ' onclick=play_channel("'+ch_no+'",'+'"flv"'+','+dvr_folder_on+')>'+
				    ' <font face="Arial" size="2">'+play_keyword+'</font></a></td>';
				}
				else
				{
				    HTML_str+="<a href='javascript:void(0)'"+
				    ' onclick=play_channel("'+ch_no+'",'+'"ch"'+','+dvr_folder_on+')>'+
				    ' <font face="Arial" size="2">'+play_keyword+'</font></a></td>';
				}
				//alert(HTML_str);
			}else
			{
				save_keyword="Save";
				add_keyword="Add";
				del_keyword="Del";
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=callServer_CH_Update("'+ch_no+'")>'+
				' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Del_Channel("'+ch_no+'")>'+
				' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Add_New_Channel("'+ch_no+'")>'+
				' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
			}
							
			HTML_str+='</tr>';
			
				
		    
		box_no++;
     }
      //    content.innerHTML=HTML_str;
      // alert(menu_main.innerHTML);
      
      if (g_Channel_Edit_Mode==0)
      {
      	      HTML_Menu_Bar_Str='<td id=ch_menu_bar width=80% align="right">';
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callServer_CH_Inquery()>"+
	      '<font size="2" face="Arial">Query</font></a>'+'&nbsp&nbsp&nbsp';
	      
 	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=call_Edit_Channel()>"+
	      '<font size="2" face="Arial">Add/Del</font></a>'+'&nbsp&nbsp&nbsp';
	      
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=call_export_channel_definition()>"+
	      '<font size="2" face="Arial">Export</font></a>'+'&nbsp&nbsp&nbsp';

 	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callezserver_refresh_channel()>"+
	      '<font size="2" face="Arial">Refresh All</font></a>';
	      
	      
 	   //   HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callServer_group_Inquery()>"+
	     // '<font size="2" face="Arial">Group</font></a>';
	}else
	{
	      HTML_Menu_Bar_Str='<td id=ch_menu_bar width=80% align="right">';
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=ezserver_quit_channel()>"+
	      '<font size="2" face="Arial">Quit</font></a>';
	      // +'&nbsp&nbsp&nbsp';

	  //    HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callezserver_quit_refresh_channel()>"+
	   //   '<font size="2" face="Arial">Quit & Refresh</font></a>';
	}
		      
	      HTML_Menu_Bar_Str+='</td>';

  	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ ch_active_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';
	g_total_ch_no=ch_active_no;
	// alert(g_Query_Channel_Status_timer);
	if (g_Channel_Edit_Mode==1)
	{
		bQuery_Channel_Status=0;
	}else
	{	
		bQuery_Channel_Status=1;
		if (g_Query_Channel_Status_timer==0)
		{
			g_Query_Channel_Status_timer=setInterval(function(){callServer_Query_Channel_Status_Timer()},10*1000);
			// alert(g_Query_Channel_Status_timer);
		}
	}
	

 
 }

 
}
function Button_Server_System_Inquery() {
    //document.getElementById('home_button').onmousedown=function () {
    document.getElementById('homebutton').src = 
    "home_down.PNG";
   // };
    document.getElementById('home_button').onmouseout=function () {
    document.getElementById('homebutton').src = 
    "home.PNG";
    };
    callServer_System_Inquery();
}
function Button_Server_CH_Inquery() {
   // document.getElementById('channel_button').onmousedown=function () {
    document.getElementById('channelbutton').src = 
    "channel_down.PNG";
    //};
    document.getElementById('channel_button').onmouseout=function () {
    document.getElementById('channelbutton').src = 
    "channel.PNG";
    };
    callServer_CH_Inquery();
}
function Button_Server_EPG_Inquery() {
   // document.getElementById('channel_button').onmousedown=function () {
    document.getElementById('epgbutton').src = 
    "epg_down.PNG";
    //};
    document.getElementById('epg_button').onmouseout=function () {
    document.getElementById('epgbutton').src = 
    "epg.PNG";
    };
    callServer_Get_EPG_Info();
}
function Button_Server_Movie_Inquery() {
   // document.getElementById('movie_button').onmousedown=function () {
    document.getElementById('moviebutton').src = 
    "movie_down.PNG";
    //};
    document.getElementById('movie_button').onmouseout=function () {
    document.getElementById('moviebutton').src = 
    "movie.PNG";
    };
    callServer_Movie_Inquery();
}
function Button_get_all_user() {
   // document.getElementById('user_button').onmousedown=function () {
    document.getElementById('userbutton').src = 
    "user_down.PNG";
    //};
    document.getElementById('user_button').onmouseout=function () {
    document.getElementById('userbutton').src = 
    "user.PNG";
    };
    call_get_all_user();
}
function Button_Server_group_Inquery() {
   // document.getElementById('bouquet_button').onmousedown=function () {
    document.getElementById('bouquetbutton').src = 
    "bouquet_down.PNG";
    //};
    document.getElementById('bouquet_button').onmouseout=function () {
    document.getElementById('bouquetbutton').src = 
    "bouquet.PNG";
    };
    callServer_group_Inquery();
}
function Button_active_player_info() {
    //document.getElementById('player_button').onmousedown=function () {
    document.getElementById('playerbutton').src = 
    "player_down.PNG";
    //};
    document.getElementById('player_button').onmouseout=function () {
    document.getElementById('playerbutton').src = 
    "player.PNG";
    };
    calllist_active_player_info();
}
function Button_alert_player_info() {
    //document.getElementById('alert_player_button').onmousedown=function () {
    document.getElementById('alertplayerbutton').src = 
    "alert_player_down.PNG";
    //};
    document.getElementById('alert_player_button').onmouseout=function () {
    document.getElementById('alertplayerbutton').src = 
    "alert_player.PNG";
    };
    calllist_alert_player_info();
}
function Button_get_reseller() {
    //document.getElementById('reseller_button').onmousedown=function () {
    document.getElementById('resellerbutton').src = 
    "reseller_down.PNG";
    //};
    document.getElementById('reseller_button').onmouseout=function () {
    document.getElementById('resellerbutton').src = 
    "reseller.PNG";
    };
    call_get_reseller();
}
function Button_player_filter() {
    //document.getElementById('player_filter_button').onmousedown=function () {
    document.getElementById('playerfilterbutton').src = 
    "player_filter_down.PNG";
    //};
    document.getElementById('player_filter_button').onmouseout=function () {
    document.getElementById('playerfilterbutton').src = 
    "player_filter.PNG";
    };
    call_player_filter();
}
function Button_mac_blocker() {
    //document.getElementById('mac_blocker_button').onmousedown=function () {
    document.getElementById('macblockerbutton').src = 
    "mac_blocker_down.PNG";
    //};
    document.getElementById('mac_blocker_button').onmouseout=function () {
    document.getElementById('macblockerbutton').src = 
    "mac_blocker.PNG";
    };
    call_mac_blocker();
}
function Button_Server_blacklist_Inquery() {
    //document.getElementById('blacklist_button').onmousedown=function () {
    document.getElementById('blacklistbutton').src = 
    "blacklist_down.PNG";
    //};
    document.getElementById('blacklist_button').onmouseout=function () {
    document.getElementById('blacklistbutton').src = 
    "blacklist.PNG";
    };
    callServer_blacklist_Inquery();
}
function Button_Server_balancer_Inquery() {
    //document.getElementById('blacklist_button').onmousedown=function () {
    document.getElementById('balancerbutton').src = 
    "balancer_down.PNG";
    //};
    document.getElementById('balancer_button').onmouseout=function () {
    document.getElementById('balancerbutton').src = 
    "balancer.PNG";
    };
    callServer_balancer_Inquery();
}
function Button_Setting() {
    //document.getElementById('setting_button').onmousedown=function () {
    document.getElementById('settingbutton').src = 
    "setting_down.PNG";
    //};
    document.getElementById('setting_button').onmouseout=function () {
    document.getElementById('settingbutton').src = 
    "setting.PNG";
    };
    callServer_Setting();
}
function Button_restart() {
    //document.getElementById('restart_button').onmousedown=function () {
    document.getElementById('restartbutton').src = 
    "restart_down.PNG";
    //};
    document.getElementById('restart_button').onmouseout=function () {
    document.getElementById('restartbutton').src = 
    "restart.PNG";
    };
    callserver_restart();
}
function Button_shutdown() {
    //document.getElementById('shutdown_button').onmousedown=function () {
    document.getElementById('shutdownbutton').src = 
    "shutdown_down.PNG";
    //};
    document.getElementById('shutdown_button').onmouseout=function () {
    document.getElementById('shutdownbutton').src = 
    "shutdown.PNG";
    };
    callserver_shutdown();
}
function Button_get_system_log() {
    //document.getElementById('log_button').onmousedown=function () {
    document.getElementById('logbutton').src = 
    "log_down.PNG";
    //};
    document.getElementById('log_button').onmouseout=function () {
    document.getElementById('logbutton').src = 
    "log.PNG";
    };
    callServer_get_system_log();
}
function callServer_CH_Inquery() {
 // var ch_no = document.getElementById("ch_no").value;
  var content = parent.document.getElementById("content");

 //var url = "/cgi-bin/cgi_eziptv?channel_inquery="+escape(ch_no)+"&flag="+Math.random();
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;
   	g_token=find_cookie_value("token");
	if (g_token!=0)
	{
		cgi_url = "/server/query_channel_list?token="+escape(g_token)+"&flag="+Math.random();
		content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Channel Information Loading...<p>';
		
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = CH_inquery;
		xmlHttp.send(null);
	}

}
function Query_Channel_Status()
{
	var ch_src_status;
	var ch_status;
	var item_name;
	var old_ch_status;
	var i;
	var strlength;
	
	if (xmlHttp.readyState == 4) {
		var response = xmlHttp.responseText.split("\r\n");
		for (i=0;i<g_total_ch_no;i++)
		{
		    	strlength=response[i].length;
		    	if (response[0].length==0)
		    	{
				clearInterval(g_Query_Channel_Status_timer);
				g_Query_Channel_Status_timer=0;
		    		break;
		    	}
		    	ch_status=response[i].slice(7,strlength);
		    	//alert(ch_status);
		
			ch_src_status="chstatus"+(i+1); 
			item_name=document.getElementById(ch_src_status);
			//alert(item_name.innerHTML);
			 if (ch_status.search("OFF")>=0)
			{
		      		item_name.innerHTML='<font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font>';
			}else
			{
		      		item_name.innerHTML='<font face="Arial" size="2">'+ch_status+'</font>';
		      		
			}


			
				
		}
	}
}

function callServer_Query_Channel_Status_Timer() {
 	var cgi_url;
	
	bSystem_Inquery_Panel=0; 
	if (bQuery_Channel_Status==0)
	{
		clearInterval(g_Query_Channel_Status_timer);
		g_Query_Channel_Status_timer=0;
		// alert("Clear Status Timer");
	}else
	{
	   	g_token=find_cookie_value("token");
		if (g_token!=0)
		{
			cgi_url = "/server/query_status_channel_list?token="+escape(g_token)+"&flag="+Math.random();
			
			
			xmlHttp.open("GET", cgi_url, true);
			xmlHttp.onreadystatechange = Query_Channel_Status;
			xmlHttp.send(null);
		}
	}

}
function Cancel_Add_New_EPG()
{
	var content = parent.document.getElementById("content");
	content.innerHTML=g_content;
}
function Add_EPG_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    var item_save;
    var item_add;
    var item_del;
    var ch_no=g_ch_no;
    if (response==1)
    {
    	g_total_program_no++;
  //  	alert("Sucessfully, Refresh Channels to active all channels");
 	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	// callServer_CH_Inquery();
	item_save=document.getElementById("save_id_button");
	item_del=document.getElementById("del_id_button");
	item_add=document.getElementById("add_id_button");
	
	item_save.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
			' onclick=callServer_Update_EPG_Info("'+g_program_no+'")>'+
	      	      ' <font face="Arial" size="2">Save</font></a></td>';
	item_del.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
			' onclick=call_Del_EPG_Info("'+g_program_no+'")>'+
	      	      ' <font face="Arial" size="2">Del</font></a></td>';
	item_add.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
			' onclick=call_Add_New_EPG_Info("'+g_program_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>';
	      	      
  } else
    {
   	alert("Failed to Add EPG");
 		callServer_Get_EPG_Info();
   }
	      	      
	/*if (g_Channel_Edit_Mode==0) 
	{
	}*/
	
    }
}
function call_Add_EPG(program_no)
{

	var ch_no= document.getElementById("cur_ch_no").value;
	var starttime_id="starttime"+program_no;
	var starttime;
	var stoptime_id="stoptime"+program_no;
	var stoptime;
	var program_title_id="program_title"+program_no;
	var program_title;
	var program_descrption_id="program_descrption"+program_no;
	var program_descrption;
	var program_icon_id="program_icon"+program_no;
	var program_icon;
	var program_rec_id="program_rec"+program_no;
	var program_rec;

	var confirm_msg;
 	var cgi_url;

	g_item=document.getElementById(starttime_id);
	starttime = g_item.value;
	if (starttime.length==0)
	{
		alert("Start Time is empty");
		return;
	}else if (starttime.length!=19)
	{
		alert("Start Time length is not 19 (YYYY/MM/DD hh:mm:ss)")
		return;
	}
	
		
	g_item=document.getElementById(stoptime_id);
	stoptime = g_item.value;
	if (stoptime.length==0)
	{
		alert("Stop Time is empty");
		return;
	}else if (stoptime.length!=19)
	{
		alert("Stop Time length is not 19 (YYYY/MM/DD hh:mm:ss)")
		return;
	}
	
	g_item=document.getElementById(program_descrption_id);
	program_descrption = g_item.value;

	g_item=document.getElementById(program_icon_id);
	program_icon = g_item.value;
	
	g_item=document.getElementById(program_rec_id);
	program_rec = g_item.value;

	g_item=document.getElementById(program_title_id);
	program_title = g_item.value;
	if (program_title.length==0)
	{
		alert("Program Title is empty");
		return;
	}


	bSystem_Inquery_Panel=0; 
	bQuery_Channel_Status=0;
   	g_token=find_cookie_value("token");

	g_ch_no=ch_no;
	g_program_title=program_title;
	g_program_no=program_no;
	confirm_msg="Add Program "+program_no+" Information?";
	cgi_url = "/server/add_epg_info?token="+escape(g_token)+"&ch_no="+escape(ch_no)+"&program_no=" + escape(program_no)+"&starttime=" + escape(starttime)+ "&stoptime=" + escape(stoptime)+ "&program_title=" + escape(program_title)+ "&program_descrption=" + escape(program_descrption)+ "&program_icon=" + escape(program_icon)+ "&program_rec=" + escape(program_rec)+"&flag="+Math.random();
 if (confirm(confirm_msg))
 {
	
	//alert(cgi_url);
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_EPG_Info;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (adding...)";
	 g_item.style.backgroundColor = "#ff0000";
 }


}
function call_Add_New_EPG_Info(program_no)
{
	var content = parent.document.getElementById("content");
	g_content=content.innerHTML;
	var program_active_no=g_total_program_no;
	var i, m;
	var starttime_id;
	var starttime;
	var stoptime_id;
	var stoptime;
	var program_title_id;
	var program_title;
	var program_descrption_id;
	var program_descrption;
	var program_icon_id;
	var program_icon;
	var program_rec_id;
	var program_rec;
	var HTML_Menu_Bar_Str="";
	var cur_month;
	var cur_temp_year;
	var cur_year;

	
	program_active_no++;
	cur_year=g_cur_year;
	cur_month=g_cur_month;
	//alert(program_active_no);
 
	HTML_Menu_Bar_Str='<td width="10%" align="right"><font face="Arial" size="2">Channel No.:</font></td>';
	HTML_Menu_Bar_Str+='<td width="5%" align="center">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_ch_no" id=cur_ch_no>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+g_ch_no+'">'+g_ch_no+'</option>';
	for (i=1;i<=g_total_ch_no;i++)
	{
		if (i!=g_ch_no)
		{
			HTML_Menu_Bar_Str+='<option value="'+i+'">'+i+'</option>';
		}
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

	HTML_Menu_Bar_Str+='<td width="5%" align="center">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_year" id=cur_year>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+g_cur_year+'">'+g_cur_year+'</option>';
	cur_temp_year=g_cur_year-1;
	for (i=0;i<5;i++)
	{
		index_year=cur_temp_year+i;
		if (g_cur_year!=index_year)
		{
			HTML_Menu_Bar_Str+='<option value="'+index_year+'">'+index_year+'</option>';
		}
		
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

 	HTML_Menu_Bar_Str+='<td width="5%" align="right">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_month" id=cur_month>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+cur_month+'">'+cur_month+'</option>';
	for (i=1;i<13;i++)
	{
		if (i!=cur_month)
		{
			if (i<10)
			{
				HTML_Menu_Bar_Str+='<option value="0'+i+'">0'+i+'</option>';
				
			}else
			{
				HTML_Menu_Bar_Str+='<option value="'+i+'">'+i+'</option>';
			}
		}
		
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

     HTML_Menu_Bar_Str+='<td width=80% align="left">';
      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callServer_Get_EPG_Info_By_Month()>"+
      '<font size="2" face="Arial">Query</font></a>'+'&nbsp&nbsp&nbsp';
      HTML_Menu_Bar_Str+='</td>';
      HTML_str=  '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="60" align="center"><font face="Arial" size="2">No.</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Start Time(YYYY/MM/DD hh:mm:ss)</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Stop Time(YYYY/MM/DD hh:mm:ss)</font></td>'+
	      '<td width="260" align="center"><font face="Arial" size="2">Program Title</font></td>'+
	      '<td width="400" align="center"><font face="Arial" size="2">Program Description</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Record Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Record</font></td>'+
 	 '</tr>'+'<tr><td  colspan="8"><hr size="1" color="#66FFFF"></td></tr>';
 	 for (i=1,m=1;i<=program_active_no;i++,m++)
	{
		starttime_id="starttime"+m; 
		//alert(starttime_id);
		item_name=document.getElementById(starttime_id);
		// alert(item_name.value);
		starttime = item_name.value;
		
		stoptime_id="stoptime"+m; 
		item_name=document.getElementById(stoptime_id);
		// alert(item_name.value);
		stoptime = item_name.value;
		
		program_title_id="program_title"+m; 
		item_name=document.getElementById(program_title_id);
		// alert(item_name.value);
		program_title = item_name.value;
		
		program_descrption_id="program_descrption"+m; 
		item_name=document.getElementById(program_descrption_id);
		// alert(item_name.value);
		program_descrption = item_name.value;

		program_icon_id="program_icon"+m; 
		item_name=document.getElementById(program_icon_id);
		// alert(item_name.value);
		program_icon = item_name.value;

		program_rec_id="program_rec"+m; 
		item_name=document.getElementById(program_rec_id);
		// alert(item_name.value);
		program_rec = item_name.value;
		HTML_str=HTML_str+
		   '<tr>'+
		      '<td width="60" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="starttime"'+
	 		' id=starttime'+i+
	 		' size="19" value="'+
	 		starttime+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="stoptime"'+
	 		' id=stoptime'+i+
	 		' size="19" value="'+
	 		stoptime+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_title"'+
	 		' id=program_title'+i+
	 		' size="20" value="'+
	 		program_title+'"/></font></td>'+
		      '<td width="40" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_descrption"'+
	 		' id=program_descrption'+i+
	 		' size="40" value="'+
	 		program_descrption+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_icon"'+
	 		' id=program_icon'+i+
	 		' size="20" value="'+
	 		program_icon+'"/></font></td>';
	 		
	 		HTML_str=HTML_str+
	 		'<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <select size="1" name="program_rec" '+'id=program_rec'+i+'>';
	 		if (program_rec=="ON")
	 		{
		      
		      		// alert(program_rec);
		 		HTML_str=HTML_str+'<option selected="selected" value="'+"ON"+'">'+"ON"+'</option>'+
		 		'<option value="'+"OFF"+'">'+"OFF"+'</option>'+'</select></font></td>';
	 		}else
 			{
		      		// alert(program_rec);
		 		HTML_str=HTML_str+'<option selected="selected" value="'+"OFF"+'">'+"OFF"+'</option>'+
		 		'<option value="'+"ON"+'">'+"ON"+'</option>'+'</select></font></td>';
 			}
	 		
	 		if (m==program_no)
			{
				save_keyword="Save";
				add_keyword="Add";
				del_keyword="Del";
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=callServer_Update_EPG_Info("'+i+'")>'+
				' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Del_EPG_Info("'+i+'")>'+
				' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Add_New_EPG_Info("'+i+'")>'+
				' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
				
				i++;
				starttime=cur_year+'/'+cur_month+'/'+'01 00:00:00';
				stoptime=cur_year+'/'+cur_month+'/'+'01 00:00:00';

			//	starttime="";
			//	stoptime="";
				program_title="";
				program_descrption="";
				program_icon="";
				
				HTML_str=HTML_str+
			   	'<tr>'+
			      '<td width="60" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
			      '<td width="20" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="starttime"'+
		 		' id=starttime'+i+
		 		' size="19" value="'+
		 		starttime+'"/></font></td>'+
			      '<td width="20" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="stoptime"'+
		 		' id=stoptime'+i+
		 		' size="19" value="'+
		 		stoptime+'"/></font></td>'+
			      '<td width="20" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="program_title"'+
		 		' id=program_title'+i+
		 		' size="20" value="'+
		 		program_title+'"/></font></td>'+
			      '<td width="40" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="program_descrption"'+
		 		' id=program_descrption'+i+
		 		' size="40" value="'+
		 		program_descrption+'"/></font></td>'+
			      '<td width="20" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="program_icon"'+
		 		' id=program_icon'+i+
		 		' size="20" value="'+
		 		program_icon+'"/></font></td>'+
		 		'<td width="20" align="center">'+
				' <font face="Arial" size="2">'+
		 		' <select size="1" name="program_rec" '+'id=program_rec'+i+'>'+
				'<option selected="selected" value="ON">ON</option>'+
				 '<option value="OFF">OFF</option>'+
				'</select></font></td>';
			      	HTML_str+='<td id=save_id_button width="80" align="center">'+
				      "<a href='javascript:void(0)'"+
				      ' onclick=call_Add_EPG("'+i+'")>'+
			      	      ' <font face="Arial" size="2">Add</font></a></td>'+
			      	      
				      '<td id=del_id_button width="80" align="center">'+		      
				      "<a href='javascript:void(0)'"+
				      ' onclick=Cancel_Add_New_EPG()>'+
			      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+
	
				      '<td id=add_id_button width="80" align="center">'+		      
				      ' <font face="Arial" size="2"></font></a></td>';
			}else
			{
				save_keyword="Save";
				add_keyword="Add";
				del_keyword="Del";
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=callServer_Update_EPG_Info("'+i+'")>'+
				' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Del_EPG_Info("'+i+'")>'+
				' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Add_New_EPG_Info("'+i+'")>'+
				' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
			}
							
			HTML_str+='</tr>';
		
	}
	
	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ program_active_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';
	//g_total_program_no=program_active_no;
}

function Get_EPG_Info()
{
 
 if (xmlHttp.readyState == 4) {


	var response = xmlHttp.responseText.split("\r\n");
	var ch_no;
	var program_no=0;
	var starttime;
	var stoptime;
	var program_title;
	var program_descrption;
	var program_icon;
	var program_rec;
	var i=0;
	var j=0;
	var HTML_str='';
	var strlength=0;
	var content = parent.document.getElementById("content");
	var save_keyword=null;
	var add_keyword=null;
	var del_keyword=null;
	//var cur_year;
	var cur_month;
	var HTML_Menu_Bar_Str="";
	var index_year;
	var d=new Date();
	var cur_year=d.getFullYear();
	var cur_temp_year;

	//cur_year=g_cur_year;
	cur_month=g_cur_month;
	content.innerHTML="";
	

	 HTML_str= '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="60" align="center"><font face="Arial" size="2">No.</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Start Time<br>YYYY/MM/DD<br>hh:mm:ss</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Stop Time<br>YYYY/MM/DD<br>hh:mm:ss</font></td>'+
	      '<td width="260" align="center"><font face="Arial" size="2">Program Title</font></td>'+
	      '<td width="400" align="center"><font face="Arial" size="2">Program Description</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Record Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Record</font></td>'+
 	 '</tr>'+'<tr><td  colspan="8"><hr size="1" color="#66FFFF"></td></tr>';
 	
	while (1)
	{
 	 	if (response[i]==0) break;
		//alert(response[i]);
	 	strlength=response[i].length;
	 	//alert(strlength);
   	    	starttime=response[i].slice(10,strlength);
     	 	strlength=response[i+1].length;
   	    	stoptime=response[i+1].slice(9,strlength);
     	 	strlength=response[i+2].length;
   	    	program_title=response[i+2].slice(6,strlength);
     	 	strlength=response[i+3].length;
 	    	program_descrption=response[i+3].slice(12,strlength);
     	 	strlength=response[i+4].length;
 	    	program_icon=response[i+4].slice(5,strlength);
     	 	strlength=response[i+5].length;
 	    	program_rec=response[i+5].slice(4,strlength);
 	    	i=i+6;
		program_no++;
		HTML_str=HTML_str+
		   '<tr>'+
		      '<td width="60" align="center"><font face="Arial" size="2">'+program_no+'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="starttime"'+
	 		' id=starttime'+program_no+
	 		' size="19" value="'+
	 		starttime+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="stoptime"'+
	 		' id=stoptime'+program_no+
	 		' size="19" value="'+
	 		stoptime+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_title"'+
	 		' id=program_title'+program_no+
	 		' size="20" value="'+
	 		program_title+'"/></font></td>'+
		      '<td width="40" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_descrption"'+
	 		' id=program_descrption'+program_no+
	 		' size="40" value="'+
	 		program_descrption+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_icon"'+
	 		' id=program_icon'+program_no+
	 		' size="20" value="'+
	 		program_icon+'"/></font></td>';
	 		
	 		HTML_str=HTML_str+
	 		'<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <select size="1" name="program_rec" '+'id=program_rec'+program_no+'>';
	 		if (program_rec==1)
	 		{
		      
		 		HTML_str=HTML_str+'<option selected="selected" value="'+"ON"+'">'+"ON"+'</option>'+
		 		'<option value="'+"OFF"+'">'+"OFF"+'</option>'+'</select></font></td>';
	 		}else
 			{
		 		HTML_str=HTML_str+'<option selected="selected" value="'+"OFF"+'">'+"OFF"+'</option>'+
		 		'<option value="'+"ON"+'">'+"ON"+'</option>'+'</select></font></td>';
 			}
	 			
	 	
			save_keyword="Save";
			add_keyword="Add";
			del_keyword="Del";
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=callServer_Update_EPG_Info("'+program_no+'")>'+
			' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Del_EPG_Info("'+program_no+'")>'+
			' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Add_New_EPG_Info("'+program_no+'")>'+
			' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
		
							
			HTML_str+='</tr>';
			
				
		    
     }
	if (i==0)
	{
		i=1;
		starttime=cur_year+'/'+cur_month+'/'+'01 00:00:00';
		stoptime=cur_year+'/'+cur_month+'/'+'01 00:00:00';
		program_title="";
		program_descrption="";
		program_icon="";
		
		HTML_str=HTML_str+
	   	'<tr>'+
	      '<td width="60" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
	      '<td width="20" align="center">'+
		' <font face="Arial" size="2">'+
		' <input type="text" name="starttime"'+
		' id=starttime'+i+
		' size="19" value="'+
		starttime+'"/></font></td>'+
	      '<td width="20" align="center">'+
		' <font face="Arial" size="2">'+
		' <input type="text" name="stoptime"'+
		' id=stoptime'+i+
		' size="19" value="'+
		stoptime+'"/></font></td>'+
	      '<td width="20" align="center">'+
		' <font face="Arial" size="2">'+
		' <input type="text" name="program_title"'+
		' id=program_title'+i+
		' size="20" value="'+
		program_title+'"/></font></td>'+
	      '<td width="40" align="center">'+
		' <font face="Arial" size="2">'+
		' <input type="text" name="program_descrption"'+
		' id=program_descrption'+i+
		' size="40" value="'+
		program_descrption+'"/></font></td>'+
	      '<td width="20" align="center">'+
		' <font face="Arial" size="2">'+
		' <input type="text" name="program_icon"'+
		' id=program_icon'+i+
		' size="20" value="'+
		program_icon+'"/></font></td>'+
	      '<td width="20" align="center">'+
		' <font face="Arial" size="2">'+
 		' <select size="1" name="program_rec" '+'id=program_rec'+i+'>'+
		'<option selected="selected" value="ON">ON</option>'+
		 '<option value="OFF">OFF</option>'+
		'</select></font></td>';
		
	      	HTML_str+='<td id=save_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_EPG("'+i+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>'+
	      	      
		      '<td id=del_id_button width="80" align="center">'+		      
		      ' <font face="Arial" size="2"></font></a></td>'+
	
		      '<td id=add_id_button width="80" align="center">'+		      
		      ' <font face="Arial" size="2"></font></a></td>';
	}

      //    content.innerHTML=HTML_str;
      //alert(HTML_str);
	HTML_Menu_Bar_Str+='<td width="10%" align="right"><font face="Arial" size="2">Channel No.:</font></td>';
	HTML_Menu_Bar_Str+='<td width="5%" align="center">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_ch_no" id=cur_ch_no>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+g_ch_no+'">'+g_ch_no+'</option>';
	for (i=1;i<=g_total_ch_no;i++)
	{
		if (i!=g_ch_no)
		{
			HTML_Menu_Bar_Str+='<option value="'+i+'">'+i+'</option>';
		}
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

	HTML_Menu_Bar_Str+='<td width="5%" align="center">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_year" id=cur_year>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+g_cur_year+'">'+g_cur_year+'</option>';
	cur_temp_year=g_cur_year-1;
	for (i=0;i<5;i++)
	{
		index_year=cur_temp_year+i;
		if (g_cur_year!=index_year)
		{
			HTML_Menu_Bar_Str+='<option value="'+index_year+'">'+index_year+'</option>';
		}
		
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

 	HTML_Menu_Bar_Str+='<td width="5%" align="right">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_month" id=cur_month>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+cur_month+'">'+cur_month+'</option>';
	for (i=1;i<13;i++)
	{
		if (i!=cur_month)
		{
			if (i<10)
			{
				HTML_Menu_Bar_Str+='<option value="0'+i+'">0'+i+'</option>';
				
			}else
			{
				HTML_Menu_Bar_Str+='<option value="'+i+'">'+i+'</option>';
			}
		}
		
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

     HTML_Menu_Bar_Str+='<td width=80% align="left">';
      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callServer_Get_EPG_Info_By_Month()>"+
      '<font size="2" face="Arial">Query</font></a>'+'&nbsp&nbsp&nbsp';
      HTML_Menu_Bar_Str+='</td>';
 
  	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ program_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';
	g_total_program_no=program_no;
 
 }
}
function callServer_Get_EPG_Info() {
	var content = parent.document.getElementById("content");
	
	var cgi_url;
	var ch_no=1;
	var from_month;
	var to_month;
	var d=new Date();
	var cur_year=d.getFullYear();
	var cur_month=d.getMonth()+1;
	
	bSystem_Inquery_Panel=0; 
 	bQuery_Channel_Status=0;
  	g_token=find_cookie_value("token");
   	g_ch_no=ch_no;
	if (g_token!=0)
	{
		g_ch_no=ch_no;
		from_month=cur_month;
		to_month=cur_month;
		g_cur_year=cur_year;
		//g_cur_month=cur_month;
		if (cur_month<10)
		{
			g_cur_month='0'+cur_month;
		}else
		{
			g_cur_month=cur_month;		
		}
		cgi_url = "/server/get_epg_info?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&from_year=" + escape(cur_year)+ "&from_month=" + escape(from_month)+ "&to_month=" + escape(to_month)+"&flag="+Math.random();
		
		content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">EPG Information Loading...<p>';
		
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Get_EPG_Info;
		xmlHttp.send(null);
	}

}
function callServer_Get_EPG_Info_By_Month() {
	var content = parent.document.getElementById("content");
	var ch_no= document.getElementById("cur_ch_no").value;
	var cur_year= document.getElementById("cur_year").value;
	var from_month= document.getElementById("cur_month").value;
	var to_month= document.getElementById("cur_month").value;
	var cgi_url;
	
	bSystem_Inquery_Panel=0; 
 	bQuery_Channel_Status=0;
  	g_token=find_cookie_value("token");
	if (g_token!=0)
	{
		g_cur_year=parseInt(cur_year);
		g_cur_month=from_month;
		g_ch_no=ch_no;
		cgi_url = "/server/get_epg_info?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&from_year=" + escape(cur_year)+ "&from_month=" + escape(from_month)+ "&to_month=" + escape(to_month)+"&flag="+Math.random();
		
		content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">EPG Information Loading...<p>';
		
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Get_EPG_Info;
		xmlHttp.send(null);
	}

}
/*
function callServer_Get_EPG_Current_Info() {
	var content = parent.document.getElementById("content");
	
	var cgi_url;
	var ch_no=g_ch_no;
	var cur_year=g_cur_year;
	var from_month=g_cur_month;
	var to_month=g_cur_month;
	
	bSystem_Inquery_Panel=0; 
   	g_token=find_cookie_value("token");
  	if (g_token!=0)
	{
		
		cgi_url = "/server/get_epg_info?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&from_year=" + escape(cur_year)+ "&from_month=" + escape(from_month)+ "&to_month=" + escape(to_month)+"&flag="+Math.random();
		
		content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">EPG Information Loading...<p>';
		
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Get_EPG_Info;
		xmlHttp.send(null);
	}

}
*/
function Update_EPG_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	//callServer_Get_EPG_Current_Info();
     } else
    {
   	alert("Failed to Update EPG.");
    }
	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
    }
}

function callServer_Update_EPG_Info(program_no) {
	
	var ch_no= document.getElementById("cur_ch_no").value;
	//var content = parent.document.getElementById("content");
	var starttime_id="starttime"+program_no;
	var starttime;
	var stoptime_id="stoptime"+program_no;
	var stoptime;
	var program_title_id="program_title"+program_no;
	var program_title;
	var program_descrption_id="program_descrption"+program_no;
	var program_descrption;
	var program_icon_id="program_icon"+program_no;
	var program_icon;
	var program_rec_id="program_rec"+program_no;
	var program_rec;

	var confirm_msg;
 	var cgi_url;

	g_item=document.getElementById(starttime_id);
	starttime = g_item.value;
	if (starttime.length==0)
	{
		alert("Start Time is empty");
		return;
	}else if (starttime.length!=19)
	{
		alert("Start Time length is not 19 (YYYY/MM/DD hh:mm:ss)")
		return;
	}
	g_item=document.getElementById(stoptime_id);
	stoptime = g_item.value;
	if (stoptime.length==0)
	{
		alert("Stop Time is empty");
		return;
	}else if (stoptime.length!=19)
	{
		alert("Stop Time length is not 19 (YYYY/MM/DD hh:mm:ss)")
		return;
	}
	g_item=document.getElementById(program_descrption_id);
	program_descrption = g_item.value;

	g_item=document.getElementById(program_icon_id);
	program_icon = g_item.value;

	g_item=document.getElementById(program_rec_id);
	program_rec = g_item.value;
		
	g_item=document.getElementById(program_title_id);
	program_title = g_item.value;
	if (program_title.length==0)
	{
		alert("Program Title is empty");
		return;
	}
	
	bSystem_Inquery_Panel=0; 
	bQuery_Channel_Status=0;
   	g_token=find_cookie_value("token");
	if (g_token!=0)
	{
		cgi_url = "/server/update_epg_info?token="+escape(g_token)+"&ch_no="+escape(ch_no)+"&program_no=" + escape(program_no)+"&starttime=" + escape(starttime)+ "&stoptime=" + escape(stoptime)
 + "&program_title=" + escape(program_title)+ "&program_descrption=" + escape(program_descrption)+ "&program_icon=" + escape(program_icon)+ "&program_rec=" + escape(program_rec)+"&flag="+Math.random();
		
		//content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">EPG Information Loading...<p>';
		
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Update_EPG_Info;
		xmlHttp.send(null);
		 g_temp=g_item.value;
		 g_item.value=g_item.value+" (updating...)";
		 g_item.style.backgroundColor = "#ff0000";
	}

}
function After_Del_EPG(program_no){
	
	var content = parent.document.getElementById("content");
	g_content=content.innerHTML;
	var program_active_no=g_total_program_no;
	var i, m;
	var starttime_id;
	var starttime;
	var stoptime_id;
	var stoptime;
	var program_title_id;
	var program_title;
	var program_descrption_id;
	var program_descrption;
	var program_icon_id;
	var program_icon;
	var program_rec_id;
	var program_rec;
	var HTML_Menu_Bar_Str="";
	var cur_month;
	var cur_temp_year;


	program_active_no--;
	
	cur_month=g_cur_month;
	
 
	HTML_Menu_Bar_Str='<td width="10%" align="right"><font face="Arial" size="2">Channel No.:</font></td>';
	HTML_Menu_Bar_Str+='<td width="5%" align="center">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_ch_no" id=cur_ch_no>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+g_ch_no+'">'+g_ch_no+'</option>';
	for (i=1;i<=g_total_ch_no;i++)
	{
		if (i!=g_ch_no)
		{
			HTML_Menu_Bar_Str+='<option value="'+i+'">'+i+'</option>';
		}
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

	HTML_Menu_Bar_Str+='<td width="5%" align="center">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_year" id=cur_year>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+g_cur_year+'">'+g_cur_year+'</option>';
	cur_temp_year=g_cur_year-1;
	for (i=0;i<5;i++)
	{
		index_year=cur_temp_year+i;
		if (g_cur_year!=index_year)
		{
			HTML_Menu_Bar_Str+='<option value="'+index_year+'">'+index_year+'</option>';
		}
		
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

 	HTML_Menu_Bar_Str+='<td width="5%" align="right">'+
	' <font face="Arial"> <font size="2">'+
	' <select size="1" name="cur_month" id=cur_month>';
	HTML_Menu_Bar_Str+='<option selected="selected" value="'+cur_month+'">'+cur_month+'</option>';
	
	for (i=1;i<13;i++)
	{
		if (i!=cur_month)
		{
			if (i<10)
			{
				HTML_Menu_Bar_Str+='<option value="0'+i+'">0'+i+'</option>';
				
			}else
			{
				HTML_Menu_Bar_Str+='<option value="'+i+'">'+i+'</option>';
			}
		}
		
	}
	HTML_Menu_Bar_Str+='</select></font></td>';

     HTML_Menu_Bar_Str+='<td width=80% align="left">';
      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callServer_Get_EPG_Info_By_Month()>"+
      '<font size="2" face="Arial">Query</font></a>'+'&nbsp&nbsp&nbsp';
      HTML_Menu_Bar_Str+='</td>';
      HTML_str=  '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="60" align="center"><font face="Arial" size="2">No.</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Start Time(YYYY/MM/DD hh:mm:ss)</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Stop Time(YYYY/MM/DD hh:mm:ss)</font></td>'+
	      '<td width="260" align="center"><font face="Arial" size="2">Program Title</font></td>'+
	      '<td width="400" align="center"><font face="Arial" size="2">Program Description</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Record Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Record</font></td>'+
 	 '</tr>'+'<tr><td  colspan="8"><hr size="1" color="#66FFFF"></td></tr>';
 	 for (i=1,m=1;i<=program_active_no;i++,m++)
	{
		if (m==program_no)
		{
			m++;
		}
		starttime_id="starttime"+m; 
		//alert(starttime_id);
		item_name=document.getElementById(starttime_id);
		// alert(item_name.value);
		starttime = item_name.value;
		
		stoptime_id="stoptime"+m; 
		item_name=document.getElementById(stoptime_id);
		// alert(item_name.value);
		stoptime = item_name.value;
		
		program_title_id="program_title"+m; 
		item_name=document.getElementById(program_title_id);
		// alert(item_name.value);
		program_title = item_name.value;
		
		program_descrption_id="program_descrption"+m; 
		item_name=document.getElementById(program_descrption_id);
		// alert(item_name.value);
		program_descrption = item_name.value;

		program_icon_id="program_icon"+m; 
		item_name=document.getElementById(program_icon_id);
		// alert(item_name.value);
		program_icon = item_name.value;

		program_rec_id="program_rec"+m; 
		item_name=document.getElementById(program_rec_id);
		// alert(item_name.value);
		program_rec = item_name.value;
		HTML_str=HTML_str+
		   '<tr>'+
		      '<td width="60" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="starttime"'+
	 		' id=starttime'+i+
	 		' size="19" value="'+
	 		starttime+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="stoptime"'+
	 		' id=stoptime'+i+
	 		' size="19" value="'+
	 		stoptime+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_title"'+
	 		' id=program_title'+i+
	 		' size="20" value="'+
	 		program_title+'"/></font></td>'+
		      '<td width="40" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_descrption"'+
	 		' id=program_descrption'+i+
	 		' size="40" value="'+
	 		program_descrption+'"/></font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="program_icon"'+
	 		' id=program_icon'+i+
	 		' size="20" value="'+
	 		program_icon+'"/></font></td>';
	 		
	 		HTML_str=HTML_str+
	 		'<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <select size="1" name="program_rec" '+'id=program_rec'+i+'>';
	 		if (program_rec=="ON")
	 		{
		      
		 		HTML_str=HTML_str+'<option selected="selected" value="'+"ON"+'">'+"ON"+'</option>'+
		 		'<option value="'+"OFF"+'">'+"OFF"+'</option>'+'</select></font></td>';
	 		}else
 			{
		 		HTML_str=HTML_str+'<option selected="selected" value="'+"OFF"+'">'+"OFF"+'</option>'+
		 		'<option value="'+"ON"+'">'+"ON"+'</option>'+'</select></font></td>';
 			}	 		
			save_keyword="Save";
			add_keyword="Add";
			del_keyword="Del";
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=callServer_Update_EPG_Info("'+i+'")>'+
			' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Del_EPG_Info("'+i+'")>'+
			' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Add_New_EPG_Info("'+i+'")>'+
			' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
							
			HTML_str+='</tr>';
		
	}
	
	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ program_active_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';
	g_total_program_no=program_active_no;
}

function Del_EPG_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    //	callServer_Get_EPG_Current_Info();
   //   	alert("Del EPG Sucessfully");
   	After_Del_EPG(g_program_no);
    } else
    {
   	alert("Failed to Del EPG.");
    }
 }
}
function call_Del_EPG_Info(program_no) {
	var confirm_msg;
 	var cgi_url;
	var ch_no= document.getElementById("cur_ch_no").value;
	var starttime_id="starttime"+program_no;
	var starttime;
	
	g_item=document.getElementById(starttime_id);
	starttime = g_item.value;
	if (starttime.length==0)
	{
		alert("Start Time is empty");
		return;
	}
	g_program_no=program_no;
		
	bSystem_Inquery_Panel=0; 
 	bQuery_Channel_Status=0;
  	g_token=find_cookie_value("token");
	if (g_token!=0)
	{
		cgi_url = "/server/del_epg_info?token="+escape(g_token)+"&ch_no="+escape(ch_no)+"&program_no=" + escape(program_no)+"&starttime=" + escape(starttime)+"&flag="+Math.random();
				
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Del_EPG_Info;
		xmlHttp.send(null);
	}

}

function Movie_inquery()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
	var movie_no;
	var movie_name;
	var movie_src;
	var icon_path;
	var movie_category;
	var duration;
	var bitrate;
	var movie_status;
    var movie_play_id;
    var movie_title="<p>"+"Movie List"+"</p>";
    var move_list;
    var i=0;
    var j=0;
    var total_movie_no=0;
	var movie_active_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
    var content = parent.document.getElementById("content");
  //var detail = parent.document.getElementById("detail");
	var refresh_keyword=null;
	var play_keyword=null;
	var save_keyword=null;
	var add_keyword=null;
	var del_keyword=null;
	var nduration =0;


	content.innerHTML="";
//	detail.innerHTML="";
	

	 HTML_str= '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="60" align="center"><font face="Arial" size="2">No</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Movie Name</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Media Source</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Category</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Duration(min.)</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Bitrate(Kbps)</font></td>'+
	      '<td width="80" align="center"><font face="Arial" size="2">Status</font></td>'+
 	 '</tr>'+'<tr><td  colspan="8"><hr size="1" color="#66FFFF"></td></tr>';
 
	while (1)
	{
 		//alert(response[i]);
	 	if (response[i]==0) break;
	 	strlength=response[i].length;
   	    	movie_no=response[i].slice(8,strlength);
   	    	
     	 	strlength=response[i+1].length;
     	 	movie_name=response[i+1].slice(5,strlength);
   	    	
     	 	strlength=response[i+2].length;
   	    	movie_src=response[i+2].slice(4,strlength);
   	    	
    	 	strlength=response[i+3].length;
   	    	icon_path=response[i+3].slice(4,strlength);
   	    	
     	 	strlength=response[i+4].length;
 	    	movie_category=response[i+4].slice(9,strlength);

   	    	
 	    	
     	 	strlength=response[i+5].length;
 	    	duration=response[i+5].slice(9,strlength);
 	    	nduration=parseFloat(duration);
 	    	nduration = nduration /60;
 	    	nduration =nduration.toFixed(3);

 	    	
     	 	strlength=response[i+6].length;
 	    	bitrate=response[i+6].slice(8,strlength);
 	    	
       	 	strlength=response[i+7].length;
 	    	movie_status=response[i+7].slice(7,strlength);
   	    		
   	    	

 		i=i+8;
		movie_active_no++;
		HTML_str=HTML_str+
		   '<tr>'+
		      '<td width="60" align="center"><font face="Arial" size="2">'+movie_no+'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="moviename"'+
	 		' id=moviename'+movie_no+
	 		' size="20" value="'+
	 		movie_name+'"/></font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="moviesrc"'+
	 		' id=moviesrc'+movie_no+
	 		' size="35" value="'+
	 		movie_src+'"/></font></td>'+		      
	 		'<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="iconpath"'+
	 		' id=iconpath'+movie_no+
	 		' size="35" value="'+
	 		icon_path+'"/></font></td>'+
		      '<td width="10" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="moviecategory"'+
	 		' id=moviecategory'+movie_no+
	 		' size="10" value="'+
	 		movie_category+'"/></font></td>'+
	 		'<td width="10" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		nduration+'</font></td>'+
		      '<td width="10" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		bitrate+'</font></td>';

	 		

			
			//alert(ch_status);		
			if (movie_status.search("1")>=0)
			{
		      		HTML_str+='<td id=moviestatus'+movie_no+' width="100" align="center"><font face="Arial" size="2">'+"ON"+'</font></td>';
			} else if (movie_status.search("0")>=0)
			{
		      		HTML_str+='<td id=moviestatus'+movie_no+' width="100" align="center"><font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font></td>';
			}

			if (g_Movie_Edit_Mode==0)
			{
				save_keyword="Save";
				refresh_keyword="Refresh";
				play_keyword="Play";
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=callServer_Movie_Update("'+movie_no+'")>'+
				' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
				 HTML_str+='<td id=refreshmoviebutton'+movie_no+' width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Refresh_A_Movie("'+movie_no+'")>'+
				' <font face="Arial" size="2">'+refresh_keyword+'</font></a></td>';
				
				HTML_str+='<td width="150" align="left" id=movie_play_id'+movie_no+'>';
				HTML_str+="<a href='javascript:void(0)'"+
				' onclick=play_movie("'+movie_no+'")>'+
				' <font face="Arial" size="2">'+play_keyword+'</font></a></td>';

				
			}else
			{
				save_keyword="Save";
				add_keyword="Add";
				del_keyword="Del";
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=callServer_Movie_Update("'+movie_no+'")>'+
				' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Del_Movie("'+movie_no+'")>'+
				' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
				HTML_str+='<td width="50" align="center">'+
				"<a href='javascript:void(0)'"+
				' onclick=call_Add_New_Movie("'+movie_no+'")>'+
				' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
			}
			
							
			HTML_str+='</tr>';				
		    
		total_movie_no++;
     }
    //    content.innerHTML=HTML_str;
      // alert(menu_main.innerHTML);
  //    alert(HTML_str);
      
      if (g_Movie_Edit_Mode==0)
      {
      	      HTML_Menu_Bar_Str='<td id=movie_menu_bar width=80% align="right">';
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callServer_Movie_Inquery()>"+
	      '<font size="2" face="Arial">Query</font></a>'+'&nbsp&nbsp&nbsp';
	      
 	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=call_Edit_Movie()>"+
	      '<font size="2" face="Arial">Add/Del</font></a>'+'&nbsp&nbsp&nbsp';
	      
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=call_export_movie_definition()>"+
	      '<font size="2" face="Arial">Export</font></a>'+'&nbsp&nbsp&nbsp';

 	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callezserver_refresh_movie()>"+
	      '<font size="2" face="Arial">Refresh All</font></a>';
	      
	      
 	}else
	{
	      HTML_Menu_Bar_Str='<td id=movie_menu_bar width=80% align="right">';
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=ezserver_quit_movie()>"+
	      '<font size="2" face="Arial">Quit</font></a>';
	      if (total_movie_no==0)
	      {
	      	
	      	i=1;		
		movie_src="";
		movie_name="";
		icon_path="";
		movie_category="";
		
	      HTML_str=HTML_str+'<tr>'+
	      '<td width="100" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviename"'+
 		' id=moviename'+i+
 		' size="20"/'+
 		'</font></td>'+
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviesrc"'+
 		' id=moviesrc'+i+
 		' size="35"/'+
 		'</font></td>'+
 		'<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="iconpath"'+
 		' id=iconpath'+i+
 		' size="35"/'+
 		'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviecategory"'+
 		' id=moviecategory'+i+
 		' size="20"/'+
 		'</font></td>';
 		
	     
	
		HTML_str+='<td id=moviestatus'+i+' width="100" align="center"><font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font></td>';
	      	HTML_str+='<td id=save_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_Movie("'+i+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>'+
	      	      
		      '<td id=del_id_button width="80" align="center">'+		      
		      "<a href='javascript:void(0)'"+
		      ' onclick=Cancel_Add_Movie()>'+
	      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

		      '<td id=add_id_button width="80" align="center">'+		      
		      ' <font face="Arial" size="2"></font></a></td>';
	      }
	
	}
		      
	      HTML_Menu_Bar_Str+='</td>';

  	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ movie_active_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';
	g_total_movie_no=movie_active_no;
 
 }

 
}
function callServer_Movie_Inquery() {
  var content = parent.document.getElementById("content");

  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
	bSystem_Inquery_Panel=0; 
  	bQuery_Channel_Status=0;
 	g_token=find_cookie_value("token");
	if (g_token!=0)
	{
		cgi_url = "/server/query_movie_list?token="+escape(g_token)+"&flag="+Math.random();
		
		content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Movie Information Loading...<p>';
		
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Movie_inquery;
		xmlHttp.send(null);
	}

}





function Set_Channel_update()
{
	add_cookie_value("ch_up_flag",1);
}
function Clear_Channel_update()
{
	add_cookie_value("ch_up_flag",0);
}
function Set_Movie_update()
{
	add_cookie_value("mv_up_flag",1);
}
function Clear_Movie_update()
{
	add_cookie_value("mv_up_flag",0);
}
function Cancel_Add_Channel()
{
	var content = parent.document.getElementById("content");
	g_Channel_Edit_Mode=0;
	content.innerHTML=g_content;
}
function Cancel_Add_Movie()
{
	var content = parent.document.getElementById("content");
	g_Movie_Edit_Mode=0;
	content.innerHTML=g_content;
}
function call_Edit_Movie()
{
	g_Movie_Edit_Mode=1;
	callServer_Movie_Inquery();
}

function call_Edit_Channel()
{
	g_Channel_Edit_Mode=1;
	callServer_CH_Inquery();
}
/*function Refresh_OK_Msg(){
alert("Refresh Channel Sucessfully");
}
*/
function show_channel_menu_bar()
{
	var ch_menu_bar= document.getElementById("ch_menu_bar");
	
	if (ch_menu_bar!=null)
	{
		if (g_Channel_Edit_Mode==0)
		{
			      HTML_Menu_Bar_Str="<a href='javascript:void(0)' onclick=callServer_CH_Inquery()>"+
		      '<font size="2" face="Arial">Query</font></a>'+'&nbsp&nbsp&nbsp';
		      
		      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=call_Edit_Channel()>"+
		      '<font size="2" face="Arial">Edit</font></a>'+'&nbsp&nbsp&nbsp';
		      
		      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callezserver_refresh_channel()>"+
		      '<font size="2" face="Arial">Refresh All</font></a>';
	//	      '<font size="2" face="Arial">Refresh All</font></a>'+'&nbsp&nbsp&nbsp';
		      
		//      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callServer_group_Inquery()>"+
		  //    '<font size="2" face="Arial">Group</font></a>';
		}else
		{
		   //   HTML_Menu_Bar_Str='<td id=ch_menu_bar width=80% align="right">';
		      HTML_Menu_Bar_Str="<a href='javascript:void(0)' onclick=ezserver_quit_channel()>"+
		      '<font size="2" face="Arial">Quit</font></a>';
		      //+'&nbsp&nbsp&nbsp';
		
		   //   HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callezserver_quit_refresh_channel()>"+
		    //  '<font size="2" face="Arial">Quit & Refresh</font></a>';
			
		}
		ch_menu_bar.innerHTML=HTML_Menu_Bar_Str;
	}
}
function show_movie_menu_bar()
{
	var movie_menu_bar= document.getElementById("movie_menu_bar");
	
	if (movie_menu_bar!=null)
	{
		if (g_Movie_Edit_Mode==0)
		{
			      HTML_Menu_Bar_Str="<a href='javascript:void(0)' onclick=callServer_Movie_Inquery()>"+
		      '<font size="2" face="Arial">Query</font></a>'+'&nbsp&nbsp&nbsp';
		      
		      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=call_Edit_Movie()>"+
		      '<font size="2" face="Arial">Edit</font></a>'+'&nbsp&nbsp&nbsp';
		      
		      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callezserver_refresh_movie()>"+
		      '<font size="2" face="Arial">Refresh All</font></a>';
	//	      '<font size="2" face="Arial">Refresh All</font></a>'+'&nbsp&nbsp&nbsp';
		      
		//      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callServer_group_Inquery()>"+
		  //    '<font size="2" face="Arial">Group</font></a>';
		}else
		{
		   //   HTML_Menu_Bar_Str='<td id=ch_menu_bar width=80% align="right">';
		      HTML_Menu_Bar_Str="<a href='javascript:void(0)' onclick=ezserver_quit_movie()>"+
		      '<font size="2" face="Arial">Quit</font></a>';
		      //+'&nbsp&nbsp&nbsp';
		
		   //   HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=callezserver_quit_refresh_channel()>"+
		    //  '<font size="2" face="Arial">Quit & Refresh</font></a>';
			
		}
		movie_menu_bar.innerHTML=HTML_Menu_Bar_Str;
	}
}
function ezserver_quit_refresh_channel(){
 
  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;

    if (response==0)
    {
   	alert("Failed to finish Channels");
    }
	g_Channel_Edit_Mode=0;
	g_Channel_Updated=0;
	show_channel_menu_bar();      
	callServer_CH_Inquery();	


 }
 
}
function callezserver_quit_updated_channel()
{
	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
  var ch_menu_bar= document.getElementById("ch_menu_bar");

	
      	g_token=find_cookie_value("token");

	cgi_url = "/server/refresh_channel?token="+escape(g_token)+"&flag="+Math.random();
	
	alert("Need to wait 10 sec. to get new channel status.");
	if (g_Channel_Updated==1)
	{
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = ezserver_quit_refresh_channel;
		xmlHttp.send(null);
		ch_menu_bar.innerHTML='<font size="2" face="Arial">Refreshing</font>';

/*		confirm_msg="Channel Updated, Refresh Channles?";
		if (confirm(confirm_msg))
		{
		 	 xmlHttp.open("GET", cgi_url, true);
			 xmlHttp.onreadystatechange = ezserver_quit_refresh_channel;
			 xmlHttp.send(null);
		      ch_menu_bar.innerHTML='<font size="2" face="Arial">Refreshing</font>';
	
		}else
		{
			g_Channel_Updated=0;
			callServer_CH_Inquery();
		}
		*/
	}else
	{
		g_Channel_Updated=0;
		callServer_CH_Inquery();
	}
		
		
	

 	
} 
function ezserver_quit_refresh_movie(){
 
  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;

    if (response==0)
    {
   	alert("Failed to finish Movies");
    }
	g_Movie_Edit_Mode=0;
	g_Movie_Updated=0;
	show_movie_menu_bar();      
	callServer_Movie_Inquery();	


 }
 
}
function callezserver_quit_updated_movie()
{
	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
  var movie_menu_bar= document.getElementById("movie_menu_bar");

	
      	g_token=find_cookie_value("token");

	cgi_url = "/server/refresh_movie?token="+escape(g_token)+"&flag="+Math.random();
	
	if (g_Movie_Updated==1)
	{
		alert("Please wait to refresh movies...");
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = ezserver_quit_refresh_movie;
		xmlHttp.send(null);
		movie_menu_bar.innerHTML='<font size="2" face="Arial">Refreshing</font>';

	}else
	{
		g_Movie_Updated=0;
		callServer_Movie_Inquery();
	}
		
		
	

 	
} 
function ezserver_quit_movie(){
 
	g_Movie_Edit_Mode=0;
	if (g_Movie_Updated==1)
	{
		callezserver_quit_updated_movie();
		g_Movie_Updated=0;
	}else
	{
		callServer_Movie_Inquery();
	}
}
function Add_Movie(movie_no) {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    var item_save;
    var item_add;
    var item_del;
    if (response==1)
    {
    	g_Movie_Updated=1;
    	Set_Movie_update();
    	g_total_movie_no++;
  //  	alert("Sucessfully, Refresh Channels to active all channels");
 	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	// callServer_CH_Inquery();
	item_save=document.getElementById("save_id_button");
	item_del=document.getElementById("del_id_button");
	item_add=document.getElementById("add_id_button");
	
	item_save.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=callServer_Movie_Update("'+g_movie_no+'")>'+
	      	      ' <font face="Arial" size="2">Save</font></a></td>';
	item_del.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Del_Movie("'+g_movie_no+'")>'+
	      	      ' <font face="Arial" size="2">Del</font></a></td>';
	item_add.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_New_Movie("'+g_movie_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>';
   } else
    {
   	alert("Failed to Add Movie");
 		g_Movie_Edit_Mode=1;
		callServer_Movie_Inquery();
   }

	
    }
}
function call_Add_Movie(movie_no)
{

 var movie_src_id="moviesrc"+movie_no; 
 var movie_src_name="moviename"+movie_no; 
  var movie_src_category="moviecategory"+movie_no; 
var icon_path_name="iconpath"+movie_no; 
 var movie_src;
 var movie_category;
 var movie_name;
 var icon_path;
 var g_item_name;



var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 g_item=document.getElementById(movie_src_id);
 movie_src = g_item.value;
 if (movie_src.length==0)
 {
 	alert("Media Source is empty");
 	return;
 }


 g_item_name=document.getElementById(movie_src_category);
 movie_category = g_item_name.value;

 g_item_name=document.getElementById(movie_src_name);
 movie_name = g_item_name.value;
 if (movie_name.length==0)
 {
 	alert("Movie Name is empty");
 	return;
 }
 g_item_name=document.getElementById(icon_path_name);
 icon_path = g_item_name.value;


   	g_token=find_cookie_value("token");
g_movie_no=movie_no;
 confirm_msg="Add Movie "+movie_no+" Information?";
 cgi_url = "/server/add_movie?token="+escape(g_token)+"&movie_no="+escape(movie_no)+ "&movie_name=" + escape(movie_name)+ "&src=" + escape(movie_src)+ "&category=" + escape(movie_category)+ "&img=" + escape(icon_path)+"&flag="+Math.random();
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_Movie;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (adding...)";
	 g_item.style.backgroundColor = "#ff0000";
 }


}

// need to edit add new channel in any position
function call_Add_New_Movie(movie_no)
{
	
	var HTML_str;
	//var ch_no;
	var len;
	var movie_refresh_button; 
	var movie_play_id;
	var movie_src_id; 
	var movie_src_name; 
	var movie_src_category; 
	var icon_path_name; 
	var movie_src_status; 
	
	var movie_src;
	var movie_name;
	var icon_path;
	var movie_category;
	var movie_status;
	var item_name;
	var i;
	var save_keyword="Save";
	var add_keyword="Add";
	var del_keyword="Del";
	var movie_active_no;
	var m;
	var k;

	
	var content = parent.document.getElementById("content");
 	var movie_menu_bar= document.getElementById("movie_menu_bar");

	g_content=content.innerHTML;
	movie_active_no=g_total_movie_no;
	movie_active_no++;
	
		HTML_Menu_Bar_Str='<td id=movie_menu_bar width=80% align="right">';
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=ezserver_quit_movie()>"+
	      '<font size="2" face="Arial">Quit</font></a>';
	      
	  HTML_str= '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="60" align="center"><font face="Arial" size="2">No</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Movie Name</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Media Source</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Category</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Duration(min.)</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Bitrate(Kbps)</font></td>'+
	      '<td width="80" align="center"><font face="Arial" size="2">Status</font></td>'+
 	 '</tr>'+'<tr><td  colspan="8"><hr size="1" color="#66FFFF"></td></tr>';
 	
	for (i=1,m=1;i<=movie_active_no;i++,m++)
	{
	//	alert(i);
		movie_src_id="moviesrc"+m; 
		item_name=document.getElementById(movie_src_id);
		// alert(item_name.value);
		movie_src = item_name.value;
		
		movie_src_name="moviename"+m; 
		item_name=document.getElementById(movie_src_name);
		movie_name = item_name.value;

		icon_path_name="iconpath"+m; 
		item_name=document.getElementById(icon_path_name);
		icon_path = item_name.value;
		
		movie_src_category="moviecategory"+m; 
		item_name=document.getElementById(movie_src_category);
		movie_category = item_name.value;
		
		
		movie_src_status="moviestatus"+m; 
		item_name=document.getElementById(movie_src_status);
		movie_status = item_name.innerHTML;
//		alert(ch_status);
	
		HTML_str=HTML_str+'<tr>'+
	      '<td width="100" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviename"'+
 		' id=moviename'+i+
 		' size="20" value="'+
	 	movie_name+'"/'+
 		'</font></td>'+
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviesrc"'+
 		' id=moviesrc'+i+
 		' size="35" value="'+
	 	movie_src+'"/'+
 		'</font></td>'+
 		'<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="iconpath"'+
 		' id=iconpath'+i+
 		' size="35" value="'+
	 	icon_path+'"/'+
 		'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviecategory"'+
 		' id=moviecategory'+i+
 		' size="20" value="'+
	 	movie_category+'"/'+
 		'</font></td>';
 		
					
		if (m==(movie_no))
		{
			HTML_str+='<td id=moviestatus'+i+' width="100" align="center">'+movie_status+'</td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=callServer_Movie_Update("'+i+'")>'+
			' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Del_Movie("'+i+'")>'+
			' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Add_New_Movie("'+i+'")>'+
			' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
			HTML_str+='</tr>';

			i++;
			
			movie_src="";
			movie_name="";
			icon_path="";
			movie_category="";
			
		      HTML_str=HTML_str+'<tr>'+
		      '<td width="100" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="moviename"'+
	 		' id=moviename'+i+
	 		' size="20"/'+
	 		'</font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="moviesrc"'+
	 		' id=moviesrc'+i+
	 		' size="35"/'+
	 		'</font></td>'+
	 		'<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="iconpath"'+
	 		' id=iconpath'+i+
	 		' size="35"/'+
	 		'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="moviecategory"'+
	 		' id=moviecategory'+i+
	 		' size="20"/'+
	 		'</font></td>';
	 		
		     
		
			HTML_str+='<td id=moviestatus'+i+' width="100" align="center"><font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font></td>';
		      	HTML_str+='<td id=save_id_button width="80" align="center">'+
			      "<a href='javascript:void(0)'"+
			      ' onclick=call_Add_Movie("'+i+'")>'+
		      	      ' <font face="Arial" size="2">Add</font></a></td>'+
		      	      
			      '<td id=del_id_button width="80" align="center">'+		      
			      "<a href='javascript:void(0)'"+
			      ' onclick=Cancel_Add_Movie()>'+
		      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

			      '<td id=add_id_button width="80" align="center">'+		      
			      ' <font face="Arial" size="2"></font></a></td>';
		      	      
		}else
		{
			HTML_str+='<td id=moviestatus'+i+' width="100" align="center"><font face="Arial" size="2">'+movie_status+'</font></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=callServer_Movie_Update("'+i+'")>'+
			' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Del_Movie("'+i+'")>'+
			' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Add_New_Movie("'+i+'")>'+
			' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
			
		}
		HTML_str+='</tr>';
	      	     
	      	      	
	}
     
     
//	alert(HTML_str);
	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ movie_active_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';

   //    content.innerHTML=HTML_str+'</table>';
//      alert(ch_list_info.innerHTML);
   
		
}



function Movie_update() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
  	Set_Movie_update();
  	g_Movie_Updated=1;
 //   	alert("Update Channel Sucessfully");
    } else
    {
   	alert("Failed to Update Movie");
    }
	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
    }
  //  setTimeout("callServer_CH_Inquery()",2000);
}

function callServer_Movie_Update(movie_no){
	
var movie_src_id="moviesrc"+movie_no; 
 var movie_src_name="moviename"+movie_no; 
 var icon_path_name="iconpath"+movie_no; 
 var movie_src_category="moviecategory"+movie_no; 
 var movie_src;
 var movie_name;
 var movie_category;
 var icon_path;
 var g_item_name;


 var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var g_ch_play_id;
	var pid;
	
 g_item=document.getElementById(movie_src_id);
 movie_src = g_item.value;
 if (movie_src.length==0)
 {
 	alert("Media Source is empty");
 	return;
 }
// alert(movie_src);
 g_item_name=document.getElementById(movie_src_name);
 movie_name = g_item_name.value;
 if (movie_name.length==0)
 {
 	alert("Movie Name is empty");
 	return;
 }
// alert(movie_name);
 g_item_name=document.getElementById(movie_src_category);
 movie_category = g_item_name.value;
// alert(movie_category);
  g_item_name=document.getElementById(icon_path_name);
 icon_path = g_item_name.value;
// alert(icon_path_name);
 
 	g_token=find_cookie_value("token");

 confirm_msg="Update Movie "+movie_no+" Information?";
 cgi_url = "/server/update_movie?token="+escape(g_token)+"&movie_no="+escape(movie_no)+
  "&movie_name=" + escape(movie_name)+ "&src=" + escape(movie_src)+ "&category=" + escape(movie_category)+ 
  "&img=" + escape(icon_path)+"&flag="+Math.random();
// alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Movie_update;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	// g_item.value=g_item.value+" (updating...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}
function Refresh_A_Movie() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    var movie_play_id="movie_play_id"+g_movie_no;
 var movie_status="moviestatus"+g_movie_no; 
  
    if (response==1)
    {
 //   	alert("Refresh Channel Sucessfully");
	 g_movie_play_id_item=document.getElementById(movie_play_id);
	 g_status_item=document.getElementById(movie_status);
  
   		g_status_item.innerHTML='<font face="Arial" size="2">'+"ON"+'</font>';
     			
	g_item.style.backgroundColor = "#ffffff";

    } else if (response==2)
    {
   	alert("Already Refreshing Movie");
    }else if (response==3)
    {
   	alert("Movie is Refreshing.");
   	g_item.style.backgroundColor = "#ffffff";
    	
    }else if (response==0)
	{
		g_status_item.innerHTML='<font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font>';
		g_movie_play_id_item.innerHTML='<font face="Arial" size="2"></font>';
	g_item.style.backgroundColor = "#ffffff";
    }
    	
  	 g_item.value=g_movie_src;
  	 

     	g_refresh_item.innerHTML="<a href='javascript:void(0)'"+
	      ' onclick=call_Refresh_A_Movie("'+g_movie_no+'")>'+
      	      ' <font face="Arial" size="2">Refresh</font></a>';

  }
}

function call_Refresh_A_Movie(movie_no)
{
 var movie_src_id="moviesrc"+movie_no; 
 var movie_status="moviestatus"+movie_no; 
 var movie_refresh_button="refreshmoviebutton"+movie_no; 
 var movie_play_id="movie_play_id"+movie_no;

 var movie_src;
 var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
 g_item=document.getElementById(movie_src_id);
g_status_item=document.getElementById(movie_status);
g_refresh_item=document.getElementById(movie_refresh_button);
g_movie_play_id_item=document.getElementById(movie_play_id);
	g_movie_no=movie_no;

 movie_src = g_item.value;
 g_movie_src=movie_src;
 	g_token=find_cookie_value("token");

 confirm_msg="Refresh Movie "+movie_no+" ?";
 cgi_url = "/server/refresh_a_movie?token="+escape(g_token)+"&movie_no="+escape(movie_no)+ "&flag="+Math.random();
 
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Refresh_A_Movie;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	g_item.style.backgroundColor = "#ff0000";
     	g_status_item.innerHTML='<font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font>';
     	g_refresh_item.innerHTML='<font face="Arial" size="2">Waiting</font>';
	//if (g_ch_play_id_item!=null) 
	g_movie_play_id_item.innerHTML='<font face="Arial" size="2"></font>';

 }
 

}
function After_Del_Movie(movie_no)
{
	
	var HTML_str;
	//var ch_no;
	var len;
	var movie_refresh_button; 
	var movie_play_id;
	var movie_src_id; 
	var movie_src_name; 
	var icon_path_name; 
	var movie_src_category; 
	var movie_src_status; 
	
	var movie_src;
	var movie_name;
	var movie_category;
	var icon_path;
	var movie_status;
	var item_name;
	var i;
	var save_keyword="Save";
	var add_keyword="Add";
	var del_keyword="Del";
	var ch_active_no;
	var m;
	var j;
	var k;

	
	var content = parent.document.getElementById("content");
 	var movie_menu_bar= document.getElementById("movie_menu_bar");

	
		HTML_Menu_Bar_Str='<td id=movie_menu_bar width=80% align="right">';
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=ezserver_quit_movie()>"+
	      '<font size="2" face="Arial">Quit</font></a>';
	      
	  HTML_str= '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="60" align="center"><font face="Arial" size="2">No</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Movie Name</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Media Source</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Category</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Duration(min.)</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Bitrate(Kbps)</font></td>'+
	      '<td width="80" align="center"><font face="Arial" size="2">Status</font></td>'+
 	 '</tr>'+'<tr><td  colspan="8"><hr size="1" color="#66FFFF"></td></tr>';
 	g_total_movie_no--;
 	movie_active_no=g_total_movie_no;
 	
	for (i=1,m=1;i<=g_total_movie_no;i++,m++)
	{
		//alert(i);
		if (m==(movie_no))
		{
			m++;	      	      
		}
		movie_src_id="moviesrc"+m; 
		item_name=document.getElementById(movie_src_id);
		// alert(item_name.value);
		movie_src = item_name.value;
		
		movie_src_name="moviename"+m; 
		item_name=document.getElementById(movie_src_name);
		movie_name = item_name.value;
		
		icon_path_name="iconpath"+m; 
		item_name=document.getElementById(icon_path_name);
		icon_path = item_name.value;

		movie_src_category="moviecategory"+m; 
		item_name=document.getElementById(movie_src_category);
		movie_category = item_name.value;
		
		
		movie_src_status="moviestatus"+m; 
		item_name=document.getElementById(movie_src_status);
		movie_status = item_name.innerHTML;
//		alert(movie_status);
	
		HTML_str=HTML_str+'<tr>'+
	      '<td width="100" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviename"'+
 		' id=moviename'+i+
 		' size="20" value="'+
	 	movie_name+'"/'+
 		'</font></td>'+
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviesrc"'+
 		' id=moviesrc'+i+
 		' size="35" value="'+
	 	movie_src+'"/'+
 		'</font></td>'+
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="iconpath"'+
 		' id=iconpath'+i+
 		' size="35" value="'+
	 	icon_path+'"/'+
 		'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="moviecategory"'+
 		' id=moviecategory'+i+
 		' size="20" value="'+
	 	movie_category+'"/'+
 		'</font></td>';
 		

		HTML_str+='<td id=moviestatus'+i+' width="100" align="center">'+movie_status+'</td>';
		HTML_str+='<td width="50" align="center">'+
		"<a href='javascript:void(0)'"+
		' onclick=callServer_Movie_Update("'+i+'")>'+
		' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
		HTML_str+='<td width="50" align="center">'+
		"<a href='javascript:void(0)'"+
		' onclick=call_Del_Movie("'+i+'")>'+
		' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
		HTML_str+='<td width="50" align="center">'+
		"<a href='javascript:void(0)'"+
		' onclick=call_Add_New_Movie("'+i+'")>'+
		' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
		HTML_str+='</tr>';
	}
     
     
//	alert(HTML_str);
	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ movie_active_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';

   //    content.innerHTML=HTML_str+'</table>';
//      alert(ch_list_info.innerHTML);
   
		
}
function Del_Movie() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
     	Set_Movie_update();
     	g_Movie_Updated=1;
  // 	alert("Sucessfully, Refresh Channels to active all channels");
    } else
    {
   	alert("Failed to Delete Movie");
    }
    
    	g_Movie_Edit_Mode=1;
    	After_Del_Movie(g_movie_no);
    	//callServer_CH_Inquery();
    }
}

function call_Del_Movie(movie_no)
{
 var movie_src_id="moviesrc"+movie_no; 
 var movie_src;
 var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
 g_item=document.getElementById(movie_src_id);
 movie_src = g_item.value;
   	g_token=find_cookie_value("token");

 confirm_msg="Delete Movie "+movie_no+" Information?";
 cgi_url = "/server/del_movie?token="+escape(g_token)+"&movie_no="+escape(movie_no)+ "&flag="+Math.random();
 g_movie_no=movie_no;
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_Movie;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}
function ezserver_quit_channel(){
 
	g_Channel_Edit_Mode=0;
	if (g_Channel_Updated==1)
	{
		callezserver_quit_updated_channel();
		g_Channel_Updated=0;
	}else
	{
		callServer_CH_Inquery();
	}
}


/*
function callezserver_quit_refresh_channel()
{
	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
  var ch_menu_bar= document.getElementById("ch_menu_bar");

	
      	g_token=find_cookie_value("token");

//	cgi_url = "/cgi-bin/cgi_ezserver?token="+escape(g_token)+"&refresh_channel"+"&flag="+Math.random();
	cgi_url = "/server/refresh_channel?token="+escape(g_token)+"&flag="+Math.random();
	
//	confirm_msg="Refresh Channles?";
//	if (confirm(confirm_msg))
//	{
	 	 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = ezserver_quit_refresh_channel;
		 xmlHttp.send(null);
	      ch_menu_bar.innerHTML='<font size="2" face="Arial">Refreshing</font>';

//	}
	

 	
} 
*/

function ezserver_refresh_movie(){
 
  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    var movie_menu_bar= document.getElementById("movie_menu_bar");
    if (response==1)
    {
  //  	alert("Refresh Movie Sucessfully");
    } else if (response==3)
    {
   	alert("Movies are Refreshing.");
    }else
    {
   	alert("Failed to Refresh Movie");
    }
    g_Movie_Edit_Mode=0;
 // setTimeout("callServer_CH_Inquery()",2000);
/*	if (response==1)
	{
	  setTimeout("Refresh_OK_Msg()",2000);
	}
*/
   callServer_Movie_Inquery();
   show_movie_menu_bar();   
 
 }
 
}
function callezserver_refresh_movie()
{
	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
  var movie_menu_bar= document.getElementById("movie_menu_bar");

	
      	g_token=find_cookie_value("token");

	cgi_url = "/server/refresh_movie?token="+escape(g_token)+"&flag="+Math.random();
	
	//confirm_msg="Do you refresh all channles?";
	//if (confirm(confirm_msg))
	//{
	 	 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = ezserver_refresh_movie;
		 xmlHttp.send(null);
	      movie_menu_bar.innerHTML='<font size="2" face="Arial">Refreshing</font>';

	//}
	

 	
}
function ezserver_refresh_channel(){
 
  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    var ch_menu_bar= document.getElementById("ch_menu_bar");
    if (response==1)
    {
  //  	alert("Refresh Channel Sucessfully");
    } else if (response==3)
    {
   	alert("Channels are Refreshing.");
    }else
    {
   	alert("Failed to Refresh Channel");
    }
    g_Channel_Edit_Mode=0;
 // setTimeout("callServer_CH_Inquery()",2000);
/*	if (response==1)
	{
	  setTimeout("Refresh_OK_Msg()",2000);
	}
*/
   callServer_CH_Inquery();
   show_channel_menu_bar();   
 
 }
 
}
function callezserver_refresh_channel()
{
	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
  var ch_menu_bar= document.getElementById("ch_menu_bar");

	
      	g_token=find_cookie_value("token");

//	cgi_url = "/cgi-bin/cgi_ezserver?token="+escape(g_token)+"&refresh_channel"+"&flag="+Math.random();
	cgi_url = "/server/refresh_channel?token="+escape(g_token)+"&flag="+Math.random();

	confirm_msg="Need to wait 10 sec. to get new channel status after refreshing.";
	if (confirm(confirm_msg))
	{
		bQuery_Channel_Status=0;
	 	 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = ezserver_refresh_channel;
		 xmlHttp.send(null);
	      ch_menu_bar.innerHTML='<font size="2" face="Arial">Refreshing</font>';

	}
	

 	
}   

function Add_Channel(ch_no) {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    var item_save;
    var item_add;
    var item_del;
    if (response==1)
    {
    	g_Channel_Updated=1;
    	Set_Channel_update();
    	g_total_ch_no++;
  //  	alert("Sucessfully, Refresh Channels to active all channels");
 	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	// callServer_CH_Inquery();
	item_save=document.getElementById("save_id_button");
	item_del=document.getElementById("del_id_button");
	item_add=document.getElementById("add_id_button");
	
	item_save.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=callServer_CH_Update("'+g_ch_no+'")>'+
	      	      ' <font face="Arial" size="2">Save</font></a></td>';
	item_del.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Del_Channel("'+g_ch_no+'")>'+
	      	      ' <font face="Arial" size="2">Del</font></a></td>';
	item_add.innerHTML='<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_New_Channel("'+g_ch_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>';
   } else
    {
   	alert("Failed to Add Channel");
 		g_Channel_Edit_Mode=1;
		callServer_CH_Inquery();
   }
	      	      
	/*if (g_Channel_Edit_Mode==0) 
	{
	}*/
	
    }
}
function call_Add_Channel(ch_no)
{

 var ch_src_id="chsrc"+ch_no; 
 var ch_icon_id="chicon"+ch_no; 
 var ch_src_name="chname"+ch_no; 
  var ch_src_category="chcategory"+ch_no; 
var ch_src_type="chtype"+ch_no; 
 var ch_src;
 var ch_icon;
 var ch_category;
 var ch_name;
 var ch_type;
 var g_item_name;



var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 g_item=document.getElementById(ch_src_id);
 ch_src = g_item.value;
 if (ch_src.length==0)
 {
 	alert("Media Source is empty");
 	return;
 }
 g_item_name=document.getElementById(ch_icon_id);
 ch_icon = g_item_name.value;


 g_item_name=document.getElementById(ch_src_category);
 ch_category = g_item_name.value;

 g_item_name=document.getElementById(ch_src_name);
 ch_name = g_item_name.value;
 if (ch_name.length==0)
 {
 	alert("Channel Name is empty");
 	return;
 }
 g_item_name=document.getElementById(ch_src_type);
 ch_type = g_item_name.value;


   	g_token=find_cookie_value("token");
g_ch_no=ch_no;
 confirm_msg="Add Channel "+ch_no+" Information?";
// cgi_url = "/server/channel_list_add?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&ch_name=" + escape(ch_name)+ "&src=" + escape(ch_src)+ "&category=" + escape(ch_category)+ "&type=" + escape(ch_type)+"&flag="+Math.random();
 cgi_url = "/server/add_channel?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&ch_name=" + escape(ch_name)+ "&src=" + escape(ch_src)+ "&category=" + escape(ch_category)+ "&icon=" + escape(ch_icon)+ "&type=" + escape(ch_type)+"&flag="+Math.random();
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_Channel;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (adding...)";
	 g_item.style.backgroundColor = "#ff0000";
 }


}

// need to edit add new channel in any position
function call_Add_New_Channel(ch_no)
{
	
	var HTML_str;
	//var ch_no;
	var len;
	var ch_refresh_button; 
	var ch_play_id;
	var ch_src_id; 
	var ch_icon_id; 
	var ch_src_name; 
	var ch_src_category; 
	var ch_src_type; 
	var ch_src_status; 
	
	var ch_src;
	var ch_icon;
	var ch_name;
	var ch_category;
	var ch_type;
	var ch_status;
	var item_name;
	var i;
	var save_keyword="Save";
	var add_keyword="Add";
	var del_keyword="Del";
	var ch_active_no;
	var m;
	var k;

	
	var content = parent.document.getElementById("content");
 	var ch_menu_bar= document.getElementById("ch_menu_bar");

  //	bQuery_Channel_Status=0;
	g_content=content.innerHTML;
	ch_active_no=g_total_ch_no;
	ch_active_no++;
	
		HTML_Menu_Bar_Str='<td id=ch_menu_bar width=80% align="right">';
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=ezserver_quit_channel()>"+
	      '<font size="2" face="Arial">Quit</font></a>';
	      
	  HTML_str= '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="20" align="center"><font face="Arial" size="2">No.</font></td>'+
	      '<td width="100" align="center"><font face="Arial" size="2">Channel Name</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Media Source</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Category</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Type</font></td>'+
	      '<td width="120" align="center"><font face="Arial" size="2">Status (per 10 sec.)</font></td>'+
 	 '</tr>'+'<tr><td  colspan="7"><hr size="1" color="#66FFFF"></td></tr>';
 	
	for (i=1,m=1;i<=ch_active_no;i++,m++)
	{
	//	alert(i);
		ch_src_id="chsrc"+m; 
		item_name=document.getElementById(ch_src_id);
		// alert(item_name.value);
		ch_src = item_name.value;

		ch_icon_id="chicon"+m; 
		item_name=document.getElementById(ch_icon_id);
		ch_icon = item_name.value;
		
		ch_src_name="chname"+m; 
		item_name=document.getElementById(ch_src_name);
		ch_name = item_name.value;
		
		ch_src_category="chcategory"+m; 
		item_name=document.getElementById(ch_src_category);
		ch_category = item_name.value;
		
		ch_src_type="chtype"+m; 
		item_name=document.getElementById(ch_src_type);
		ch_type = item_name.value;
		
		ch_src_status="chstatus"+m; 
		item_name=document.getElementById(ch_src_status);
		ch_status = item_name.innerHTML;
//		alert(ch_status);
	
		HTML_str=HTML_str+'<tr>'+
	      '<td width="100" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="chname"'+
 		' id=chname'+i+
 		' size="20" value="'+
	 	ch_name+'"/'+
 		'</font></td>'+
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="chsrc"'+
 		' id=chsrc'+i+
 		' size="30" value="'+
	 	ch_src+'"/'+
 		'</font></td>'+
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="chicon"'+
 		' id=chicon'+i+
 		' size="30" value="'+
	 	ch_icon+'"/'+
 		'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="chcategory"'+
 		' id=chcategory'+i+
 		' size="20" value="'+
	 	ch_category+'"/'+
 		'</font></td>'+
 		
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
		' <select size="1" name="chtype" id=chtype'+i+'>';
 		
		//alert(ch_type);
		if (ch_type.search("live")>=0)
		{
			HTML_str+='<option selected="selected" value="live">'+"Live"+'</option>'+
			'<option value="movie">'+"Movie"+'</option>'+
			'<option value="dvr">'+"DVR"+'</option>'+
			'<option value="hls">'+"HLS"+'</option>'+
			'<option value="inactive">'+"Inactive"+'</option>';
			for (j=0;j<g_delaytime_array.length;j++)
			{
				
				HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
				
			}
		}else if (ch_type.search("delay")>=0)
		{
			for (k=0;k<g_delaytime_array.length;k++)
			{
				
				if (ch_type.search(g_delayvalue_array[k])==0)
				{
					break;
				}
			}
			//alert(k);
			HTML_str+='<option value="live">'+"Live"+'</option>'+
			'<option value="movie">'+"Movie"+'</option>'+
			'<option value="dvr">'+"DVR"+'</option>'+
			'<option value="hls">'+"HLS"+'</option>'+
			'<option value="inactive">'+"Inactive"+'</option>';
			for (j=0;j<g_delaytime_array.length;j++)
			{
				if (j!=k)
				{
					HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
				}else 
				{
					HTML_str+='<option selected="selected" value="'+g_delayvalue_array[k]+'">'+g_delaytime_array[k]+'</option>';
				}
										
			}
		}else if (ch_type.search("dvr")>=0)
		{
			HTML_str+='<option selected="selected" value="dvr">'+"DVR"+'</option>'+
			'<option value="live">'+"Live"+'</option>'+
			'<option value="movie">'+"Movie"+'</option>'+
			'<option value="hls">'+"HLS"+'</option>'+
			'<option value="inactive">'+"Inactive"+'</option>';
			for (j=0;j<g_delaytime_array.length;j++)
			{
				
				HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
				
			}
		}else if (ch_type.search("inactive")>=0)
		{
			HTML_str+='<option selected="selected" value="inactive">'+"Inactive"+'</option>'+
			'<option value="live">'+"Live"+'</option>'+
			'<option value="movie">'+"Movie"+'</option>'+
			'<option value="dvr">'+"DVR"+'</option>'+
			'<option value="hls">'+"HLS"+'</option>';
			for (j=0;j<g_delaytime_array.length;j++)
			{
				
				HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
				
			}
		}else if (ch_type.search("movie")>=0)
		{
			HTML_str+='<option selected="selected" value="movie">'+"Movie"+'</option>'+
			'<option value="live">'+"Live"+'</option>'+
			'<option value="dvr">'+"DVR"+'</option>'+
			'<option value="hls">'+"HLS"+'</option>'+
			'<option value="inactive">'+"Inactive"+'</option>';
			for (j=0;j<g_delaytime_array.length;j++)
			{
				
				HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
				
			}
		}else if (ch_type.search("hls")>=0)
		{
			HTML_str+='<option selected="selected" value="hls">'+"HLS"+'</option>'+
			'<option value="live">'+"Live"+'</option>'+
			'<option value="dvr">'+"DVR"+'</option>'+
			'<option value="movie">'+"Movie"+'</option>'+
			'<option value="inactive">'+"Inactive"+'</option>';
			for (j=0;j<g_delaytime_array.length;j++)
			{
				
				HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
				
			}
		}
		HTML_str+='</select></font></td>';
					
		if (m==(ch_no))
		{
			HTML_str+='<td id=chstatus'+i+' width="100" align="center">'+ch_status+'</td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=callServer_CH_Update("'+i+'")>'+
			' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Del_Channel("'+i+'")>'+
			' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Add_New_Channel("'+i+'")>'+
			' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
			HTML_str+='</tr>';

			i++;
			
			ch_src="";
			ch_icon="";
			ch_name="";
			ch_category="";
			ch_status="";
		      HTML_str=HTML_str+'<tr>'+
		      '<td width="100" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="chname"'+
	 		' id=chname'+i+
	 		' size="20"/'+
	 		'</font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="chsrc"'+
	 		' id=chsrc'+i+
	 		' size="30"/'+
	 		'</font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="chicon"'+
	 		' id=chicon'+i+
	 		' size="30"/'+
	 		'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="chcategory"'+
	 		' id=chcategory'+i+
	 		' size="20"/'+
	 		'</font></td>'+
	 		
		      '<td width="200" align="center">'+
	 		' <font face="Arial" size="2">'+
			' <select size="1" name="chtype" id=chtype'+i+'>';
	 		
			HTML_str+='<option selected="selected" value="live">'+"Live"+'</option>'+
			'<option value="movie">'+"Movie"+'</option>'+
			'<option value="dvr">'+"DVR"+'</option>'+
			'<option value="hls">'+"HLS"+'</option>'+
			'<option value="inactive">'+"Inactive"+'</option>';
			for (j=0;j<g_delaytime_array.length;j++)
			{
				
				HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
				
			}
			HTML_str+='</select></font></td>';
		
			HTML_str+='<td id=chstatus'+i+' width="100" align="center"><font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font></td>';
		      	HTML_str+='<td id=save_id_button width="80" align="center">'+
			      "<a href='javascript:void(0)'"+
			      ' onclick=call_Add_Channel("'+i+'")>'+
		      	      ' <font face="Arial" size="2">Add</font></a></td>'+
		      	      
			      '<td id=del_id_button width="80" align="center">'+		      
			      "<a href='javascript:void(0)'"+
			      ' onclick=Cancel_Add_Channel()>'+
		      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

			      '<td id=add_id_button width="80" align="center">'+		      
			      ' <font face="Arial" size="2"></font></a></td>';
		      	      
		}else
		{
			HTML_str+='<td id=chstatus'+i+' width="100" align="center"><font face="Arial" size="2">'+ch_status+'</font></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=callServer_CH_Update("'+i+'")>'+
			' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Del_Channel("'+i+'")>'+
			' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
			HTML_str+='<td width="50" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Add_New_Channel("'+i+'")>'+
			' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
			
		}
		HTML_str+='</tr>';
	      	     
	      	      	
	}
     
     
//	alert(HTML_str);
	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ ch_active_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';

   //    content.innerHTML=HTML_str+'</table>';
//      alert(ch_list_info.innerHTML);
   
		
}

function CH_update() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
  	Set_Channel_update();
  	g_Channel_Updated=1;
 //   	alert("Update Channel Sucessfully");
    } else
    {
   	alert("Failed to Update Channel");
    }
	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
    }
  //  setTimeout("callServer_CH_Inquery()",2000);
}

function callServer_CH_Update(ch_no){
	
var ch_src_id="chsrc"+ch_no; 
var ch_icon_id="chicon"+ch_no; 
 var ch_src_name="chname"+ch_no; 
 var ch_src_category="chcategory"+ch_no; 
 var ch_src_type="chtype"+ch_no; 
 var ch_src;
 var ch_icon;
 var ch_name;
 var ch_category;
 var ch_type;
 var g_item_name;


 var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var g_ch_play_id;
	var pid;
	
 bQuery_Channel_Status=0;	
 g_item=document.getElementById(ch_src_id);
 ch_src = g_item.value;
 if (ch_src.length==0)
 {
 	alert("Media Source is empty");
 	return;
 }
 g_item_name=document.getElementById(ch_icon_id);
 ch_icon = g_item_name.value;

 g_item_name=document.getElementById(ch_src_name);
 ch_name = g_item_name.value;
 if (ch_name.length==0)
 {
 	alert("Channel Name is empty");
 	return;
 }
 g_item_name=document.getElementById(ch_src_category);
 ch_category = g_item_name.value;
  g_item_name=document.getElementById(ch_src_type);
 ch_type = g_item_name.value;
 	g_token=find_cookie_value("token");

 confirm_msg="Update Channel "+ch_no+" Information?";
// cgi_url = "/server/channel_list_update?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&ch_name=" + escape(ch_name)+ "&src=" + escape(ch_src)+ "&category=" + escape(ch_category)+ "&type=" + escape(ch_type)+"&flag="+Math.random();
// cgi_url = "/server/channel_list_update?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&ch_name=" + escape(ch_name)+ "&src=" + ch_src+ "&category=" + escape(ch_category)+ "&type=" + escape(ch_type)+"&flag="+Math.random();
cgi_url = "/server/update_channel?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&ch_name=" + escape(ch_name)+ "&src=" + ch_src+ "&category=" + escape(ch_category)+ "&icon=" + ch_icon+ "&type=" + escape(ch_type)+"&flag="+Math.random();

 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = CH_update;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	// g_item.value=g_item.value+" (updating...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}
function Refresh_A_Channel() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    var ch_play_id="ch_play_id"+g_ch_no;
 var ch_status="chstatus"+g_ch_no; 
 var ch_chtype="chtype"+g_ch_no; 
 var ch_type_value;
 var dvr_folder_on;
  
    if ((response==1) || (response==2))
    {
 //   	alert("Refresh Channel Sucessfully");
	 g_ch_play_id_item=document.getElementById(ch_play_id);
	 g_status_item=document.getElementById(ch_status);
	 g_chtype_item=document.getElementById(ch_chtype);
	 ch_type_value=g_chtype_item.value;
 
     	if (ch_type_value.search("inactive")==0)
     	{
   		g_status_item.innerHTML='<font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font>';
   		//if (g_ch_play_id_item!=null)
   		//{
		g_ch_play_id_item.innerHTML='<font face="Arial" size="2"></font>';
		//}
		
	}else
	{
    		if (response==1)
    		{
    			g_status_item.innerHTML='<font face="Arial" size="2">'+"ON"+'</font>';
    		}else if (response==2)
		{
    			g_status_item.innerHTML='<font face="Arial" size="2" color="#0000FF">'+"Connecting"+'</font>';
		}
    			
    		
		if (ch_type_value.search("dvr")>=0)
	    	{
	    		dvr_folder_on=1;
	    	}else
	    	{
	    		dvr_folder_on=0;
	    	}	
	    	//if (g_ch_play_id_item!=null)
	        //{	
		if (g_ch_src.search("rtmp")==0)
		{
		    	 g_ch_play_id_item.innerHTML="<a href='javascript:void(0)'"+
		    ' onclick=play_channel("'+g_ch_no+'",'+'"flv"'+','+dvr_folder_on+')>'+
		    ' <font face="Arial" size="2">Play</font></a>';
		}
		else
		{
		    g_ch_play_id_item.innerHTML="<a href='javascript:void(0)'"+
		    ' onclick=play_channel("'+g_ch_no+'",'+'"ch"'+','+dvr_folder_on+')>'+
		    ' <font face="Arial" size="2">Play</font></a>';
		}
		//}
	}
     			
	g_item.style.backgroundColor = "#ffffff";

    }else if (response==3)
    {
   	alert("The Channel is connecting.");
   	g_item.style.backgroundColor = "#ffffff";
    	
    }else if (response==4)
    {
   	alert("Channels are Refreshing.");
   	g_item.style.backgroundColor = "#ffffff";
    	
    }else if (response==0)
	{
	alert("Failed to Refresh Channel");
	g_item.style.backgroundColor = "#ffffff";
	}
    	
  	 g_item.value=g_ch_src;
  	 
/*     	g_refresh_item.innerHTML='<td id=refreshchannelbutton'+g_ch_no+' width="50" align="center">'+
	      "<a href='javascript:void(0)'"+
	      ' onclick=call_Refresh_A_Channel("'+g_ch_no+'")>'+
      	      ' <font face="Arial" size="2">Refresh</font></a></td>';
  */
     	g_refresh_item.innerHTML="<a href='javascript:void(0)'"+
	      ' onclick=call_Refresh_A_Channel("'+g_ch_no+'")>'+
      	      ' <font face="Arial" size="2">Refresh</font></a>';

  }
}

function call_Refresh_A_Channel(ch_no)
{
 var ch_src_id="chsrc"+ch_no; 
 var ch_status="chstatus"+ch_no; 
 var ch_refresh_button="refreshchannelbutton"+ch_no; 
 var ch_play_id="ch_play_id"+ch_no;

 var ch_src;
 var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
	bQuery_Channel_Status=0;
 g_item=document.getElementById(ch_src_id);
g_status_item=document.getElementById(ch_status);
g_refresh_item=document.getElementById(ch_refresh_button);
g_ch_play_id_item=document.getElementById(ch_play_id);
	g_ch_no=ch_no;

 ch_src = g_item.value;
 g_ch_src=ch_src;
 	g_token=find_cookie_value("token");

 confirm_msg="Refresh Channel "+ch_no+" ?";
 cgi_url = "/server/refresh_a_channel?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&flag="+Math.random();
 
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Refresh_A_Channel;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	g_item.style.backgroundColor = "#ff0000";
//     	g_status_item.innerHTML='<td id=chstatus'+ch_no+' width="100" align="center"><font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font></td>';
  //   	g_refresh_item.innerHTML='<td id=refreshchannelbutton'+ch_no+' width="50" align="center">'+' <font face="Arial" size="2">Waiting</font></td>';
     	g_status_item.innerHTML='<font face="Arial" size="2" color="#FF0000">'+"<b>OFF</b>"+'</font>';
     	g_refresh_item.innerHTML='<font face="Arial" size="2">Waiting</font>';
	//if (g_ch_play_id_item!=null) 
	g_ch_play_id_item.innerHTML='<font face="Arial" size="2"></font>';

 }
 

}
function After_Del_Channel(ch_no)
{
	
	var HTML_str;
	//var ch_no;
	var len;
	var ch_refresh_button; 
	var ch_play_id;
	var ch_src_id; 
	var ch_src_icon; 
	var ch_src_name; 
	var ch_src_category; 
	var ch_src_type; 
	var ch_src_status; 
	
	var ch_src;
	var ch_icon;
	var ch_name;
	var ch_category;
	var ch_type;
	var ch_status;
	var item_name;
	var i;
	var save_keyword="Save";
	var add_keyword="Add";
	var del_keyword="Del";
	var ch_active_no;
	var m;
	var j;
	var k;

	
	var content = parent.document.getElementById("content");
 	var ch_menu_bar= document.getElementById("ch_menu_bar");

	
		HTML_Menu_Bar_Str='<td id=ch_menu_bar width=80% align="right">';
	      HTML_Menu_Bar_Str+="<a href='javascript:void(0)' onclick=ezserver_quit_channel()>"+
	      '<font size="2" face="Arial">Quit</font></a>';
	      
	  HTML_str= '<table border="0" cellpadding="0" cellspacing="10">'+
	  '<tr>'+
	      '<td width="20" align="center"><font face="Arial" size="2">No.</font></td>'+
	      '<td width="100" align="center"><font face="Arial" size="2">Channel Name</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Media Source</font></td>'+
	      '<td width="200" align="center"><font face="Arial" size="2">Icon Path</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Category</font></td>'+
	      '<td width="60" align="center"><font face="Arial" size="2">Type</font></td>'+
	      '<td width="120" align="center"><font face="Arial" size="2">Status (per 10 sec.)</font></td>'+
 	 '</tr>'+'<tr><td  colspan="7"><hr size="1" color="#66FFFF"></td></tr>';
 	g_total_ch_no--;
 	ch_active_no=g_total_ch_no;
 	
	for (i=1,m=1;i<=g_total_ch_no;i++,m++)
	{
		//alert(i);
		if (m==(ch_no))
		{
			m++;	      	      
		}
		ch_src_id="chsrc"+m; 
		item_name=document.getElementById(ch_src_id);
		// alert(item_name.value);
		ch_src = item_name.value;
		
		ch_src_name="chname"+m; 
		item_name=document.getElementById(ch_src_name);
		ch_name = item_name.value;
		
		ch_src_icon="chicon"+m; 
		item_name=document.getElementById(ch_src_icon);
		ch_icon = item_name.value;

		ch_src_category="chcategory"+m; 
		item_name=document.getElementById(ch_src_category);
		ch_category = item_name.value;
		
		ch_src_type="chtype"+m; 
		item_name=document.getElementById(ch_src_type);
		ch_type = item_name.value;
		
		ch_src_status="chstatus"+m; 
		item_name=document.getElementById(ch_src_status);
		ch_status = item_name.innerHTML;
//		alert(ch_status);
	
		HTML_str=HTML_str+'<tr>'+
	      '<td width="100" align="center"><font face="Arial" size="2">'+i+'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="chname"'+
 		' id=chname'+i+
 		' size="20" value="'+
	 	ch_name+'"/'+
 		'</font></td>'+
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="chsrc"'+
 		' id=chsrc'+i+
 		' size="30" value="'+
	 	ch_src+'"/'+
 		'</font></td>'+
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="chicon"'+
 		' id=chicon'+i+
 		' size="30" value="'+
	 	ch_icon+'"/'+
 		'</font></td>'+
	      '<td width="20" align="center">'+
 		' <font face="Arial" size="2">'+
 		' <input type="text" name="chcategory"'+
 		' id=chcategory'+i+
 		' size="20" value="'+
	 	ch_category+'"/'+
 		'</font></td>'+
 		
	      '<td width="200" align="center">'+
 		' <font face="Arial" size="2">'+
		' <select size="1" name="chtype" id=chtype'+i+'>';
 		
		HTML_str+='<option selected="selected" value="live">'+"Live"+'</option>'+
		'<option value="movie">'+"Movie"+'</option>'+
		'<option value="dvr">'+"DVR"+'</option>'+
		'<option value="hls">'+"HLS"+'</option>'+
		'<option value="inactive">'+"Inactive"+'</option>';
		for (j=0;j<g_delaytime_array.length;j++)
		{
			
			HTML_str+='<option value="'+g_delayvalue_array[j]+'">'+g_delaytime_array[j]+'</option>';
			
		}
		HTML_str+='</select></font></td>';
		HTML_str+='<td id=chstatus'+i+' width="100" align="center">'+ch_status+'</td>';
		HTML_str+='<td width="50" align="center">'+
		"<a href='javascript:void(0)'"+
		' onclick=callServer_CH_Update("'+i+'")>'+
		' <font face="Arial" size="2">'+save_keyword+'</font></a></td>';
		HTML_str+='<td width="50" align="center">'+
		"<a href='javascript:void(0)'"+
		' onclick=call_Del_Channel("'+i+'")>'+
		' <font face="Arial" size="2">'+del_keyword+'</font></a></td>';
		HTML_str+='<td width="50" align="center">'+
		"<a href='javascript:void(0)'"+
		' onclick=call_Add_New_Channel("'+i+'")>'+
		' <font face="Arial" size="2">'+add_keyword+'</font></a></td>';
		HTML_str+='</tr>';
	}
     
     
//	alert(HTML_str);
	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font size="2" face="Arial">Total: '+ ch_active_no+'</td>'+HTML_Menu_Bar_Str+
 	'</tr></table>'+HTML_str+'</table>';

   //    content.innerHTML=HTML_str+'</table>';
//      alert(ch_list_info.innerHTML);
   
		
}
function Del_Channel() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
     	Set_Channel_update();
     	g_Channel_Updated=1;
  // 	alert("Sucessfully, Refresh Channels to active all channels");
    } else
    {
   	alert("Failed to Delete Channel");
    }
    
    	g_Channel_Edit_Mode=1;
    	After_Del_Channel(g_ch_no);
    	//callServer_CH_Inquery();
    }
}

function call_Del_Channel(ch_no)
{
 var ch_src_id="chsrc"+ch_no; 
 var ch_src;
 var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;

	if (g_total_ch_no==1)
	{
		alert("Warning: EZserver needs at least one channel.");
		return;
	}
	
 g_item=document.getElementById(ch_src_id);
 ch_src = g_item.value;
   	g_token=find_cookie_value("token");

 confirm_msg="Delete Channel "+ch_no+" Information?";
 cgi_url = "/server/del_channel?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&flag="+Math.random();
 g_ch_no=ch_no;
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_Channel;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}
function Save_Channel_More() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Save Channel More Sucessfully");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    } else if (response==0)
    {
   	alert("Failed to Save Channel More");
    }
  }
}

function callServer_Save_Channel_More(ch_no)
{

    var sr2_id="sr2";
   var sr3_id="sr3";
  var sid_id="sid";
  var tolerance_id="tolerance";
  var forwardflag_id="forwardflag";

   
   var sr2url;
   var sr3url;
  var sid;
  var tolerance;
  var forwardflag;
 
 

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 //alert(ch_no);

	g_item=document.getElementById(sr2_id);
	//alert(g_item.value);
	sr2url=g_item.value;
	g_item=document.getElementById(sr3_id);
	//alert(g_item.value);
	sr3url=g_item.value;
	
	g_item=document.getElementById(sid_id);
	//alert(g_item.value);
	sid=g_item.value;
	g_item=document.getElementById(tolerance_id);
	//alert(g_item.value);
	tolerance=g_item.value;
	g_item=document.getElementById(forwardflag_id);
	//alert(g_item.value);
	forwardflag=g_item.value;


   	g_token=find_cookie_value("token");

 confirm_msg="Save Channel: "+ch_no+" Information?";
 cgi_url = "/server/save_channel_more?token="+escape(g_token)+"&ch_no="+escape(ch_no)+
  "&sr2="+sr2url+
  "&sr3="+sr3url+
  "&sid="+sid+
  "&tolerance="+tolerance+
  "&forward="+forwardflag+
   "&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Save_Channel_More;
	 xmlHttp.send(null);

 }


}
function Query_A_Channel_More()
{
  var str;
 
 var ch_no;
 var ch_name;
   var UserDetailWindow;
   var srcurl;
   var sr2url;
   var sr3url;
   var sid;
   var tolerance;
   var forwardflag;
 	


  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText.split("\r\n");
  //		alert(response[0]);
 		i=0;

	 	strlength=response[i].length;
   	    	ch_no=response[i].slice(3,strlength);

		i++;
	 	strlength=response[i].length;
   	    	ch_name=response[i].slice(5,strlength);
   	    	
    str="<head><title>"+ch_name+" [CH "+ch_no+"]"+"</title><link rel='stylesheet' type='text/css' href='menu.css'/>"+'<script src="menu.js"></script></head><body><table align="center">';
		
		i++;
	 	strlength=response[i].length;
   	    	srcurl=response[i].slice(4,strlength);
   	    	
  	    	i++;
    	 	strlength=response[i].length;
   	    	sr2url=response[i].slice(4,strlength);

   	    	i++;
    	 	strlength=response[i].length;
   	    	sr3url=response[i].slice(4,strlength);
   	    	
   	    	i++;
	 	strlength=response[i].length;
   	    	sid=response[i].slice(4,strlength);
 	    	
   	    	i++;
	 	strlength=response[i].length;
   	    	tolerance=response[i].slice(10,strlength);
   	    	
   	    	i++;
     	 	strlength=response[i].length;
   	    	forwardflag=response[i].slice(8,strlength);
   	    	

  		
 		str+='<tr><td><font face="Arial"> <font size="2">Channel No. : </font></td><td width="350" height="23"><font face="Arial"> <font size="2"><b>'+ch_no+'</b></font></td></tr>';
 		str+='<tr><td><font face="Arial"> <font size="2">Channel Name: </font></td><td width="350" height="23"><font face="Arial"> <font size="2"><b>'+ch_name+'</b></font></td></tr>';
 		str+='<tr><td><font face="Arial"> <font size="2">Main URL: </font></td><td width="350" height="23"><font face="Arial"> <font size="2"><b>'+srcurl+'</b></font></td></tr>';
 
 		str+='<tr><td><font face="Arial"> <font size="2">2nd URL: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="sr2"'+
 		' id="sr2"'+
 		' size="80" value="'+
 		sr2url+
 		'"/></font></td></tr>';

 		str+='<tr><td><font face="Arial"> <font size="2">3rd URL: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="sr3"'+
 		' id="sr3"'+
 		' size="80" value="'+
 		sr3url+
 		'"/></font></td></tr>';
 		
		str+='<tr><td><font face="Arial"> <font size="2">Channel SID: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="sid"'+
 		' id="sid"'+
 		' size="50" value="'+
 		sid+
 		'"/></font></td></tr>';

		str+='<tr><td><font face="Arial"> <font size="2">Bitrate Tolerance: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="tolerance"'+
 		' id="tolerance"'+
 		' size="5" value="'+
 		tolerance+
 		'"/></font></td></tr>';
  		
 		 str+='<tr><td><font face="Arial"> <font size="2">Channel Forward : </font></td><td width="350" height="23">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="forwardflag" id="forwardflag">';
		if (forwardflag==0)
		{
			str+='<option selected="selected" value="0">0</option>';
			str+='<option value="1">1</option>';
		}
		else
		{
			str+='<option selected="selected" value="1">1</option>';
			str+='<option value="0">0</option>';
		}	 			
 		str+='</select></font></td></tr>';

 		
    str+='<tr><td><input type="button" value="Save" onclick=callServer_Save_Channel_More("'+g_ch_no+'") name="B2" /></td></tr></table></body>';  
   // alert(str);
 
       	 UserDetailWindow= window.open("", "", "top=100, left=100, width=700, height=300"); 
	UserDetailWindow.document.write(str); 

  }
}

function call_Query_A_Channel_More(ch_no)
{
 var ch_src_id="chsrc"+ch_no; 
 var ch_src;
 var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;


   	g_token=find_cookie_value("token");

	 cgi_url = "/server/query_channel_more?token="+escape(g_token)+"&ch_no="+escape(ch_no)+ "&flag="+Math.random();
	 g_ch_no=ch_no;
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Query_A_Channel_More;
	 xmlHttp.send(null);

}

function Block_Player() {

  if (xmlHttp.readyState == 4) {
	    var response = xmlHttp.responseText;
	    var reloader_content;
	    if (response==1)
	    {
	    	calllist_active_player_info();
	    } else
	    {
	   	alert("Failed to Block the player");
	    }

    }
}

function callServer_Block_Player(sessionno, protocoltype){

	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
	
	//alert(protocoltype);
   	g_token=find_cookie_value("token");

	confirm_msg="Block Player ["+sessionno+"] ?";
	 if (confirm(confirm_msg))
	 {
 		cgi_url= "/player/block_player?token="+escape(g_token)+"&sessionno="+escape(sessionno)+"&protocol="+escape(protocoltype)+"&flag="+Math.random();
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Block_Player;
		xmlHttp.send(null);
	}
 
 

}
function Stop_Player() {

  if (xmlHttp.readyState == 4) {
	    var response = xmlHttp.responseText;
	    var reloader_content;
	    if (response==1)
	    {
	    	calllist_active_player_info();
	    } else
	    {
	   	alert("Failed to Stop the player");
	    }

    }
}

function callServer_Stop_Player(sessionno, protocoltype){

	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
	
	//alert(protocoltype);
   	g_token=find_cookie_value("token");

	confirm_msg="Stop Player ["+sessionno+"] ?";
	 if (confirm(confirm_msg))
	 {
 		cgi_url= "/player/stop_player?token="+escape(g_token)+"&sessionno="+escape(sessionno)+"&protocol="+escape(protocoltype)+"&flag="+Math.random();
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Stop_Player;
		xmlHttp.send(null);
	}
 
 

}
function list_active_player_info(){
  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText.split("\r\n");
    var sessionnotext;
    var sessionno;
    var username;
    var playername;
    var watching_ch;
    var box_time;
    var box_ip;
    var box_country;
    var box_group;
    var box_group_text;
    var eztbox_title="<p>"+"macid IP name"+"</p>";
    var eztbox_list;
    var i=0;
    var box_no=1;
	var eztbox_active_no=0;
	var ret=0;
	var HTML_title_str='';
	var HTML_str='';
	var macid_value;
  var content = parent.document.getElementById("content");
  // var detail = parent.document.getElementById("detail");
	

	content.innerHTML="";
//	detail.innerHTML="";
	

	 HTML_title_str= '<table border="0" align="center" height="53">'+
	  '<tr>'+
	      '<td width="50" height="17" align="center"><font face="Arila" size="2">No.</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Subscriber</font></td>'+
	      '<td width="100 height="17" align="center"><font face="Arila" size="2">Session No.</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Player Name</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Watching CH/Moive</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Starting Time</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">IP</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">MAC Address</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Country</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Protocol</font></td>'+
	   //   '<td width="100" height="17" align="center">'+
	    //  " <a href='javascript:void(0)' onclick=callServer_Reboot_All_Player()>"+
	    // ' <font face="Arial" size="2">Reboot All</font></a></td>'+
 	 '</tr>'+'<tr><td  colspan="10"><hr size="1" color="#66FFFF"></td></tr>';
	
	while (1)
	{
		if (response[i]==0) break;
		//alert(response[i]);
		sessionnotext=response[i];
		sessionno=sessionnotext.slice(10);
		//alert(sessionno);
		username=response[i+1];
//		alert(username);
		ret=username.indexOf("username",0);
		//if (ret==-1) break;
		playername=response[i+2];
		watching_ch=response[i+3];
		
		box_time=response[i+4];
//		alert(box_time);
		box_ip=response[i+5];
//		alert(box_ip)
		box_macid=response[i+6];
		box_country=response[i+7];
		box_group_text=response[i+8];
		box_group=box_group_text.slice(6);
//		alert(box_group);
		i=i+9;
		eztbox_active_no++;
		HTML_str='<tr>'+
		      '<td width="50" height="18" align="center"><font face="Arila" size="2">'+box_no+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+username.slice(9)+'</font></td>'+
		      '<td width="50" height="18" align="center"><font face="Arila" size="2">'+sessionno+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+playername.slice(11)+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+watching_ch.slice(12)+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+box_time.slice(12)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_ip.slice(10)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_macid.slice(13)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_country.slice(8)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_group+'</font></td>'+
		      '<td width="50" height="18" align="center">'+
		      " <a href='javascript:void(0)'"+' onclick=callServer_Stop_Player("'+sessionno+'","'+box_group+'")>'+
		      '<font face="Arila" size="2">'+"Stop"+'</font></td>'+
		      '<td width="50" height="18" align="center">'+
		      " <a href='javascript:void(0)'"+' onclick=callServer_Block_Player("'+sessionno+'","'+box_group+'")>'+
		      '<font face="Arila" size="2">'+"Block"+'</font></td>'+
		      '</tr>'+HTML_str;
		      
		box_no++;
     }
       // contentinnerHTML=HTML_str;
       HTML_str=HTML_title_str+HTML_str;
        
  	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font face="Arial" size="2">Total: '+ eztbox_active_no+'</font></td>'+
  	'<td width=70% align="right">'+"<a href='javascript:void(0)'"+
	' onclick=calllist_active_player_info()>'+
	' <font face="Arial" size="2">Query</font></a></td>'+
  	'<td id=reload_filter_information width=10% align="right">'+"<a href='javascript:void(0)'"+
	' onclick=call_reload_filter_information()>'+
	' <font face="Arial" size="2">Reload Filters</font></a></td>'+
	'</tr></table>'+HTML_str;
	
	//alert(content.innerHTML);
    
 }
 
 
}


function Block_Alert_Player() {

  if (xmlHttp.readyState == 4) {
	    var response = xmlHttp.responseText;
	    var reloader_content;
	    if (response==1)
	    {
	    	calllist_alert_player_info();
	    } else
	    {
	   	alert("Failed to Block the player");
	    }

    }
}

function callServer_Block_Alert_Player(sessionno, protocoltype){

	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
	
	//alert(protocoltype);
   	g_token=find_cookie_value("token");

	confirm_msg="Block Player ["+sessionno+"] ?";
	 if (confirm(confirm_msg))
	 {
 		cgi_url= "/player/block_player?token="+escape(g_token)+"&sessionno="+escape(sessionno)+"&protocol="+escape(protocoltype)+"&flag="+Math.random();
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Block_Alert_Player;
		xmlHttp.send(null);
	}
 
 

}
function Stop_Alert_Player() {

  if (xmlHttp.readyState == 4) {
	    var response = xmlHttp.responseText;
	    var reloader_content;
	    if (response==1)
	    {
	    	calllist_alert_player_info();
	    } else
	    {
	   	alert("Failed to Stop the player");
	    }

    }
}

function callServer_Stop_Alert_Player(sessionno, protocoltype){

	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
	
	//alert(protocoltype);
   	g_token=find_cookie_value("token");

	confirm_msg="Stop Player ["+sessionno+"] ?";
	 if (confirm(confirm_msg))
	 {
 		cgi_url= "/player/stop_player?token="+escape(g_token)+"&sessionno="+escape(sessionno)+"&protocol="+escape(protocoltype)+"&flag="+Math.random();
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Stop_Alert_Player;
		xmlHttp.send(null);
	}
 
 

}
function list_alert_player_info(){
  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText.split("\r\n");
    var sessionnotext;
    var sessionno;
    var username;
    var playername;
    var watching_ch;
    var box_time;
    var box_watch_hour;
    var box_ip;
    var box_country;
    var box_group;
    var box_group_text;
    var eztbox_title="<p>"+"macid IP name"+"</p>";
    var eztbox_list;
    var i=0;
    var box_no=1;
	var eztbox_active_no=0;
	var ret=0;
	var HTML_title_str='';
	var HTML_str='';
	var macid_value;
  var content = parent.document.getElementById("content");
  // var detail = parent.document.getElementById("detail");
	

	content.innerHTML="";
//	detail.innerHTML="";
	

	 HTML_title_str= '<table border="0" align="center" height="53">'+
	  '<tr>'+
	      '<td width="50" height="17" align="center"><font face="Arila" size="2">No.</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Subscriber</font></td>'+
	      '<td width="100 height="17" align="center"><font face="Arila" size="2">Session No.</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Player Name</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Watching CH/Moive</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Starting Time</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Watch Hours</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">IP</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">MAC Address</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Country</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Protocol</font></td>'+
	   //   '<td width="100" height="17" align="center">'+
	    //  " <a href='javascript:void(0)' onclick=callServer_Reboot_All_Player()>"+
	    // ' <font face="Arial" size="2">Reboot All</font></a></td>'+
 	 '</tr>'+'<tr><td  colspan="10"><hr size="1" color="#66FFFF"></td></tr>';
	
	while (1)
	{
		if (response[i]==0) break;
		//alert(response[i]);
		sessionnotext=response[i];
		sessionno=sessionnotext.slice(10);
		//alert(sessionno);
		username=response[i+1];
//		alert(username);
		ret=username.indexOf("username",0);
		//if (ret==-1) break;
		playername=response[i+2];
		watching_ch=response[i+3];
		
		box_time=response[i+4];
		box_watch_hour=response[i+5];
//		alert(box_watch_hour);
//		alert(box_time);
		box_ip=response[i+6];
//		alert(box_ip)
		box_macid=response[i+7];
		box_country=response[i+8];
		box_group_text=response[i+9];
		box_group=box_group_text.slice(6);
//		alert(box_group);
		i=i+10;
		eztbox_active_no++;
		HTML_str='<tr>'+
		      '<td width="50" height="18" align="center"><font face="Arila" size="2">'+box_no+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+username.slice(9)+'</font></td>'+
		      '<td width="50" height="18" align="center"><font face="Arila" size="2">'+sessionno+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+playername.slice(11)+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+watching_ch.slice(12)+'</font></td>'+
		      '<td width="200" height="18" align="center"><font face="Arila" size="2">'+box_time.slice(12)+'</font></td>'+
		      '<td width="200" height="18" align="center"><b><font face="Arila" size="2" color="#FF0000">'+box_watch_hour.slice(18)+'</font></b></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_ip.slice(10)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_macid.slice(13)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_country.slice(8)+'</font></td>'+
		      '<td width="100" height="18" align="center"><font face="Arila" size="2">'+box_group+'</font></td>'+
		      '<td width="50" height="18" align="center">'+
		      " <a href='javascript:void(0)'"+' onclick=callServer_Stop_Alert_Player("'+sessionno+'","'+box_group+'")>'+
		      '<font face="Arila" size="2">'+"Stop"+'</font></td>'+
		      '<td width="50" height="18" align="center">'+
		      " <a href='javascript:void(0)'"+' onclick=callServer_Block_Alert_Player("'+sessionno+'","'+box_group+'")>'+
		      '<font face="Arila" size="2">'+"Block"+'</font></td>'+
		      '</tr>'+HTML_str;
		      
		box_no++;
     }
       // contentinnerHTML=HTML_str;
       HTML_str=HTML_title_str+HTML_str;
        
  	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font face="Arial" size="2">Total: '+ eztbox_active_no+'</font></td>'+
  	'<td width=70% align="right">'+"<a href='javascript:void(0)'"+
	' onclick=calllist_alert_player_info()>'+
	' <font face="Arial" size="2">Query</font></a></td>'+
  	'</tr></table>'+HTML_str;
	
	//alert(content.innerHTML);
    
 }
 
 
}


function reload_filter_information() {

  if (xmlHttp.readyState == 4) {
	    var response = xmlHttp.responseText;
	    var reloader_content;
	    if (response==1)
	    {
	    } else
	    {
	   	alert("Failed to Reload Filter Information");
	    }
 	reloader_content = document.getElementById("reload_filter_information");
 	reloader_content.innerHTML="<a href='javascript:void(0)'"+
	' onclick=call_reload_filter_information()>'+
	' <font face="Arial" size="2">Reload Filters</font></a>'

    }
}

function call_reload_filter_information(){

	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
	
   	g_token=find_cookie_value("token");
 	var reloader_content = document.getElementById("reload_filter_information");

	confirm_msg="Reload Filter Information?";
	 if (confirm(confirm_msg))
	 {
 		cgi_url= "/server/reload_filter_information?token="+escape(g_token)+"&flag="+Math.random();
		reloader_content.innerHTML='<font face="Arila" color="#FF0000" size="2">Reloading';
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = reload_filter_information;
		xmlHttp.send(null);
	}
 
 

}
function calllist_active_player_info(){

	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;

   	g_token=find_cookie_value("token");
   	bSystem_Inquery_Panel=0;
 	bQuery_Channel_Status=0;
	var content = parent.document.getElementById("content");

	if (g_token!=0)
	{
		cgi_url= "/player/query_all?token="+escape(g_token)+"&flag="+Math.random();
		content.innerHTML='<p align="center"><font face="Arila" color="#FF0000" size="4">Player Information Loading...<p>';
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = list_active_player_info;
		xmlHttp.send(null);
	}
 
 

}
function calllist_alert_player_info(){

	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;

   	g_token=find_cookie_value("token");
   	bSystem_Inquery_Panel=0;
 	bQuery_Channel_Status=0;
	var content = parent.document.getElementById("content");

	if (g_token!=0)
	{
		cgi_url= "/player/get_alert_player_list?token="+escape(g_token)+"&flag="+Math.random();
		content.innerHTML='<p align="center"><font face="Arila" color="#FF0000" size="4">Player Information Loading...<p>';
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = list_alert_player_info;
		xmlHttp.send(null);
	}
 
 

}

function callServer_group_Inquery() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");

 cgi_url = "/server/query_group?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Group Information Loading...<p>';


 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = group_inquery;
 xmlHttp.send(null);

}

function Cancel_Add_group()
{
	callServer_group_Inquery();
}


function Add_group() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
 //   	alert("Add Group Sucessfully");
    } else
    {
   	alert("Failed to Add Group");
    }
	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	callServer_group_Inquery();
    }
}
function call_Add_group(group_no)
{

 var group_src_id="groupsrc"+group_no; 
 var group_src_name="groupname"+group_no; 
 var group_concurrentconnection="group_concurrentconnection"+group_no; 
 var group_src;
 var group_name;
 var group_concurrentconnection;
 var g_item_name;



var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 g_item=document.getElementById(group_src_id);
 group_src = g_item.value;

 g_item_name=document.getElementById(group_src_name);
 group_name = g_item_name.value;

g_item_name=document.getElementById(group_concurrentconnection);
 group_concurrentconnection = g_item_name.value;

   	g_token=find_cookie_value("token");

 confirm_msg="Add Group "+group_name+" Information?";
 cgi_url = "/server/add_group?token="+escape(g_token)+ "&group_name=" + escape(group_name)+"&group_concurrent_connection=" + escape(group_concurrentconnection)+ "&group_src=" + escape(group_src)+"&flag="+Math.random();
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_group;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (adding...)";
	 g_item.style.backgroundColor = "#ff0000";
 }


}


function call_Add_New_group()
{

var HTML_str;
var group_no;
var len;
g_total_group_no++;
   var content = parent.document.getElementById("content");

	HTML_str=content.innerHTML;
	//len=HTML_str.length-16;
	len=HTML_str.lastIndexOf("</tr>");
	if (len==-1)
	{
		len=HTML_str.lastIndexOf("</TR>");
	}	
//	alert(len);
	len+=5;
	HTML_str=HTML_str.slice(0,len);
	group_no=g_total_group_no;
	HTML_str=HTML_str+'<tr>'+
		      '<td width="100" align="center"><font face="Arila" size="2">'+group_no+'</font></td>'+
		      '<td width="20" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="groupname"'+
	 		' id=groupname'+group_no+
	 		' size="20"/'+
	 		'</font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="groupsrc"'+
	 		' id=groupsrc'+group_no+
	 		' size="35"/'+
	 		'</font></td>'+
		      '<td width="150" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="group_concurrentconnection"'+
	 		' id=group_concurrentconnection'+group_no+
	 		' size="3"/'+
	 		'</font></td>'+
		      '<td id=add_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_group("'+group_no+'")>'+
	      	      ' <font face="Arila" size="2">Add</font></a></td>'+
	      	      
		      '<td width="80" align="center">'+		      
		      "<a href='javascript:void(0)'"+
		      ' onclick=Cancel_Add_group()>'+
	      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+
	      	      '</tr>';
//	alert(HTML_str);

	       content.innerHTML=HTML_str+'</table>';
  //      alert(ch_list_info.innerHTML);
   
		
}

function update_group() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
 //   	alert("Update Group Sucessfully");
    } else
    {
   	alert("Failed to Update Group");
    }
	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
    }
}

function callServer_update_group(group_no){
	
var group_src_id="groupsrc"+group_no; 
 var group_src_name="groupname"+group_no; 
 var group_src_concurrentconnection="groupconcurrentconnection"+group_no; 
 var group_src;
 var group_name;
 var group_concurrentconnection;
 var g_item_name;



var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 g_item=document.getElementById(group_src_id);
 group_src = g_item.value;

 g_item_name=document.getElementById(group_src_name);
 group_name = g_item_name.value;

g_item_name=document.getElementById(group_src_concurrentconnection);
 group_concurrentconnection = g_item_name.value;

    	g_token=find_cookie_value("token");

 confirm_msg="Update Group "+group_no+" Information?";
  cgi_url = "/server/update_group?token="+escape(g_token)+"&group_no=" + escape(group_no)+"&group_name=" + escape(group_name)+"&group_concurrent_connection=" + escape(group_concurrentconnection)+ "&group_src=" + escape(group_src)+"&flag="+Math.random();
if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = update_group;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 // g_item.value=g_item.value+" (updating...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}

function Del_group() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
  //   	alert("Delete Group Sucessfully");
    } else
    {
   	alert("Failed to Delete Group");
    }
    	callServer_group_Inquery();
    }
}

function call_Del_group(group_no)
{
  var group_src_id="groupsrc"+group_no; 
 var group_src_name="groupname"+group_no; 
 var group_src;
 var group_name;
 var g_item_name;
 
  var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
 g_item=document.getElementById(group_src_id);
 group_src = g_item.value;

 g_item_name=document.getElementById(group_src_name);
 group_name = g_item_name.value;
   	g_token=find_cookie_value("token");

 confirm_msg="Delete Group "+group_no+" Information?";
 cgi_url = "/server/del_group?token="+escape(g_token)+ "&group_name=" + escape(group_name)+ "&flag="+Math.random();
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_group;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}



function Cancel_Add_User()
{
	call_get_all_user();

}

function Add_User_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    //	alert("Add User Sucessfully");
    } else if (response==0)
    {
   	alert("Failed to Add User");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    }else if (response==3)
    {
    	alert("The user is already in Database");
    }

	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	call_get_all_user();
    }
}

function call_Add_User(user_no)
{

 var username_id="username"+user_no; 
 var password_id="password"+user_no; 
 var group_id="group"+user_no; 
 var expired_time_id="expired_time"+user_no; 
// var paymodel_id="paymodel"+user_no; 
// var user_point_id="user_point"+user_no;
 var userip_id="userip"+user_no;
 var macid_id="macid"+user_no;
 var szpassword;
 var szgroup;
 var expired_time;
 var expired_YY;
 var expired_MM;
 var expired_DD;
 //var paymodel;
 //var user_point;
 var userip;
 var macid;
 var username;
 var d=new Date();
 var cur_year=d.getFullYear();
 var cur_month=d.getMonth()+1;
 var cur_date=d.getDate();



var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var pos;
	var expired_time_temp;
 	var pos;
	var expired_time_temp;
	var alert_message;


	g_item=document.getElementById(username_id);
	username=g_item.value;
	if (username.length==0)
	{
		alert("User name is empty");
		return;
	}
	g_item=document.getElementById(expired_time_id);
	expired_time=g_item.value;
	if (expired_time.length==0)
	{
		alert("Expired Time is empty");
		return;
	}else if (expired_time.length>10)
	{
		alert("Date Length is too long(>10)");
		return;
	}
	if (g_user_authorization_mode==1)
	{
		g_item=document.getElementById(password_id);
		szpassword=g_item.value;
		if (szpassword.length==0)
		{
			alert("Pawword is empty");
			return;
		}
		pos=expired_time.indexOf('/');
		expired_MM=expired_time.substring(0,pos);
		expired_time_temp=expired_time.substring(pos+1);
		pos=expired_time_temp.indexOf('/');	
		expired_DD=expired_time_temp.substring(0,pos);
		expired_YY=expired_time_temp.substring(pos+1);
		if (expired_YY<cur_year)
		{
			alert_message="Expired Year should be >="+cur_year;
			alert(alert_message);
			return;
		}
		if ((expired_MM<1)||(expired_MM>12))
		{
			alert("Exipred Month should be between 1 and 12");
			return;
		}
		if ((expired_YY==cur_year)&&(expired_MM<cur_month))
		{
			alert_message="Expired Month should be >"+cur_month;
			alert(alert_message);
			return;
			
		}
		if ((expired_DD<1)||(expired_DD>31))
		{
			alert("Exipred Date should be between 1 and 30");
			return;
		}
		if ((expired_YY==cur_year)&&(expired_MM==cur_month)&&(expired_DD<cur_date))
		{
			alert_message="Expired Date should be >"+cur_date;
			alert(alert_message);
			return;
		}
	}else if (g_user_authorization_mode==2)
	{
		szpassword=null;
	}

	
	g_item=document.getElementById(group_id);
	szgroup=g_item.value;
//	g_item=document.getElementById(paymodel_id);
//	paymodel=g_item.value;
//	g_item=document.getElementById(user_point_id);
//	user_point=g_item.value;
	g_item=document.getElementById(userip_id);
	userip=g_item.value;
	g_item=document.getElementById(macid_id);
	macid=g_item.value;


   	g_token=find_cookie_value("token");

 confirm_msg="Add User: "+username+" Information?";
 cgi_url = "/server/add_user?token="+escape(g_token)+"&username="+escape(username)+
  "&password="+szpassword+
  "&group="+szgroup+
  "&expired_time="+expired_time+
 // "&paymodel="+paymodel+
 // "&user_point="+user_point+
  "&userip="+userip+
  "&macid="+macid+
   "&flag="+Math.random();
 //  alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_User_Info;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (Adding...)";
	g_item.style.backgroundColor = "#ff0000";
 }


}
function call_Add_New_User() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
    	g_token=find_cookie_value("token");

 cgi_url = "/server/query_group?token="+escape(g_token)+"&flag="+Math.random();

 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = group_inquery_item_for_add;
 xmlHttp.send(null);

}

function call_Add_New_User_detail()
{

var HTML_str;
var user_no;
var len;
var paymodel;
var str;
  var content = parent.document.getElementById("content");
	

	g_user_no++;

	HTML_str=content.innerHTML;
	//alert(HTML_str);
	//len=HTML_str.length-16;
	len=HTML_str.lastIndexOf("<TABLE");
	
	if (len==-1)
	{
		len=HTML_str.lastIndexOf("<table");
	}
		
		//HTML_str=HTML_str.slice(800,len);
		//alert(HTML_str);
//	alert(len);
	//len+=6;
	HTML_str=HTML_str.slice(0,len);

	user_no=g_user_no;
//	alert(HTML_str);
	HTML_str=HTML_str+'<tr><td><table><tr>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">'+user_no+'</font></td>';
			if (g_user_authorization_mode==1)
 			{
			     HTML_str+='<td width="10%" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="username"'+
		 		' id=username'+user_no+' size="12"/></font></td>'+
	 		      '<td width="15%" align="center">'+
		 		'<font face="Arial" size="2">'+
		 		'<input type="text" name="password"'+
		 		'id=password'+user_no+' size="12"/></font></td>';
	 		}else if (g_user_authorization_mode==2)
 			{
			     HTML_str+='<td width="20%" align="center">'+
		 		' <font face="Arial" size="2">'+
		 		' <input type="text" name="username"'+
		 		' id=username'+user_no+' size="36"/></font></td>';
 			}
	 			

		      HTML_str+='<td width="15%" align="center">'+
	 		'<font face="Arial" size="2">'+
			'<select size="1" name="group" id=group'+user_no+'>';
			
	 		for (j=0;j<g_total_group_no;j++)
	 		{
	 			groupname=g_groupname_array[j];
 				HTML_str+='<option value="'+groupname+'">'+groupname+'</option>';
	 		}
	  		HTML_str+='</select></font></td>';
	  		
	  		HTML_str=HTML_str+'<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1">'+
 			'<option value="-1">--</option>'+
			'<option value="enigma">Enigma</option>'+
			'<option value="enigma16">Enigma 1.6</option>'+
			'<option value="enigma(RTMP)">Enigma(RTMP)</option>'+
			'<option value="enigma16(RTMP)">Enigma 1.6(RTMP)</option>'+
			'<option value="m3u_no">m3u(by chno)</option>'+
 			'<option value="m3u_name">m3u(by chname)</option>'+
 			'<option value="m3ue_no">m3u(by chno with suffix)</option>'+
 			'<option value="m3ue_name">m3u(by chname with suffix)</option>'+
			'<option value="octagon">octagon</option>'+
			'<option value="ariva">ariva</option>'+
 			'<option value="xbmc">XBMC</option>'+
 			'<option value="pure">Pure</option>'+
			'<option value="optumuss">Optumuss</option>'+
			'<option value="amiko">Amiko</option>'+
			'<option value="spark">Spark</option>'+
			'<option value="tiger">Tiger</option>'+
			'<option value="nstreamvod">nStreamVOD</option>'+
			'<option value="script_enigma">*Enigma Script*</option>'+
			'<option value="script_enigma16">*Enigma16 Script*</option>'+
			'<option value="script_mac_address">*MAC Address Script*</option>';
	  		HTML_str+='</select></font></td>';
	 		 		
		      HTML_str+='<td width="18%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="expired_time"'+
	 		' id=expired_time'+user_no+' size="12"/></font></td>'; 		

		      HTML_str+='<td width="18%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="userip"'+
	 		' id=userip'+user_no+' size="12"/></font></td>';

		      HTML_str+='<td width="18%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="macid"'+
	 		' id=macid'+user_no+' size="12"/></font></td>';
	 		
		      /* '<td width="15%" align="center">'+
	 		' <font face="Arial" size="2">'+
			' <select size="1" name="paymodel" id=paymodel'+user_no+'>';
			
	 		 for (j=0;j<3;j++)
	 		{
	 			paymodel=g_paymodel_array[j];
 				str+='<option value="'+paymodel+'">'+paymodel+'</option>';
	 		}
	  		HTML_str=HTML_str+str+'</select></font></td>';
	  		
	 		
		      HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="user_point"'+
	 		' id=user_point'+user_no+' size="12"/></font></td>'+
	 		*/
	 			 		
		       HTML_str+='<td id=add_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_User("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>'+
	      	      
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=Cancel_Add_User()>'+
	      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

		    '</tr></table></td></tr>';
	//alert(HTML_str);

	       content.innerHTML=HTML_str+'</table>';
  //      alert(user_list_info.innerHTML);
   
		
}
function Del_User_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Delete User Sucessfully");
    } else if (response==2)
    {
     	alert("Disk is error(FULL), Please contact administrator");  	
    } else if (response==0)
    {
   	alert("Failed to Delete User");
    }
    	call_get_all_user();
    }
}

//nction call_Del_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Del_User(user_no)
{
 var username_id="username"+user_no; 
 var username;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(username_id);
	username=g_item.value;
	
   	g_token=find_cookie_value("token");

 confirm_msg="Delete User: "+username+" Information?";
// cgi_url = "/server/del_user?token="+escape(g_token)+"&user_no="+escape(user_no)+"&username="+escape(username)+"&flag="+Math.random();
 cgi_url = "/server/del_user?token="+escape(g_token)+"&username="+escape(username)+"&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_User_Info;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}

function Save_User_More() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Save User More Sucessfully");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    } else if (response==0)
    {
   	alert("Failed to Save User More");
    }
   // call_get_all_user();
  }
}

function callServer_Save_More(user_no,username)
{

   var rating_password_id="rating_password";
   var paymodel_id="paymodel";
   var user_point_id="user_point";
   var smart_phone_id="smart_phone";
   var tablet_id="tablet";
   var desktop_id="desktop";
   var tv_id="tv";
   var first_name_id="first_name";
   var last_name_id="last_name";
   var address_id="address";
   var city_id="city";
   var zip_id="zip";
   var tel_id="tel";
   var email_id="email";
   
   var rating_password;
   var paymodel;
   var user_point;
  var smart_phone;
   var tablet;
   var desktop;
   var tv;
   var first_name;
   var last_name;
   var address;
   var city;
   var zip;
   var tel;
   var email;
 

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 

	g_item=document.getElementById(rating_password_id);
	rating_password=g_item.value;

	g_item=document.getElementById(paymodel_id);
	paymodel=g_item.value;

	g_item=document.getElementById(user_point_id);
	user_point=g_item.value;

	g_item=document.getElementById(smart_phone_id);
//	alert(g_item);
	smart_phone=g_item.value;
	
	g_item=document.getElementById(tablet_id);
	tablet=g_item.value;
	g_item=document.getElementById(desktop_id);
	desktop=g_item.value;
	g_item=document.getElementById(tv_id);
	tv=g_item.value;
	g_item=document.getElementById(first_name_id);
	first_name=g_item.value;
	g_item=document.getElementById(last_name_id);
	last_name=g_item.value;
	g_item=document.getElementById(address_id);
	address=g_item.value;
	g_item=document.getElementById(city_id);
	city=g_item.value;
	g_item=document.getElementById(zip_id);
	zip=g_item.value;
	g_item=document.getElementById(tel_id);
	tel=g_item.value;
	g_item=document.getElementById(email_id);
	email=g_item.value;

   	g_token=find_cookie_value("token");

 confirm_msg="Save User: "+username+" Information?";
// cgi_url = "/server/save_user_more?token="+escape(g_token)+"&user_no="+escape(user_no)+"&username="+escape(username)+
 cgi_url = "/server/save_user_more?token="+escape(g_token)+"&username="+escape(username)+
  "&rating_password="+rating_password+
  "&paymodel="+paymodel+
  "&user_point="+user_point+
  "&smart_phone="+smart_phone+
  "&tablet="+tablet+
  "&desktop="+desktop+
  "&tv="+tv+
  "&first_name="+first_name+
  "&last_name="+last_name+
  "&address="+address+
  "&city="+city+
  "&zip="+zip+
  "&tel="+tel+
  "&email="+email+
   "&flag="+Math.random();
 //  alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Save_User_More;
	 xmlHttp.send(null);

 }


}
function Query_User_More() {
   var str;
   var i;
   var username;
   var rating_password;
   var paymodel;
   var paymodel_option;
   var user_point;
   
   var smart_phone;
   var tablet;
   var desktop;
   var tv;
   var first_name;
   var last_name;
   var address;
   var city;
   var zip;
   var tel;
   var email;
   var UserDetailWindow
   // var detail = parent.document.getElementById("detail");
	

	// detail.innerHTML="";

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText.split("\r\n");
     str="<head><title>EZserver Subscriber</title><link rel='stylesheet' type='text/css' href='menu.css'/>"+'<script src="menu.js"></script></head><body><table align="center">';
  //   str='';
 //		alert(response[0]);
 		i=0;
	 	strlength=response[i].length;
   	    	username=response[i].slice(9,strlength);
   	    	
  	    	i++;
    	 	strlength=response[i].length;
   	    	rating_password=response[i].slice(16,strlength);

   	    	i++;
    	 	strlength=response[i].length;
   	    	paymodel=response[i].slice(9,strlength);
   	    	
   	    	i++;
	 	strlength=response[i].length;
   	    	user_point=response[i].slice(11,strlength);
 	    	
   	    	i++;
	 	strlength=response[i].length;
   	    	smart_phone=response[i].slice(12,strlength);
   	    	
   	    	i++;
     	 	strlength=response[i].length;
   	    	tablet=response[i].slice(7,strlength);
   	    	
   	    	i++;
     	 	strlength=response[i].length;
   	    	desktop=response[i].slice(8,strlength);
   	    	
   	    	i++;
     	 	strlength=response[i].length;
   	    	tv=response[i].slice(3,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	first_name=response[i].slice(11,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	last_name=response[i].slice(10,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	address=response[i].slice(8,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	city=response[i].slice(5,strlength);
   	    	
   	    	i++;
    	 	strlength=response[i].length;
   	    	zip=response[i].slice(4,strlength);
   	    	 	    	
   	    	i++;
   	 	strlength=response[i].length;
   	    	tel=response[i].slice(4,strlength);
   	    	
   	    	i++;
   	 	strlength=response[i].length;
   	    	email=response[i].slice(6,strlength);
 
 		str+='<tr><td><font face="Arial"> <font size="2">User: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		username+
 		'</font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">Rating Password: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="rating_password"'+
 		' id="rating_password"'+
 		' size="16" value="'+
 		rating_password+
 		'"/></font></td></tr>';
 		
  		
 		 str+='<tr><td><font face="Arial"> <font size="2">Pay Model: </font></td><td width="350" height="23">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="paymodel" id="paymodel">';
	 		for (j=0;j<3;j++)
	 		{
	 			paymodel_option=g_paymodel_array[j];
	 			if (paymodel.search(paymodel_option)==-1)
	 			{
	 				str+='<option value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}
	 			else
	 			{
	 				str+='<option selected="selected" value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}	 			
	 		}
 		str+='</select></font></td></tr>';

		str+='<tr><td><font face="Arial"> <font size="2">User Point.: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="user_point"'+
 		' id="user_point"'+
 		' size="16" value="'+
 		user_point+
 		'"/></font></td></tr>';

 		str+='<tr><td><font face="Arial"> <font size="2">Smart Phone No.: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="smart_phone"'+
 		' id="smart_phone"'+
 		' size="16" value="'+
 		smart_phone+
 		'"/></font></td></tr>';

 		str+='<tr><td><font face="Arial"> <font size="2">Tablet ID: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="tablet"'+
 		' id="tablet"'+
 		' size="16" value="'+
 		tablet+
 		'"/></font></td></tr>';

		str+='<tr><td><font face="Arial"> <font size="2">Desktop ID: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="desktop"'+
 		' id="desktop"'+
 		' size="16" value="'+
 		desktop+
 		'"/></font></td></tr>';

 		str+='<tr><td><font face="Arial"> <font size="2">TV ID: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="tv"'+
 		' id="tv"'+
 		' size="16" value="'+
 		tv+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">First Name: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="first_name"'+
 		' id="first_name"'+
 		' size="16" value="'+
 		first_name+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">Last Name: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="last_name"'+
 		' id="last_name"'+
 		' size="16" value="'+
 		last_name+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">Adress: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="address"'+
 		' id="address"'+
 		' size="50" value="'+
 		address+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">City: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="city"'+
 		' id="city"'+
 		' size="16" value="'+
 		city+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">ZIP: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="zip"'+
 		' id="zip"'+
 		' size="16" value="'+
 		zip+
 		'"/></font></td></tr>';
 		
 		str+='<tr><td><font face="Arial"> <font size="2">Tel: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="tel"'+
 		' id="tel"'+
 		' size="16" value="'+
 		tel+
 		'"/></font></td></tr>';
  
  		str+='<tr><td><font face="Arial"> <font size="2">Email: </font></td><td width="350" height="23">'+
 		' <font face="Arial"> <font size="2">'+
 		' <input type="text" name="email"'+
 		' id="email"'+
 		' size="30" value="'+
 		email+
 		'"/></font></td></tr>';
 		
//    str+='<tr><td><input type="button" value="Cancel" onclick=call_get_all_user() name="B1" />';  
    str+='<tr><td><input type="button" value="Save" onclick=callServer_Save_More("'+g_user_no+'"'+','+'"'+g_username+'") name="B2" /></td></tr></table></body>';  
   /*  detail.innerHTML='<table align="center"><tr><td>'+
  	'<p align="center" style="margin-top: 10"><font face="Arial"> <font size="2"> User Name: '+
  	'<font face="Arial"> <font size="2">'+username+'</font></td></tr></table>'+str;
  */
 /* str+='<table align="center"><tr><td>'+
  	'<font face="Arial"> <font size="2"> User Name: '+
  	'<font face="Arial"> <font size="2">'+username+'</font></td></tr>'+str+'</table>';
        alert(str);
        */
       	 UserDetailWindow= window.open("", "", "top=100, left=100, width=600, height=500"); 
	UserDetailWindow.document.write(str); 

  }
}

function call_Query_User_More(user_no)
{
 var username_id="username"+user_no; 
 var username;

var confirm_msg;
 	var cgi_url;
	var cookieStr;

 

	g_item=document.getElementById(username_id);
	username=g_item.value;
	g_username=username;
	g_user_no=user_no;
	
   	g_token=find_cookie_value("token");

// confirm_msg="Get User: "+username+" more Information?";
 cgi_url = "/server/query_user_more?token="+escape(g_token)+"&username="+escape(username)+"&flag="+Math.random();
  // alert(cgi_url);
// if (confirm(confirm_msg))
// {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Query_User_More;
	 xmlHttp.send(null);
 //}
 

}
function Update_User_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Update User Sucessfully");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    } else if (response==0)
    {
   	alert("Failed to Update User");
    }else if (response==3)
    {
   	alert("Primay Key can not be changed");
	call_get_all_user();
    }
	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
    }
}

//function call_Update_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Update_User(user_no)
{
 var username_id="username"+user_no; 
 var password_id="password"+user_no; 
 var group_id="group"+user_no; 
 var expired_time_id="expired_time"+user_no; 
 //var paymodel_id="paymodel"+user_no; 
 //var user_point_id="user_point"+user_no;
 var userip_id="userip"+user_no;
 var macid_id="macid"+user_no;

 var szpassword;
 var szgroup;
 var expired_time;
 //var paymodel;
 //var user_point;
 var username;
 var userip;
 var macid;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 var d=new Date();
 var cur_year=d.getFullYear();
 var cur_month=d.getMonth()+1;
 var cur_date=d.getDate();
 var alert_message;
 
	g_item=document.getElementById(username_id);
	username=g_item.value;
	if (username.length==0)
	{
		alert("User name is empty");
		return;
	}	
	g_item=document.getElementById(expired_time_id);
	expired_time=g_item.value;
	if (expired_time.length==0)
	{
		alert("Expired Time is empty");
		return;
	}else if (expired_time.length>10)
	{
		alert("Date Length is too long(>10)");
		return;
	}
	
	if (g_user_authorization_mode==1)
	 {
		g_item=document.getElementById(password_id);
		szpassword=g_item.value;
		if (szpassword.length==0)
		{
			alert("Pawword is empty");
			return;
		}
		pos=expired_time.indexOf('/');
		expired_MM=expired_time.substring(0,pos);
		expired_time_temp=expired_time.substring(pos+1);
		pos=expired_time_temp.indexOf('/');	
		expired_DD=expired_time_temp.substring(0,pos);
		expired_YY=expired_time_temp.substring(pos+1);
		
			//	alert_message=cur_year+'/'+cur_month+'/'+cur_date+'--'+expired_YY+'/'+expired_MM+'/'+expired_DD;
	   	    	//alert(alert_message);
	
		if (expired_YY<cur_year)
		{
			alert_message="Expired Year should be >="+cur_year;
			alert(alert_message);
			return;
		}
		if ((expired_MM<1)||(expired_MM>12))
		{
			alert("Exipred Month should be between 1 and 12");
			return;
		}
		if ((expired_YY==cur_year)&&(expired_MM<cur_month))
		{
			alert_message="Expired Month should be >"+cur_month;
			alert(alert_message);
			return;
			
		}
		if ((expired_DD<1)||(expired_DD>31))
		{
			alert("Exipred Date should be between 1 and 30");
			return;
		}
		if ((expired_YY==cur_year)&&(expired_MM==cur_month)&&(expired_DD<cur_date))
		{
			alert_message="Expired Date should be >"+cur_date;
			alert(alert_message);
			return;
		}		
		
	}else if (g_user_authorization_mode==2)
	{
		szpassword=null;
	}
		


	
	g_item=document.getElementById(group_id);
	szgroup=g_item.value;
//	g_item=document.getElementById(paymodel_id);
//	paymodel=g_item.value;
//	g_item=document.getElementById(user_point_id);
//	user_point=g_item.value;
	g_item=document.getElementById(userip_id);
	userip=g_item.value;
	g_item=document.getElementById(macid_id);
	macid=g_item.value;
	
   	g_token=find_cookie_value("token");

 confirm_msg="Update User: "+username+" Information?";
// cgi_url = "/server/update_user?token="+escape(g_token)+"&user_no="+escape(user_no)+"&username="+escape(username)+
 cgi_url = "/server/update_user?token="+escape(g_token)+"&username="+escape(username)+
  "&password="+szpassword+
  "&group="+szgroup+
  "&expired_time="+expired_time+
//  "&paymodel="+paymodel+
//  "&user_point="+user_point+
  "&userip="+userip+
  "&macid="+macid+
   "&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Update_User_Info;
	 xmlHttp.send(null);
	 g_item=document.getElementById(expired_time_id);
	 g_temp=g_item.value;
	 //g_item.value=g_item.value+" (updating...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}


//function call_get_all_user() {
function call_get_all_user_detail() {
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
   var content = parent.document.getElementById("content");
 // var detail = parent.document.getElementById("detail");
	

	content.innerHTML="";
//	detail.innerHTML="";

  	
  	g_token=find_cookie_value("token");

 cgi_url = "/server/query_all_user?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">User Information Loading...<p>';

 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = get_all_user;
 xmlHttp.send(null);

}
function user_authorization_mode()
{
if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
	    g_user_authorization_mode=response;
	    callServer_System_Inquery();
	    g_System_timer=setInterval(function(){callServer_System_Inquery_Timer()},60*1000);
	  //  alert(g_user_authorization_mode);
	  //  show_uptime();
    }
}

function call_user_authorization_mode() {
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
  	
  	g_token=find_cookie_value("token");

	 cgi_url = "/server/query_user_authorization?token="+escape(g_token)+"&flag="+Math.random();
	  xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = user_authorization_mode;
	 xmlHttp.send(null);

}  

function call_get_all_user() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
   	g_token=find_cookie_value("token");
	
	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;
	if (g_token!=0)
	{
		cgi_url = "/server/query_group?token="+escape(g_token)+"&flag="+Math.random();
		
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = group_inquery_item;
		xmlHttp.send(null);
	}

}

function Download_User_Chlist() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
      /* if ((response==1))
    {
	    		alert("For security, root can not create channel list");
    }else*/
    if ((response==0))
    {
	    		alert("Can not create channel list");
    }else
    {
	    if (response.length>0)
	    
	    {
	    	window.location =response; 
	    }else
	    	{
	    		alert("Can not create channel list");
	    	}
	    	
    }
}
}
function call_download_user_chlist(user_no,sObj)
{
 var username_id="username"+user_no; 
 var username;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(username_id);
	username=g_item.value;
	
   	g_token=find_cookie_value("token");
	//alert(user_no);
	//alert(sObj.value);
 	cgi_url = "/server/call_download_user_chlist?token="+escape(g_token)+"&hostname="+location.hostname+"&username="+escape(username)+"&ch_list_type="+sObj.value+"&flag="+Math.random();
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Download_User_Chlist;
	 xmlHttp.send(null); 

}
function get_all_user()
{
 
  if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
     var username;
    var szpassword;
    var szgroup;
    var expired_timel
   // var paymodel;
  //  var paymodel_option;
  //  var user_point;
    var userip;
    var macid;
    var reseller;
    var user_title="<p>"+"User List"+"</p>";
    var user_list;
    var i=0;
    var user_no=1;
	var total_user_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
   var content = parent.document.getElementById("content");
  //var detail = parent.document.getElementById("detail");
  var expired_YY;
  var expired_MM;
  var expired_DD;
  var d=new Date();
  	var cur_year=d.getFullYear();
  	var cur_month=d.getMonth()+1;
  	var cur_day=d.getDate();
  	var bexpired=0;
  	var pos;
  	var expired_time_temp;
  	var yearmsg;
  	var menustr;

	content.innerHTML="";
	//detail.innerHTML="";
	
	content.innerHTML="";
	 HTML_str= '<table border="0 align="center">'+
	  '<tr>'+
	      '<td width="10%" align="center"><font face="Arial" size="2">User no</font></td>';
	      if (g_user_authorization_mode==1)
	      {
		     HTML_str+='<td width="10%" align="center"><font face="Arial" size="2">User Name<br>(Primary Key)</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">Password</font></td>';
		      HTML_str+='<td width="15%" align="center"><font face="Arial" size="2">Bouquet</font></td>'+
		      '<td width="15%" align="center"><font face="Arial" size="2">CH List</font></td>'+
		      '<td width="15%" align="center"><font face="Arial" size="2">Expired Time / Paid Days<br>(MM/DD/YYYY)/ (Number)</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">IP</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">MAC ID</font></td>'+
		      '<td width="5%" align="center"><font face="Arial" size="2">Reseller</font></td>'+
	//	      '<td width="10%" align="center"><font face="Arial" size="2">DRM Model</font></td>'+
	//	      '<td width="5%" align="center"><font face="Arial" size="2">DRM Points</font></td>'+
	 	 '</tr>'+'<tr><td  colspan="9"><hr size="1" color="#66FFFF"></td></tr>';
	      }else if (g_user_authorization_mode==2)
	      {
	      	HTML_str+='<td width="20%" align="center"><font face="Arial" size="2">PIN No.(Primary Key)</font></td>';
		      HTML_str+='<td width="15%" align="center"><font face="Arial" size="2">Bouquet</font></td>'+
		      '<td width="15%" align="center"><font face="Arial" size="2">CH List</font></td>'+
		      '<td width="15%" align="center"><font face="Arial" size="2">Expired Time / Paid Days<br>(MM/DD/YYYY)/ (Number)</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">IP</font></td>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">MAC ID</font></td>'+
		      '<td width="5%" align="center"><font face="Arial" size="2">Reseller</font></td>'+
//		      '<td width="10%" align="center"><font face="Arial" size="2">DRM Model</font></td>'+
//		      '<td width="5%" align="center"><font face="Arial" size="2">DRM Points</font></td>'+
	 	 '</tr>'+'<tr><td  colspan="8"><hr size="1" color="#66FFFF"></td></tr>';
	      }
	      	
 	
	while (1)
	{
 	 	if (response[i]==0) break;
		//alert(response[i]);
	 	strlength=response[i].length;
   	    	username=response[i].slice(9,strlength);
     	 	strlength=response[i+1].length;
   	    	szpassword=response[i+1].slice(9,strlength);
    	 	strlength=response[i+2].length;
   	    	szgroup=response[i+2].slice(6,strlength);
	 	strlength=response[i+3].length;
   	    	expired_time=response[i+3].slice(13,strlength);

	 	pos=expired_time.indexOf('/');
		expired_MM=expired_time.substring(0,pos);
		expired_time_temp=expired_time.substring(pos+1);
		pos=expired_time_temp.indexOf('/');	
		expired_DD=expired_time_temp.substring(0,pos);
		expired_YY=expired_time_temp.substring(pos+1);
		//yearmsg=cur_year+'/'+cur_month+'/'+cur_day+'--'+expired_YY+'/'+expired_MM+'/'+expired_DD;
   	    	//alert(yearmsg);

   	    	bexpired=0;
   	    	if (cur_year<expired_YY)
   	    	{
   	    		bexpired=0;
   	    	}else if (cur_year==expired_YY)
   	    	{
	   	    	if (cur_month<expired_MM)
	   	    	{
	   	    		bexpired=0;
	   	    	}else if (cur_month==expired_MM)
	   	    	{	
		   	    	if (cur_day>expired_DD)
		   	    	{
		   	    		bexpired=1;
		   	    	}else
	   	    		{
	   	    			bexpired=0;
	   	    		}
	   	    	}else if (cur_month>expired_MM)
	   	    	{
	   	    		bexpired=1;
	   	    	}
	   	    	
   	    	}else if (cur_year>expired_YY)
    		{
    			bexpired=1;
    		}
    	
   	    	
   	    	
     	 	//strlength=response[i+4].length;
     	 	
   	    	//paymodel=response[i+4].slice(9,strlength);
	 	//strlength=response[i+5].length;
   	    	//user_point=response[i+5].slice(11,strlength);
	 	strlength=response[i+4].length;
   	    	userip=response[i+4].slice(7,strlength);
	 	strlength=response[i+5].length;
   	    	macid=response[i+5].slice(6,strlength);
	 	strlength=response[i+6].length;
   	    	reseller=response[i+6].slice(9,strlength);
 
 		i=i+7;
		HTML_str=HTML_str+
		   '<tr>';
		   if (g_user_authorization_mode==1)
		   {
		      HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
		      '<td width="10%" align="center">'+
	 		' <font face="Arial" font size="2">'+
	 		' <input type="text" name="username"'+
	 		' id=username'+user_no+' size="12" value="'+
	 		username+'"/></font></td>'+
	 		
		      '<td width="10%" align="center">'+
	 		' <font face="Arial" font size="2">'+
	 		' <input type="text" name="password"'+
	 		' id=password'+user_no+' size="12" value="'+
	 		szpassword+'"/></font></td>';
		   }else if (g_user_authorization_mode==2)
	 		{
		 		HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
			      '<td width="20%" align="center">'+
		 		' <font face="Arial" font size="2">'+
		 		' <input type="text" name="username"'+
		 		' id=username'+user_no+' size="36" value="'+
		 		username+'"/></font></td>';
	 		}
	 		

		      HTML_str=HTML_str+'<td width="15%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="group" id=group'+user_no+'>';
	 		for (j=0;j<g_total_group_no;j++)
	 		{
	 			groupname=g_groupname_array[j];
	 			if (szgroup.search(groupname)==-1)
	 			{
	 				HTML_str+='<option value="'+groupname+'">'+groupname+'</option>';
	 			}
	 			else 
	 			{
	 				if (szgroup.length==groupname.length)
	 				{
	 					HTML_str+='<option selected="selected" value="'+groupname+'">'+groupname+'</option>';
	 				}else
	 				{
	 					HTML_str+='<option value="'+groupname+'">'+groupname+'</option>';
	 				}
	 			}	 			
	 		}
	  		HTML_str+='</select></font></td>';
	  		
	  		HTML_str=HTML_str+'<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" onchange="call_download_user_chlist('+user_no+','+'chlist'+user_no+')" name="ch_list" id=chlist'+user_no+'>'+
 			'<option value="-1">--</option>'+
			'<option value="enigma">Enigma</option>'+
			'<option value="enigma16">Enigma 1.6</option>'+
			'<option value="enigma(RTMP)">Enigma(RTMP)</option>'+
			'<option value="enigma16(RTMP)">Enigma 1.6(RTMP)</option>'+
			'<option value="m3u_no">m3u(by chno)</option>'+
 			'<option value="m3u_name">m3u(by chname)</option>'+
 			'<option value="m3ue_no">m3u(by chno with suffix)</option>'+
 			'<option value="m3ue_name">m3u(by chname with suffix)</option>'+
			'<option value="octagon">octagon</option>'+
			'<option value="ariva">ariva</option>'+
 			'<option value="xbmc">XBMC</option>'+
 			'<option value="pure">Pure</option>'+
			'<option value="optumuss">Optumuss</option>'+
			'<option value="amiko">Amiko</option>'+
			'<option value="spark">Spark</option>'+
			'<option value="tiger">Tiger</option>'+
			'<option value="nstreamvod">nStreamVOD</option>'+
			'<option value="script_enigma">*Enigma Script*</option>'+
			'<option value="script_enigma16">*Enigma16 Script*</option>'+
			'<option value="script_mac_address">*MAC Address Script*</option>';
	  		HTML_str+='</select></font></td>';		
	  		                         
 
	  		
	  		
	  		if (bexpired==0)
	  		{	 		 		
			      HTML_str+='<td width="18%" align="center">'+
		 		' <font face="Arial"> <font size="2">'+
		 		' <input type="text" name="expired_time"'+
		 		' id=expired_time'+user_no+' size="12" value="'+
		 		expired_time+'"/></font></td>';		
	 		}else
	 		{
	 			
	 			HTML_str+='<td width="18%" align="center">'+
		 		' <font face="Arial"> <font size="2">'+
		 		' <input type="text" name="expired_time"  style="background:#ff0000"'+
		 		' id=expired_time'+user_no+' size="12" value="'+
		 		expired_time+'"/></font></td>';		

	 	}
	 	
	 		HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		' <input type="text" name="userip"'+
	 		' id=userip'+user_no+' size="12" value="'+
	 		userip+'"/></font></td>';	 			

	 		HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		' <input type="text" name="macid"'+
	 		' id=macid'+user_no+' size="12" value="'+
	 		macid+'"/></font></td>';	 			

	 		HTML_str+='<td id=reseller'+user_no+' width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		reseller+'</font></td>'+	 			
	 		
		    /*  HTML_str+='<td width="15%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
			' <select size="1" name="paymodel" id=paymodel'+user_no+'>';
	 		for (j=0;j<3;j++)
	 		{
	 			paymodel_option=g_paymodel_array[j];
	 			if (paymodel.search(paymodel_option)==-1)
	 			{
	 				HTML_str+='<option value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}
	 			else
	 			{
	 				HTML_str+='<option selected="selected" value="'+paymodel_option+'">'+paymodel_option+'</option>';
	 			}	 			
	 		}
	  		HTML_str+='</select></font></td>';
	 		*/
		      /* HTML_str+='<td width="10%" align="center">'+
	 		' <font face="Arial"> <font size="2">'+
	 		' <input type="text" name="user_point"'+
	 		' id=user_point'+user_no+' size="12" value="'+
	 		user_point+'"/></font></td>'+
	 		*/
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Update_User("'+user_no+'")>'+
	      	      ' <font face="Arial"" size="2">Save</font></a></td>';
		      if (username!="root")
		      {
			      	HTML_str+='<td width="80" align="center">'+
			      "<a href='javascript:void(0)'"+
			      ' onclick=call_Del_User("'+user_no+'")>'+
		      	      ' <font face="Arial"" size="2">Del</font></a></td>';
	      	      }
	      	      
		      HTML_str+='<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Query_User_More("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">More</font></a></td>'+
		    '</tr>';
		total_user_no++;
		user_no++;
		//alert(HTML_str);
    }
        HTML_str=HTML_str+'</table>';
       //  alert(user_list_info.innerHTML);
   	menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td>'+
 	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_get_all_user()>"+
 	      ' <font face="Arila" size="2">Refresh</font></a>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_Add_New_User()>"+
	      ' <font face="Arila" size="2">Add</font></a>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_export_user_profile()>"+
	      ' <font face="Arila" size="2">Export</font></a>'+
	      //'&nbsp&nbsp&nbsp'+
	      // "<a href='javascript:void(0)' onclick=callServer_group_Inquery()>"+
	      // '<font size="2" face="Arial">Group</font></a>'+
	      '</td></tr></table>';
	 content.innerHTML=menustr+HTML_str+menustr;
	g_user_no=total_user_no;
 }

 
}
function blacklist_remove_all()
{
 
 if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
      if (response==1)
    {
	 callServer_blacklist_Inquery();
    } else
    {
   	alert("Failed to Remove All");
   }
 g_remove_all_button.innerHTML='<font face="Arial" size="2">Remove</font>';
    	
  }
}
function call_blacklist_remove_all() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
	
  	g_token=find_cookie_value("token");
 	g_remove_all_button= document.getElementById("blacklist_remove_all");
 	//alert(g_remove_all_button);
	confirm_msg="Remove All?";
	if (confirm(confirm_msg))
	{
	 cgi_url = "/server/remove_all_black_list?token="+escape(g_token)+"&flag="+Math.random();
	
     	 g_remove_all_button.innerHTML='<font size="2" face="Arial">Removing</font>';
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = blacklist_remove_all;
	 xmlHttp.send(null);
	 }

}
function blacklist_remove_ip()
{
 
 if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
	// g_blacklist_remove_item.innerHTML='<font face="Arial" size="2">Remove</font>';
	 callServer_blacklist_Inquery();
    } else
    {
   	alert("Failed to Remove");
 	callServer_blacklist_Inquery();

//  	g_blacklist_remove_item.innerHTML='<font face="Arial" size="2">Remove</font>';
  }
    	
  }
}
function callServer_blacklist_remove_ip(ip) {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var confirm_msg;
	
	blacklist_ip_remove_button="blacklist_ip_remove_button="+ip;
// alert(blacklist_ip_remove_button);
//    var detail = parent.document.getElementById("detail");
	g_blacklist_remove_item=document.getElementById(blacklist_ip_remove_button);
  	g_token=find_cookie_value("token");
	confirm_msg="Remove "+ip+" ?";
	if (confirm(confirm_msg))
	{
	 cgi_url = "/server/remove_ip_black_list?token="+escape(g_token)+"&ipaddress="+ip+"&flag="+Math.random();
	// alert(cgi_url);
	
	g_blacklist_remove_item.innerHTML='<font face="Arial" size="2">Removing</font>';
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = blacklist_remove_ip;
	 xmlHttp.send(null);
	 }

}
function blacklist_inquery()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
 /*   var group_no;
    var group_name;
    var group_concurrent_connection;
    var group_src;
    var group_title="<p>"+"Group List"+"</p>";
    var group_list;
   */
   var ip_no;
   var username;
   var ip;
   var macid;
   var country;
    var i=0;
 	var blacklist_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
 //   var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");

	//content.innerHTML="";
	 HTML_str= '<table border="0" align="center">'+
	  '<tr>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">No.</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">User</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">IP</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">MAC Address</font></td>'+
	      '<td width="100" height="17" align="center"><font face="Arila" size="2">Country</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Failed Login times</font></td>'+
	      '<td width="200" height="17" align="center"><font face="Arila" size="2">Available Login times</font></td>'+
 	      '</tr>'+'<tr><td  colspan="7"><hr size="1" color="#66FFFF"></td></tr>';
 	

	 while (1)
	{
 	 	if (response[i]==0) break;
		//alert(response[i]);
	 	strlength=response[i].length;
	 	//alert(strlength);
   	    	ip_no=response[i].slice(3,strlength);
   	    	//alert(ip_no);
     	 	strlength=response[i+1].length;
   	    	username=response[i+1].slice(9,strlength);

     	 	strlength=response[i+2].length;
   	    	ip=response[i+2].slice(3,strlength);
   	    	//alert(ip);
   	    	
    	 	strlength=response[i+3].length;
   	    	macid=response[i+3].slice(6,strlength);
   	    	
    	 	
    	 	strlength=response[i+4].length;
   	    	country=response[i+4].slice(8,strlength);
   	    	//alert(country);
   	    	
   	 	strlength=response[i+5].length;
   	    	tryno=response[i+5].slice(6,strlength);

   	 	strlength=response[i+6].length;
   	    	availno=response[i+6].slice(8,strlength);
 
 		i=i+7;
		blacklist_no++;
		HTML_str=HTML_str+
		   '<tr>'+
		      '<td width="100" align="center"><font face="Arila" size="2">'+ip_no+'</font></td>'+
		      '<td width="100" align="center"><font face="Arila" size="2">'+username+'</font></td>'+
		      '<td width="100" align="center"><font face="Arila" size="2">'+ip+'</font></td>'+
		      '<td width="100" align="center"><font face="Arila" size="2">'+macid+'</font></td>'+
		      '<td width="100" align="center"><font face="Arila" size="2">'+country+'</font></td>'+
		      '<td width="200" align="center"><font face="Arila" size="2">'+tryno+'</font></td>'+
		      '<td width="200" align="center"><font face="Arila" size="2">'+availno+'</font></td>'+

		      '<td id=blacklist_ip_remove_button='+ip+' width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=callServer_blacklist_remove_ip("'+ip+'")>'+
	      	      ' <font face="Arila" size="2">Remove</font></a></td>'+
		    '</tr>';
		   // alert(HTML_str);
     }
        //detail.innerHTML=HTML_str;
      // alert(menu_main.innerHTML);
  
  	content.innerHTML='<table width=99%><tr><td width=20%>'+
  	'<font face="Arial" size="2">Total: '+ blacklist_no+'</td>'+
  	      '<td id=blacklist_remove_all width=70% align="right">'+"<a href='javascript:void(0)' onclick=callServer_blacklist_Inquery()>"+
	      '<font face="Arila" size="2">Reresh</font></a></td>'+
 	      '<td id=blacklist_remove_all width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_blacklist_remove_all()>"+
	      '<font face="Arila" size="2">Remove All</font></a></td></tr></table>'+HTML_str; 
	   //   alert(content.innerHTML);
 }

 
}

function callServer_blacklist_Inquery() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");
  	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

 cgi_url = "/server/query_black_list?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Blacklist Loading...<p>';


 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = blacklist_inquery;
 xmlHttp.send(null);

}
function Disable_Balancer_Respponse() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    
 	 var balancer_header_item=document.getElementById("balancer_header");
	 balancer_header_item.innerHTML='<font face="Arial" size="2"><input type="radio" value="V1" checked name="R1" onclick="javascript:checked_disable_balancer()"><b>Disabled</b><input type="radio" name="R1" value="V3" onclick="javascript:checked_master_balancer()"><b>Master Server</b><input type="radio" name="R1" value="V4" onclick="javascript:checked_edge_balancer()"><b>Edge Server</b></font>';
    	callServer_balancer_Inquery();
    }
 
}
function Checked_Master_Balancer_Respponse() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
 	 var balancer_header_item=document.getElementById("balancer_header");
	 balancer_header_item.innerHTML='<font face="Arial" size="2"><input type="radio" value="V1" name="R1" onclick="javascript:checked_disable_balancer()"><b>Disabled</b><input type="radio" name="R1" value="V3" checked onclick="javascript:checked_master_balancer()"><b>Master Server</b><input type="radio" name="R1" value="V4" onclick="javascript:checked_edge_balancer()"><b>Edge Server</b></font>';
    	callServer_balancer_Inquery();
    }
 
}
function Checked_Edge_Balancer_Respponse() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
	 var balancer_header_item=document.getElementById("balancer_header");
	 balancer_header_item.innerHTML='<font face="Arial" size="2"><input type="radio" value="V1" name="R1" onclick="javascript:checked_disable_balancer()"><b>Disabled</b><input type="radio" name="R1" value="V3" onclick="javascript:checked_master_balancer()"><b>Master Server</b><input type="radio" name="R1" value="V4" checked onclick="javascript:checked_edge_balancer()"><b>Edge Server</b></font>';
  	callServer_balancer_Inquery();
    }
 
}

function checked_disable_balancer()
{
	 confirm_msg="Disable Balancer?";
	 if (confirm(confirm_msg))
	 {
		 cgi_url = "/server/disable_balancer?token="+escape(g_token)+"&flag="+Math.random();	
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Disable_Balancer_Respponse;
		 xmlHttp.send(null);
		 var balancer_header_item=document.getElementById("balancer_header");
		 balancer_header_item.innerHTML='<font face="Arial" size="2"><b>Updating</b></font>';
	 }else
	{
		callServer_balancer_Inquery();
	}
	 	
 }
function checked_master_balancer()
{
	 confirm_msg="Change to Master Server?";
	 if (confirm(confirm_msg))
	 {
		 cgi_url = "/server/checked_master_balancer?token="+escape(g_token)+"&flag="+Math.random();	
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Checked_Master_Balancer_Respponse;
		 xmlHttp.send(null);
		 var balancer_header_item=document.getElementById("balancer_header");
		 balancer_header_item.innerHTML='<font face="Arial" size="2"><b>Updating</b></font>';
	} else
 	{
 		callServer_balancer_Inquery();
 	}
}
function checked_edge_balancer()
{
	 confirm_msg="Change to Edge Server";
	 if (confirm(confirm_msg))
	 {
		 cgi_url = "/server/checked_edge_balancer?token="+escape(g_token)+"&flag="+Math.random();	
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Checked_Edge_Balancer_Respponse;
		 xmlHttp.send(null);
		 var balancer_header_item=document.getElementById("balancer_header");
		 balancer_header_item.innerHTML='<font face="Arial" size="2"><b>Updating</b></font>';
	} else
 	{
 		callServer_balancer_Inquery();
 	}
}

function Cancel_Add_Balancer()
{
	callServer_balancer_Inquery();

}
function Update_Blancer() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    //	alert("Add Server Sucessfully");
    } else if (response==0)
    {
   	alert("Failed to Update Server");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    }else if (response==3)
    {
    	alert("The Server is already in Database");
    }

	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	callServer_balancer_Inquery();
    }
}

function call_Update_Blancer(user_no)
{

	var servername_id="servername"+user_no;
	var username_id="username"+user_no;
	var szpassword_id="password"+user_no;
	var server_ip_id="server_ip"+user_no;
	var panel_port_id="panel_port"+user_no;
	var country_id="country"+user_no;
	var servername;
	var username;
	var szpassword;
	var server_ip;
	var panel_port;
	var country;
	var confirm_msg;
	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var pos;
	var alert_message;


 	g_item=document.getElementById(servername_id);
	servername=g_item.value;
	g_item=document.getElementById(username_id);
	username=g_item.value;
	g_item=document.getElementById(szpassword_id);
	szpassword=g_item.value;
	g_item=document.getElementById(server_ip_id);
	server_ip=g_item.value;
	g_item=document.getElementById(panel_port_id);
	panel_port=g_item.value;
	g_item=document.getElementById(country_id);
	country=g_item.value;
	if (servername.length==0)
	{
		alert("Server Name is empty");
		return;
	}

   	g_token=find_cookie_value("token");

	cgi_url = "/server/update_balancer?token="+escape(g_token)+"&servername="+escape(servername)+
	"&username="+escape(username)+
	"&password="+escape(szpassword)+
	"&server_ip="+escape(server_ip)+
	"&panel_port="+escape(panel_port)+
	"&country="+escape(country)+
	"&flag="+Math.random();
	//  alert(cgi_url);
	confirm_msg="Update Server "+servername+" ?";
	if (confirm(confirm_msg))
	{
	
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange = Update_Blancer;
		xmlHttp.send(null);
		g_temp=g_item.value;
		// g_item.value=g_item.value+" (Updating...)";
		g_item.style.backgroundColor = "#ff0000";
	}


}
function Add_Blancer() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    //	alert("Add Server Sucessfully");
    } else if (response==0)
    {
   	alert("Failed to Add Server");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    }else if (response==3)
    {
    	alert("The Server is already in Database");
    }

	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	callServer_balancer_Inquery();
    }
}

function call_Add_Blancer(user_no)
{

var servername_id="servername"+user_no;
var username_id="username"+user_no;
var szpassword_id="password"+user_no;
var server_ip_id="server_ip"+user_no;
var panel_port_id="panel_port"+user_no;
var country_id="country"+user_no;
var servername;
var username;
var szpassword;
var server_ip;
var panel_port;
var country;




var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var pos;
	var expired_time_temp;
 	var pos;
	var expired_time_temp;
	var alert_message;


 	g_item=document.getElementById(servername_id);
	servername=g_item.value;
	g_item=document.getElementById(username_id);
	username=g_item.value;
	g_item=document.getElementById(szpassword_id);
	szpassword=g_item.value;
	g_item=document.getElementById(server_ip_id);
	server_ip=g_item.value;
	g_item=document.getElementById(panel_port_id);
	panel_port=g_item.value;
	g_item=document.getElementById(country_id);
	country=g_item.value;
	if (servername.length==0)
	{
		alert("Server Name is empty");
		return;
	}
	if (username.length==0)
	{
		alert("Admin. Name is empty");
		return;
	}
	if (szpassword.length==0)
	{
		alert("Password is empty");
		return;
	}
	if (server_ip.length==0)
	{
		alert("IP is empty");
		return;
	}
	if (panel_port.length==0)
	{
		alert("Panel Port is empty");
		return;
	}
	if (country.length==0)
	{
		alert("Country is empty");
		return;
	}
   	g_token=find_cookie_value("token");

  cgi_url = "/server/add_balancer?token="+escape(g_token)+"&servername="+escape(servername)+
 "&username="+escape(username)+
 "&password="+escape(szpassword)+
 "&server_ip="+escape(server_ip)+
 "&panel_port="+escape(panel_port)+
 "&country="+escape(country)+
 "&flag="+Math.random();
 //  alert(cgi_url);
confirm_msg="Add Server "+servername+" ?";
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_Blancer;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (Adding...)";
	g_item.style.backgroundColor = "#ff0000";
 }


}

function call_Add_New_Balancer()
{

var HTML_str;
var user_no;
var len;
var servername;
var username;
var szpassword;
var userip;
var panel_port;
var country;var str;
var content = parent.document.getElementById("content");
	

	g_balancer_server_no++;

	HTML_str=content.innerHTML;
	//alert(HTML_str);
	//len=HTML_str.length-16;
	len=HTML_str.lastIndexOf("<TABLE");
	
	if (len==-1)
	{
		len=HTML_str.lastIndexOf("<table");
	}
		
		//HTML_str=HTML_str.slice(800,len);
		//alert(HTML_str);
//	alert(len);
	//len+=6;
	HTML_str=HTML_str.slice(0,len);

	user_no=g_balancer_server_no;
//	alert(HTML_str);
	HTML_str=HTML_str+'<tr><td><table><tr>';
			HTML_str+='<td width="5%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>';
			HTML_str+='<td width="15%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="servername"'+
			' id=servername'+user_no+' size="20"></font></td>';

	
			HTML_str+='<td width="10%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="username"'+
			' id=username'+user_no+' size="12" value=root></font></td>';
			
			HTML_str+='<td width="20%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="password"'+
			' id=password'+user_no+' size="20"></font></td>';
	
			HTML_str+='<td width="10%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="server_ip"'+
			' id=server_ip'+user_no+' size="12" value=192.168.0.8></font></td>';
	
			HTML_str+='<td width="10%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="panel_port"'+
			' id=panel_port'+user_no+' size="12" value=18000></font></td>';
	
			HTML_str+='<td width="15%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="country"'+
			' id=country'+user_no+' size="20"></font></td>';
			
			HTML_str+='<td width="10%" align="center" id=server_status'+user_no+'>'+
				'<b><font color="#FF0000" face="Arial" size="2">OFF</font></b></td>';	
	 		
		      HTML_str+='<td id=add_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_Blancer("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>'+
	      	      
		      '<td width="40" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=Cancel_Add_Balancer()>'+
	      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

		    '</tr></table></td></tr>';
	//alert(HTML_str);

	       content.innerHTML=HTML_str+'</table>';
  //      alert(user_list_info.innerHTML);
   
		
}

function Del_Balancer() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Delete Server Sucessfully");
    } else if (response==2)
    {
     	alert("Disk is error(FULL), Please contact administrator");  	
    } else if (response==0)
    {
   	alert("Failed to Delete Server");
    }
    	callServer_balancer_Inquery();
    }
}

//nction call_Del_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Del_Balancer(user_no)
{
var servername_id="servername"+user_no;
var servername;
var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(servername_id);
	servername=g_item.value;
	
   	g_token=find_cookie_value("token");

 confirm_msg="Delete Server: "+servername+" ?";
 cgi_url = "/server/del_balancer?token="+escape(g_token)+"&servername="+escape(servername)+"&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_Balancer;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}

function Query_Edge_Server() {

  if (xmlHttp.readyState == 4) {
	var response = xmlHttp.responseText.split("\r\n");
	var servername_id="servername"+g_edge_server_no;
	var username_id="username"+g_edge_server_no;
	var szpassword_id="password"+g_edge_server_no;
	var server_ip_id="server_ip"+g_edge_server_no;
	var panel_port_id="panel_port"+g_edge_server_no;
	var country_id="country"+g_edge_server_no;
	var max_connection_no_id="max_connection_no"+g_edge_server_no;
	var free_conneciton_no_id="free_conneciton_no"+g_edge_server_no;
	var server_status_id="server_status"+g_edge_server_no;
	
	var servername_id_item=document.getElementById(servername_id);
	var username_id_item=document.getElementById(username_id);
	var szpassword_id_item=document.getElementById(szpassword_id);
	var server_ip_id_item=document.getElementById(server_ip_id);
	var panel_port_id_item=document.getElementById(panel_port_id);
	var country_id_item=document.getElementById(country_id);
	var max_connection_no_id_item=document.getElementById(max_connection_no_id);
	var free_conneciton_no_id_item=document.getElementById(free_conneciton_no_id);
	var server_status_id_item=document.getElementById(server_status_id);
	
	var servername;
	var username;
	var szpassword;
	var userip;
	var panel_port;
	var country;
	var max_connection_no;
	var free_conneciton_no;
	var server_status;
	var i;
	
	i=0;
 	strlength=response[i].length;
    	servername=response[i].slice(11,strlength);
    	//alert(servername);
 	strlength=response[i+1].length;
    	username=response[i+1].slice(9,strlength);
    	//alert(username);
 	strlength=response[i+2].length;
    	szpassword=response[i+2].slice(9,strlength);
    	//alert(szpassword);
 	strlength=response[i+3].length;
    	server_ip=response[i+3].slice(10,strlength);
    	//alert(server_ip);
 	strlength=response[i+4].length;
    	panel_port=response[i+4].slice(11,strlength);
    	//alert(panel_port);
 	strlength=response[i+5].length;
    	country=response[i+5].slice(8,strlength);
    	//alert(country);
 	strlength=response[i+6].length;
    	max_connection_no=response[i+6].slice(13,strlength);

 	strlength=response[i+7].length;
    	free_conneciton_no=response[i+7].slice(8,strlength);

 	strlength=response[i+8].length;
    	server_status=response[i+8].slice(14,strlength);
     
        servername_id_item.value=servername;
	username_id_item.value=username;
	szpassword_id_item.value=szpassword;
	server_ip_id_item.value=server_ip;
	panel_port_id_item.value=panel_port;
	country_id_item.value=country;
	max_connection_no_id_item.innerHTML='<font face="Arial" size="2">'+max_connection_no+'</font>';
	free_conneciton_no_id_item.innerHTML='<font face="Arial" size="2">'+free_conneciton_no+'</font>';
	if (server_status==1)
	{
		server_status_id_item.innerHTML='<font face="Arial" size="2">ON</font>';
	}else if (server_status==2)
	{
		server_status_id_item.innerHTML='<font color="#00FF00" face="Arial" size="2">Checking</font>';
	}
	else {
		server_status_id_item.innerHTML='<b><font color="#FF0000" face="Arial" size="2">OFF</font></b>';
	}
	servername_id_item.style.backgroundColor= "#ffffff";
		
   }
}

//nction call_Del_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Query_Edge_Server(user_no)
{
var servername_id="servername"+user_no;
var servername;
var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(servername_id);
	servername=g_item.value;
	
	g_edge_server_no=user_no;
	
	
   	g_token=find_cookie_value("token");

 cgi_url = "/server/query_edge_server?token="+escape(g_token)+"&servername="+escape(servername)+"&flag="+Math.random();
  // alert(cgi_url);

	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Query_Edge_Server;
	 xmlHttp.send(null);
	g_item.style.backgroundColor = "#ff0000";

}
function balancer_inquery()
{
 
  if (xmlHttp.readyState == 4) {


	var response = xmlHttp.responseText.split("\r\n");
	var balancertype;
	var servername;
	var username;
	var szpassword;
	var userip;
	var panel_port;
	var country;
	var max_connection_no;
	var free_conneciton_no;
	var server_status;
	var user_title="<p>"+"User List"+"</p>";
	var user_list;
	var i=0;
	var user_no=1;
	var total_user_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
	var content = parent.document.getElementById("content");
	var menustr;

	content.innerHTML="";
	//detail.innerHTML="";
	
	content.innerHTML="";
	HTML_str= '<table border="0 align="center">';
	strlength=response[0].length;
	balancertype=response[0].slice(13,strlength);
	//alert(balancertype);
	if (balancertype==0)
	{		
		 HTML_str+= '<tr><td id=balancer_header colspan="10"><font face="Arial" size="2"><input type="radio" value="V1" checked name="R1" onclick="javascript:checked_disable_balancer()"><b>Disabled</b><input type="radio" name="R1" value="V3" onclick="javascript:checked_master_balancer()"><b>Master Server</b><input type="radio" name="R1" value="V4" onclick="javascript:checked_edge_balancer()"><b>Edge Server</b></font></td></tr>';
	}else if (balancertype==2)
	{
		 HTML_str+= '<tr><td id=balancer_header colspan="10"><font face="Arial" size="2"><input type="radio" value="V1" name="R1" onclick="javascript:checked_disable_balancer()"><b>Disabled</b><input type="radio" name="R1" value="V3" onclick="javascript:checked_master_balancer()"><b>Master Server</b><input type="radio" name="R1" value="V4" checked onclick="javascript:checked_edge_balancer()"><b>Edge Server</b></font></td></tr>';
	}else if (balancertype==1)
	{
		 HTML_str+= '<tr><td id=balancer_header colspan="10"><font face="Arial" size="2"><input type="radio" value="V1" name="R1" onclick="javascript:checked_disable_balancer()"><b>Disabled</b><input type="radio" name="R1" value="V3" checked onclick="javascript:checked_master_balancer()"><b>Master Server</b><input type="radio" name="R1" value="V4" onclick="javascript:checked_edge_balancer()"><b>Edge Server</b></font></td></tr>';
	}else if (balancertype==-1)
	{
		alert("For Prof. Version Only...");
	}
	if (balancertype!=-1)
	{
		i=i+1;	
		HTML_str+='</tr>'+'<tr><td  colspan="10"><hr size="1" color="#66FFFF"></td></tr>';
		  HTML_str+='<tr>'+
		      '<td width="5%" align="center"><font face="Arial" size="2">No.</font></td>';
			     HTML_str+='<td width="15%" align="center"><font face="Arial" size="2">Server Name<br>(Primary Key)</font></td>'+
			      '<td width="10%" align="center"><font face="Arial" size="2">Admin. Name</font></td>'+
			      '<td width="20%" align="center"><font face="Arial" size="2">Password</font></td>'+
			      '<td width="10%" align="center"><font face="Arial" size="2">IP</font></td>'+
			      '<td width="10%" align="center"><font face="Arial" size="2">Panel Port</font></td>'+
			      '<td width="15%" align="center"><font face="Arial" size="2">Country</font></td>'+
			      '<td width="10%" align="center"><font face="Arial" size="2">Max Connection</font></td>'+
			      '<td width="10%" align="center"><font face="Arial" size="2">Free Connection</font></td>'+
			      '<td width="10%" align="center"><font face="Arial" size="2">Status</font></td>'+
		 	 '</tr>'+'<tr><td  colspan="10"><hr size="1" color="#66FFFF"></td></tr>';
		      
		      	
	 	i=1;
		while (1)
		{
		 	if (response[i]==0) break;
			//alert(response[i]);
		 	strlength=response[i].length;
		    	servername=response[i].slice(11,strlength);
		    	//alert(servername);
		 	strlength=response[i+1].length;
		    	username=response[i+1].slice(9,strlength);
		    	//alert(username);
		 	strlength=response[i+2].length;
		    	szpassword=response[i+2].slice(9,strlength);
		    	//alert(szpassword);
		 	strlength=response[i+3].length;
		    	server_ip=response[i+3].slice(10,strlength);
		    	//alert(server_ip);
		 	strlength=response[i+4].length;
		    	panel_port=response[i+4].slice(11,strlength);
		    	//alert(panel_port);
		 	strlength=response[i+5].length;
		    	country=response[i+5].slice(8,strlength);
		    	//max_connection_no(country);
		 	strlength=response[i+6].length;
		    	max_connection_no=response[i+6].slice(13,strlength);
		    	//alert(max_connection_no);
		 	strlength=response[i+7].length;
		    	free_conneciton_no=response[i+7].slice(8,strlength);		    	
		    	//alert(free_conneciton_no)
		 	strlength=response[i+8].length;
		    	server_status=response[i+8].slice(14,strlength);
		    	//alert(server_status);
		
			i=i+9;
			HTML_str+='<tr>';
			HTML_str+='<td width="5%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>';
			HTML_str+='<td width="15%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="servername"'+
			' id=servername'+user_no+' size="20" value="'+
			servername+'"/></font></td>';
	
			HTML_str+='<td width="10%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="username"'+
			' id=username'+user_no+' size="12" value="'+
			username+'"/></font></td>';
			
			HTML_str+='<td width="20%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="password"'+
			' id=password'+user_no+' size="20" value="'+
			szpassword+'"/></font></td>';
	
			HTML_str+='<td width="10%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="server_ip"'+
			' id=server_ip'+user_no+' size="12" value="'+
			server_ip+'"/></font></td>';
	
			HTML_str+='<td width="10%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="panel_port"'+
			' id=panel_port'+user_no+' size="12" value="'+
			panel_port+'"/></font></td>';
	
			HTML_str+='<td width="15%" align="center">'+
			' <font face="Arial" font size="2">'+
			' <input type="text" name="country"'+
			' id=country'+user_no+' size="20" value="'+
			country+'"/></font></td>';
		 		
			HTML_str+='<td width="10%" align="center" id=max_connection_no'+user_no+'>'+
			'<font face="Arial" size="2">'+max_connection_no+'</font></td>';
			HTML_str+='<td width="10%" align="center" id=free_conneciton_no'+user_no+'>'+
			'<font face="Arial" color="#0000FF" size="2">'+free_conneciton_no+'</font></td>';
			if (server_status==1)
			{
				HTML_str+='<td width="10%" align="center" id=server_status'+user_no+'>'+
				'<font face="Arial" size="2">ON</font></td>';
			}else if (server_status==2)
			{
				HTML_str+='<td width="10%" align="center" id=server_status'+user_no+'>'+
				'<font color="#00FF00" face="Arial" size="2">Checking</font></td>';
			}
			else {
				HTML_str+='<td width="10%" align="center" id=server_status'+user_no+'>'+
				'<b><font color="#FF0000" face="Arial" size="2">OFF</font></b></td>';
			}
		
			HTML_str+='<td width="80" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Update_Blancer("'+user_no+'")>'+
			' <font face="Arial" size="2">Save</font></a></td>';
	
			HTML_str+='<td width="80" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Query_Edge_Server("'+user_no+'")>'+
			' <font face="Arial" size="2">Query</font></a></td>';
	
			HTML_str+='<td width="80" align="center">'+
			"<a href='javascript:void(0)'"+
			' onclick=call_Del_Balancer("'+user_no+'")>'+
			' <font face="Arial" size="2">Del</font></a></td>';
		
			HTML_str+='</tr>';
			total_user_no++;
			user_no++;
			//alert(HTML_str);
			
		}
		
		HTML_str=HTML_str+'</table>';
		if (balancertype>0)
		{
		menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td>'+
		      "<td width=80% align=right> <a href='javascript:void(0)' onclick=callServer_balancer_Inquery()>"+
		      ' <font face="Arila" size="2">Query All</font></a>'+
		      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_Add_New_Balancer()>"+
		      ' <font face="Arila" size="2">Add</font></a>'+
		      '</td></tr></table>';
		 }else
	 	{
			menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td></tr></table>';
	 	}
		 	
		 content.innerHTML=menustr+HTML_str+menustr;
		g_balancer_server_no=total_user_no;
	}
 }

 
}
function callServer_balancer_Inquery() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");
  	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

 cgi_url = "/server/query_balancer_list?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Balancer Loading...<p>';


 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = balancer_inquery;
 xmlHttp.send(null);

}
function create_enigma_chlist()
{
 
 if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
     if (response.length>1)
    {
    	alert(response);
    }else
    {		
  	alert("Failed to Create");
   }
   callServer_group_Inquery();
    	
    	
  }
}
function create_m3u8_ch_list()
{
 
 if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response.length>1)
    {
    	alert(response);
    }else
    {		
  	alert("Failed to Create");
   }
   callServer_group_Inquery();
    	
  }
}
function create_xbmc_ch_list()
{
 
 if (xmlHttp.readyState == 4) {
   var response = xmlHttp.responseText;
     if (response.length>1)
    {
   	alert(response);
    }else
    {		
  	alert("Failed to Create");
   }
   callServer_group_Inquery();
    	
    	
  }
}

function call_create_enigma_chlist() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");
  	var service_type;
  	
  	service_type=prompt("Please enter Service Type","1:0:1:0:0:0:0:0:0:0");
  	if (service_type!=null)
  	{

	 cgi_url = "/server/create_enigma_ch_list?token="+escape(g_token)+"&hostname="+location.hostname+"&enigma_serveice_parm="+service_type+"&flag="+Math.random();
	 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Creating Enigma Channel List...<p>';
	
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = create_enigma_chlist;
	 xmlHttp.send(null);
	 }

}
function call_create_m3u8_chlist() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");

 cgi_url = "/server/create_m3u8_ch_list?token="+escape(g_token)+"&hostname="+location.hostname+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Creating M3U8 Channel List...<p>';


 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = create_m3u8_ch_list;
 xmlHttp.send(null);

}
function call_create_xbmc_chlist() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");

 cgi_url = "/server/create_xbmc_ch_list?token="+escape(g_token)+"&hostname="+location.hostname+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Creating XBMC Channel List...<p>';


 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = create_xbmc_ch_list;
 xmlHttp.send(null);

}

function group_inquery()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var group_no;
    var group_name;
    var group_concurrent_connection;
    var group_src;
    var group_title="<p>"+"Group List"+"</p>";
    var group_list;
    var i=0;
 	var group_active_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
 //   var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
	

	//content.innerHTML="";
	 HTML_str= '<table border="0" align="center">'+
	  '<tr>'+
	      '<td width="100" align="center"><font face="Arila" size="2">Bouquet</font></td>'+
	      '<td width="150" align="cneter"><font face="Arila" size="2">Bouquet Name</font></td>'+
	      '<td width="200" align="center"><font face="Arila" size="2">Channel No.</font></td>'+
 	      '<td width="200" align="center"><font face="Arila" size="2"> User Multiple Connection</font></td>'+
 	 '</tr>'+'<tr><td  colspan="4"><hr size="1" color="#66FFFF"></td></tr>';
 	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
	 	strlength=response[i].length;
	 	//alert(strlength);
   	    	group_no=response[i].slice(3,strlength);
     	 	strlength=response[i+1].length;
   	    	group_name=response[i+1].slice(5,strlength);
    	 	
    	 	strlength=response[i+2].length;
   	    	group_concurrent_connection=response[i+2].slice(11,strlength);
   	    	
     	 	strlength=response[i+3].length;
   	    	group_src=response[i+3].slice(4,strlength);

 		i=i+4;
		group_active_no++;
		HTML_str=HTML_str+
		   '<tr>'+
		      '<td width="100" align="center"><font face="Arila" size="2">'+group_no+'</font></td>'+
		      '<td width="150" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="groupname"'+
	 		' id=groupname'+group_no+
	 		' size="20" value="'+
	 		group_name+'"/></font></td>'+
		      '<td width="200" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="groupsrc"'+
	 		' id=groupsrc'+group_no+
	 		' size="35" value="'+
	 		group_src+'"/></font></td>'+
	 		'<td width="150" align="center">'+
	 		' <font face="Arila" size="2">'+
	 		' <input type="text" name="groupconcurrentconnection"'+
	 		' id=groupconcurrentconnection'+group_no+
	 		' size="3" value="'+
	 		group_concurrent_connection+'"/></font></td>'+

		      '<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=callServer_update_group("'+group_no+'")>'+
	      	      ' <font face="Arila" size="2">Save</font></a></td>'+
		      '<td width="50" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Del_group("'+group_no+'")>'+
	      	      ' <font face="Arila" size="2">Del</font></a></td>'+
		    '</tr>';
     }
        //detail.innerHTML=HTML_str;
      // alert(menu_main.innerHTML);
  
  	content.innerHTML='<table cellspacing="10" width=99%><tr><td width=20%>'+
  	'<font face="Arial" size="2">Total: '+ group_active_no+'</td>'+
 	      '<td width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_Add_New_group()>"+
	      '<font face="Arila" size="2">Add Bouquet</font></a></td>'+
	      /*
 	      '<td width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_create_enigma_chlist()>"+
	      '<font face="Arila" size="2">Create Enigma CHlist</font></a></td>'+
 	      '<td width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_create_m3u8_chlist()>"+
	      '<font face="Arila" size="2">Create M3U8 CHlist</font></a></td>'+
 	      '<td width=10% align="right">'+"<a href='javascript:void(0)' onclick=call_create_xbmc_chlist()>"+
	      '<font face="Arila" size="2">Create XBMC CHlist</font></a></td>'+
	      */
	      '</tr></table>'+HTML_str;
	g_total_group_no=group_active_no;
 
 }

 
}

function callServer_group_Inquery() {
  	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
//    var detail = parent.document.getElementById("detail");
	var content = parent.document.getElementById("content");
  	g_token=find_cookie_value("token");
  	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

 cgi_url = "/server/query_group?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Group Information Loading...<p>';


 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = group_inquery;
 xmlHttp.send(null);

}
function group_inquery_item()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var group_name;
    var i=0;
	var group_active_no=0;
	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
    	 	strlength=response[i+1].length;
   	    	g_groupname_array[group_active_no]=response[i+1].slice(5,strlength);
 // 	    	alert(g_groupname_array[group_active_no]);
 		i=i+4;
		group_active_no++;
	}
	g_total_group_no=group_active_no;
 	call_get_all_user_detail();
 }

 
}

function group_inquery_item_for_add()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var group_name;
    var i=0;
	var group_active_no=0;
	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
    	 	strlength=response[i+1].length;
   	    	g_groupname_array[group_active_no]=response[i+1].slice(5,strlength);
 // 	    	alert(g_groupname_array[group_active_no]);
 		i=i+4;
		group_active_no++;
	}
	g_total_group_no=group_active_no;
 	call_Add_New_User_detail();
 }

 
}

function server_shutdown(){
  var login_status = document.getElementById("login_status");

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
      if (response==1)
    {
	 login_status.innerHTML='<font face="Arial" color="#FF0000" size="4">EZserver Closed</font>';  
    	alert("Shutdown EZserver Sucessfully");
    } else
    {
   	alert("Failed to Shutdown EZserver");
    }
 }
}
function callserver_shutdown()
{
// var login_status = document.getElementById("login_status");
// var ret=login_status.innerHTML.search("Logout");
   var shutdown_status = document.getElementById("content");
var confirm_msg="Shutdown EZserver?";
 var login_area = document.getElementById("login_area");
	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;

	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

      	g_token=find_cookie_value("token");
      	if (g_token!=0)
      	{

		cgi_url = "/server/shutdown?token="+escape(g_token)+"&flag="+Math.random();
		
		if (confirm(confirm_msg))
		{
			shutdown_status.innerHTML='';
			// login_status.innerHTML='<font face="Arial" color="#FF0000" size="4">EZserver Closing...</font>';  
			 xmlHttp.open("GET", cgi_url, true);
			 xmlHttp.onreadystatechange = server_shutdown;
			 xmlHttp.send(null);
		}
	}
 	
}
function restart_ezserver(){
  var restart_status = document.getElementById("content");

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
      if (response==1)
    {
    	alert("Restarted EZserver and re-login Sucessfully");
 	login();
   } else
    {
   	alert("Failed to Restart EZserver");
     }
  //   restart_status.innerHTML='<p align="center"><font face="Arial" size="3"><a style="text-decoration:none" '+"href='javascript:void(0)'"+' onclick=callserver_restart()>Restart</a></font>';  
 }
}
function callserver_restart()
{
  var restart_status = document.getElementById("content");
// var ret=login_status.innerHTML.search("Logout");
 var confirm_msg="Restart EZserver?";
 //var login_area = document.getElementById("login_area");
	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;
      	g_token=find_cookie_value("token");
      	if (g_token!=0)
      	{

		cgi_url = "/server/restart_ezserver?token="+escape(g_token)+"&flag="+Math.random();
		
		if (confirm(confirm_msg))
		{
			// login_status.innerHTML='<font face="Arial" color="#FF0000" size="4">EZserver Closing...</font>';  
			 xmlHttp.open("GET", cgi_url, true);
			 xmlHttp.onreadystatechange = restart_ezserver;
			 xmlHttp.send(null);
			 restart_status.innerHTML='<p align="center"><font face="Arila" color="#FF0000" size="2">Restarting</font>'; 
		}

	}
 	
}
function open_middleware_windows()
{
	var middleware_url='http://'+location.host+'/middleware/index.htm';
	window.open(middleware_url);

}
function get_uptime()
{
   var home_field= parent.document.getElementById("home_field");
    var strlength;
 
   
	if (xmlHttp.readyState == 4) 
	{
		var response = xmlHttp.responseText;
		
		if (response.length>0)
		{
   			home_field.innerHTML="<a href='javascript:void(0)' onclick=show_uptime()>"+'<font face="Arial" size="2">'+response+'</font>'+'<a>';
   		}else
   		{
   			// clearInterval(g_server_timer);
   		}
   			
   		

	}

}
function show_uptime()
{
	var time_delay=5000;

    	cgi_url= "/server/inquery_uptime?token="+escape(g_token)+"&flag="+Math.random();

	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange =get_uptime ;
	xmlHttp.send(null);
	
	//setTimeout("show_uptime()",time_delay);
}
function system_info_inquery()
{
    
	if (xmlHttp.readyState == 4) 
	{
    		var response = xmlHttp.responseText.split("\r\n");
		var str;
		var i=0;
  		var content = parent.document.getElementById("content");
  		var static_serial_number;
  		var serial_number;
  		var content;
  		var ez_button;
  		var main_button;
  		var add_cuet_at;
  		var add_cuet;
  		var free_version_flag=0;
  		
   		if (response[0].search("ezhometech")==0)
  		{
  			 
	  		str='<p align="left" style="margin-top: 35; margin-left: 25"><table border="0" cellpadding="0" cellspacing="10" border>';
	  		str+='<tr><td><p align="left" style="text-indent: 5"><font face="Arial" size="2" color="#ff0000">System Information</td></tr>';
 			add_cuet_at='E'+'Z'+response[0].substring(2,10);
  			add_cuet=response[0].substring(11,19);
	  		while(1)
	  		{
				if (response[i]==0) break;
				if (response[i].search("Serial Number")==0)
				{
					free_version_flag=0;
					static_serial_number="Serial Number: ";
					serial_number=response[i].substring(static_serial_number.length);
					str+='<tr>'+
					'<td>'+
					'<p align="left" style="text-indent: 5"><font face="Arial" size="2">'+'<b>*</b> '+static_serial_number+'</font>'+
					'<font face="Arial" size="1">'+serial_number+'</font>'+
					'</p>'+
					'</td>'+      
					'</tr>';
				}else if (response[i].search("Limitation: Max")==0)
				{	
					
					free_version_flag=1;
					str+='<tr>'+
					'<td>'+
					'<p align="left" style="text-indent: 5"><font face="Arial" color="#FF0000" size="2">'+'<b>* '+response[i]+'</b></font>'+
					'</p>'+
					'</td>'+      
					'</tr>';
				}else 
				{
					str+='<tr>'+
					'<td>'+
					'<p align="left" style="text-indent: 5"><font face="Arial" size="2">'+'<b>*</b> '+response[i]+'</font>'+
					'</p>'+
					'</td>'+      
					'</tr>';
				}
				if (response[i].search("Channel No: ")==0)
				{
					static_channel_number="Channel No: ";
					g_total_ch_no=response[i].substring(static_channel_number.length);
					
				}
				
				i++;
			}
			str+='</table>';
			content.innerHTML=str;	
			ez_button = parent.document.getElementById("ez_button");
  			ez_button.innerHTML='<b><i><font color="#FFFFFF" size="4">'+add_cuet_at+'</font></i></b>';
  			main_button = parent.document.getElementById("main_button");
  			main_button.innerHTML='<p style="text-indent: 5; margin-top: 5; margin-bottom: 5"><b><font face="Arial" color="#FF0000" size="4">'+add_cuet+'</font></b></p>';
		}else
		{
  			bSystem_Inquery_Panel=0;
  			clearInterval(g_System_timer);			
		    	g_token=find_cookie_value("token");
		  	g_user_id=find_cookie_value("userid");
		  	g_password=find_cookie_value("password");
		 	 cgi_url = "/token/destroytoken?token="+escape(g_token)+"&flag="+Math.random();
			 xmlHttp.open("GET", cgi_url, true);
			 xmlHttp.onreadystatechange = login_out_return;
			 xmlHttp.send(null);
		}
		if ((free_version_flag==1)&&(g_show_free_version==0))
		{
			g_show_free_version=1;
			alert("Free Trial is for 5 channels, 2 users and No EPG Channel Recording only.")
		}
			

	}

}
function callServer_System_Inquery_Timer()
{
	var time_delay=5000;

	if (bSystem_Inquery_Panel==1)
	{
	    	cgi_url= "/server/system_info_inquery?token="+escape(g_token)+"&flag="+Math.random();
	
		xmlHttp.open("GET", cgi_url, true);
		xmlHttp.onreadystatechange =system_info_inquery ;
		xmlHttp.send(null);
	}	
	//setTimeout("show_uptime()",time_delay);
}

function callServer_System_Inquery()
{
	bQuery_Channel_Status=0;
	bSystem_Inquery_Panel=1;
	callServer_System_Inquery_Timer();
	
}
function get_reseller()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var username;
    var szpassword;
    var user_title="<p>"+"Reseller List"+"</p>";
    var user_list;
    var i=0;
    var user_no=1;
	var total_user_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
   var content = parent.document.getElementById("content");
 
  	var menustr;

	content.innerHTML="";
	//detail.innerHTML="";
	
	content.innerHTML="";
	 HTML_str= '<table border="0 align="center">'+
	  '<tr>'+
	      '<td width="10%" align="center"><font face="Arial" size="2">No.</font></td>';
	      	HTML_str+='<td width="20%" align="center"><font face="Arial" size="2">Reseller Name(Primary Key)</font></td>';
	      HTML_str+='</tr>'+'<tr><td  colspan="3"><hr size="1" color="#66FFFF"></td></tr>';
	      	
	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
	 	strlength=response[i].length;
   	    	username=response[i].slice(9,strlength);
 		i=i+1;
		HTML_str=HTML_str+
		   '<tr>';
	
 		HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
	      '<td width="20%" align="center">'+
 		' <font face="Arial" font size="2">'+
 		' <input type="text" name="username"'+
 		' id=username'+user_no+' size="36" value="'+
 		username+'"/></font></td>'+	
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Del_Reseller("'+user_no+'")>'+
	      	      ' <font face="Arial"" size="2">Del</font></a></td>'+
		    '</tr>';
		total_user_no++;
		user_no++;
		//alert(HTML_str);
    }
        HTML_str=HTML_str+'</table>';
       //  alert(user_list_info.innerHTML);
   	menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td>'+
 	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_get_reseller()>"+
 	      ' <font face="Arila" size="2">Refresh</font></a>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_Add_New_Reseller()>"+
	      ' <font face="Arila" size="2">Add</font></a>'+

	      '</td></tr></table>';
	 content.innerHTML=menustr+HTML_str+menustr;
	g_reseller_no=total_user_no;
 }

 
}
function call_get_reseller() {
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
   var content = parent.document.getElementById("content");
	

	content.innerHTML="";

  	
  	g_token=find_cookie_value("token");
  	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

 cgi_url = "/server/query_reseller_index?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">User Information Loading...<p>';

 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = get_reseller;
 xmlHttp.send(null);

}

function Cancel_Add_Reseller()
{
	call_get_reseller();

}

function Add_Reseller_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    //	alert("Add Reseller Sucessfully");
    } else if (response==0)
    {
   	alert("Failed to Add Reseller");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    }else if (response==3)
    {
    	alert("The reseller is already in Database");
    }

	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	call_get_reseller();
    }
}

function call_Add_Reseller(user_no)
{

 var username_id="username"+user_no; 
 var username;
 


var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var pos;
	var expired_time_temp;
 	var pos;
	var expired_time_temp;
	var alert_message;


	g_item=document.getElementById(username_id);
	username=g_item.value;
	if (username.length==0)
	{
		alert("Reseller name is empty");
		return;
	}

   	g_token=find_cookie_value("token");

 confirm_msg="Add Reseller: "+username+" Information?";
 cgi_url = "/server/add_reseller?token="+escape(g_token)+"&username="+escape(username)+"&flag="+Math.random();
 //  alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_Reseller_Info;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (Adding...)";
	g_item.style.backgroundColor = "#ff0000";
 }


}

function call_Add_New_Reseller()
{

var HTML_str;
var user_no;
var len;
var paymodel;
var str;
  var content = parent.document.getElementById("content");
	

	g_reseller_no++;

	HTML_str=content.innerHTML;
	//alert(HTML_str);
	//len=HTML_str.length-16;
	len=HTML_str.lastIndexOf("<TABLE");
	
	if (len==-1)
	{
		len=HTML_str.lastIndexOf("<table");
	}
		
		//HTML_str=HTML_str.slice(800,len);
		//alert(HTML_str);
//	alert(len);
	//len+=6;
	HTML_str=HTML_str.slice(0,len);

	user_no=g_reseller_no;
//	alert(HTML_str);
	HTML_str=HTML_str+'<tr><td><table><tr>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">'+user_no+'</font></td>';
			HTML_str+='<td width="20%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="username"'+
	 		' id=username'+user_no+' size="36"/></font></td>';
 			
	
	 		
		      HTML_str+='<td id=add_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_Reseller("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>'+
	      	      
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=Cancel_Add_Reseller()>'+
	      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

		    '</tr></table></td></tr>';
	//alert(HTML_str);

	       content.innerHTML=HTML_str+'</table>';
  //      alert(user_list_info.innerHTML);
   
		
}
function Del_Reseller_Info() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Delete Reseller Sucessfully");
    } else if (response==2)
    {
     	alert("Disk is error(FULL), Please contact administrator");  	
    } else if (response==0)
    {
   	alert("Failed to Delete Reseller");
    }
    	call_get_reseller();
    }
}

//nction call_Del_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Del_Reseller(user_no)
{
 var username_id="username"+user_no; 
 var username;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(username_id);
	username=g_item.value;
	
   	g_token=find_cookie_value("token");

 confirm_msg="Delete Reseller: "+username+" Information?";
// cgi_url = "/server/del_user?token="+escape(g_token)+"&user_no="+escape(user_no)+"&username="+escape(username)+"&flag="+Math.random();
 cgi_url = "/server/del_reseller?token="+escape(g_token)+"&username="+escape(username)+"&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_Reseller_Info;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}
function Disable_Player_Filter_Respponse() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    
    	call_player_filter();
    }
 
}
function Checked_Rejected_Player_Filter_Respponse() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    	call_player_filter();
    }
 
}
function Checked_Accepted_Player_Filter_Respponse() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    	call_player_filter();
    }
 
}

function checked_disable_player_filter()
{
	 confirm_msg="Disable Player Filter ?";
	 if (confirm(confirm_msg))
	 {
		 cgi_url = "/server/disable_player_filter?token="+escape(g_token)+"&flag="+Math.random();	
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Disable_Player_Filter_Respponse;
		 xmlHttp.send(null);
	 }else
	{
		call_player_filter();
	}
	 	
 }
function checked_rejected_player_filter()
{
	 confirm_msg="Change Mode to Rejected Mode?";
	 if (confirm(confirm_msg))
	 {
		 cgi_url = "/server/checked_rejected_player_filter?token="+escape(g_token)+"&flag="+Math.random();	
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Checked_Rejected_Player_Filter_Respponse;
		 xmlHttp.send(null);
	} else
 	{
 		call_player_filter();
 	}
}
function checked_accepted_player_filter()
{
	 confirm_msg="Change Mode to Accepted Mode?";
	 if (confirm(confirm_msg))
	 {
		 cgi_url = "/server/checked_accepted_player_filter?token="+escape(g_token)+"&flag="+Math.random();	
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Checked_Accepted_Player_Filter_Respponse;
		 xmlHttp.send(null);
	} else
 	{
 		call_player_filter();
 	}
}

function get_player_filter()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var playername;
    var szpassword;
    var user_title="<p>"+"Reseller List"+"</p>";
    var user_list;
    var i=0;
    var user_no=1;
	var total_user_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
   var content = parent.document.getElementById("content");
 
  	var menustr;
  	var playerfiltertype;

	content.innerHTML="";
	//detail.innerHTML="";
	
	content.innerHTML="";
	 HTML_str= '<table border="0"  cellpadding="3" align="center">';
	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
		if (i==0)
		{
		 	strlength=response[i].length;
	   	    	playerfiltertype=response[i].slice(17,strlength);
	   	    	//alert(playerfiltertype);
	   	    	if (playerfiltertype==0)
	   	    	{
	   	    		
				 HTML_str+= '<tr><td colspan="3"><font face="Arial" size="2"><input type="radio" value="V1" checked name="R1" onclick="javascript:checked_disable_player_filter()"><b>Disabled Mode</b><input type="radio" name="R1" value="V3" onclick="javascript:checked_rejected_player_filter()"><b>Rejected Mode</b><input type="radio" name="R1" value="V4" onclick="javascript:checked_accepted_player_filter()"><b>Accepted Mode</b></font></td></tr>';
			        HTML_str+='</tr>'+'<tr><td  colspan="3"><hr size="1" color="#66FFFF"></td></tr>';
	   	    	}else if (playerfiltertype==1)
	   	    	{
				 HTML_str+= '<tr><td colspan="3"><font face="Arial" size="2"><input type="radio" value="V1" name="R1" onclick="javascript:checked_disable_player_filter()"><b>Disabled Mode</b><input type="radio" name="R1" value="V3" onclick="javascript:checked_rejected_player_filter()"><b>Rejected Mode</b><input type="radio" name="R1" value="V4" checked onclick="javascript:checked_accepted_player_filter()"><b>Accepted Mode</b></font></td></tr>';
			        HTML_str+='</tr>'+'<tr><td  colspan="3"><hr size="1" color="#66FFFF"></td></tr>';
			      HTML_str+='<tr>'+'<td width="10%" align="center"><font face="Arial" size="2">No.</font></td>';
			      HTML_str+='<td width="20%" align="center"><font face="Arial" size="2">Accepted Player Name</font></td></tr>';
	   	    	}else if (playerfiltertype==2)
	   	    	{
				 HTML_str+= '<tr><td colspan="3"><font face="Arial" size="2"><input type="radio" value="V1" name="R1" onclick="javascript:checked_disable_player_filter()"><b>Disabled Mode</b><input type="radio" name="R1" value="V3" checked onclick="javascript:checked_rejected_player_filter()"><b>Rejected Mode</b><input type="radio" name="R1" value="V4" onclick="javascript:checked_accepted_player_filter()"><b>Accepted Mode</b></font></td></tr>';
			        HTML_str+='</tr>'+'<tr><td  colspan="3"><hr size="1" color="#66FFFF"></td></tr>';
			      HTML_str+='<tr>'+'<td width="10%" align="center"><font face="Arial" size="2">No.</font></td>';
			      HTML_str+='<td width="20%" align="center"><font face="Arial" size="2">Rejected Player Name</font></td></tr>';
	   	    	}  
	   	    	i=i+1;	
		        HTML_str+='</tr>'+'<tr><td  colspan="3"><hr size="1" color="#66FFFF"></td></tr>';
	  		
		}else
		{
		 	strlength=response[i].length;
	   	    	playername=response[i].slice(11,strlength);
	 		i=i+1;
			HTML_str=HTML_str+
			   '<tr>';
		
	 		HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
		      '<td width="20%" align="center">'+
	 		' <font face="Arial" font size="2">'+
	 		' <input type="text" name="playername"'+
	 		' id=playername'+user_no+' size="36" value="'+
	 		playername+'"/></font></td>'+	
			      '<td width="80" align="center">'+
			      "<a href='javascript:void(0)'"+
			      ' onclick=call_Del_Player_Filter("'+user_no+'")>'+
		      	      ' <font face="Arial"" size="2">Del</font></a></td>'+
			    '</tr>';
			total_user_no++;
			user_no++;
			//alert(HTML_str);
		}
    	}
        HTML_str=HTML_str+'</table>';
       //  alert(user_list_info.innerHTML);
       if (playerfiltertype==0)
       {
 		menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td></tr></table>';
      	}else
	{
		menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_player_filter()>"+
	      ' <font face="Arila" size="2">Refresh</font></a>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_Add_New_Player_Filter()>"+
	      ' <font face="Arila" size="2">Add</font></a>'+
	
	      '</td></tr></table>';
      }
	 content.innerHTML=menustr+HTML_str+menustr;
	g_player_filter_no=total_user_no;
 }

 
}
function call_player_filter() {
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
   var content = parent.document.getElementById("content");
	

	content.innerHTML="";

  	
  	g_token=find_cookie_value("token");
  	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

 cgi_url = "/server/query_player_filter?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">Player Filter Loading...<p>';

 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = get_player_filter;
 xmlHttp.send(null);

}
function Cancel_Add_Player_Filter()
{
	call_player_filter();

}

function Add_Player_Filter() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    //	alert("Add Player Filter Sucessfully");
    } else if (response==0)
    {
   	alert("Failed to Add Player Filter");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    }else if (response==3)
    {
    	alert("The Player Filter is already in Database");
    }

	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	call_player_filter();
    }
}

function call_Add_Player_Filter(user_no)
{

 var playername_id="playername"+user_no; 
 var playername;
 


var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var pos;
	var expired_time_temp;
 	var pos;
	var expired_time_temp;
	var alert_message;


	g_item=document.getElementById(playername_id);
	playername=g_item.value;
	if (playername.length==0)
	{
		alert("Player Filter is empty");
		return;
	}

   	g_token=find_cookie_value("token");

 confirm_msg="Add Player Filter: "+playername+" Information?";
 cgi_url = "/server/add_player_filter_item?token="+escape(g_token)+"&playername="+escape(playername)+"&flag="+Math.random();
 //  alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_Player_Filter;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (Adding...)";
	g_item.style.backgroundColor = "#ff0000";
 }


}

function call_Add_New_Player_Filter()
{

var HTML_str;
var user_no;
var len;
var paymodel;
var str;
  var content = parent.document.getElementById("content");
	

	g_player_filter_no++;

	HTML_str=content.innerHTML;
	//alert(HTML_str);
	//len=HTML_str.length-16;
	len=HTML_str.lastIndexOf("<TABLE");
	
	if (len==-1)
	{
		len=HTML_str.lastIndexOf("<table");
	}
		
		//HTML_str=HTML_str.slice(800,len);
		//alert(HTML_str);
//	alert(len);
	//len+=6;
	HTML_str=HTML_str.slice(0,len);

	user_no=g_player_filter_no;
//	alert(HTML_str);
	HTML_str=HTML_str+'<tr><td><table><tr>'+
		      '<td width="10%" align="center"><font face="Arial" size="2">'+user_no+'</font></td>';
			HTML_str+='<td width="20%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="playername"'+
	 		' id=playername'+user_no+' size="36"/></font></td>';
 			
	
	 		
		      HTML_str+='<td id=add_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_Player_Filter("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>'+
	      	      
		      '<td width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=Cancel_Add_Player_Filter()>'+
	      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

		    '</tr></table></td></tr>';
	//alert(HTML_str);

	       content.innerHTML=HTML_str+'</table>';
  //      alert(user_list_info.innerHTML);
   
		
}
function Del_Player_Filter() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Delete Player Filter Sucessfully");
    } else if (response==2)
    {
     	alert("Disk is error(FULL), Please contact administrator");  	
    } else if (response==0)
    {
   	alert("Failed to Delete Player Filter");
    }
    	call_player_filter();
    }
}

//nction call_Del_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Del_Player_Filter(user_no)
{
 var playername_id="playername"+user_no; 
 var playername;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(playername_id);
	playername=g_item.value;
	
   	g_token=find_cookie_value("token");

 confirm_msg="Delete Player Filter: "+playername+" Information?";
 cgi_url = "/server/del_player_filter_item?token="+escape(g_token)+"&playername="+escape(playername)+"&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_Player_Filter;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}
function Disable_Mac_Blocker_Respponse() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    
    	call_mac_blocker();
    }
 
}

function Checked_Accepted_Mac_Blocker_Respponse() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    	call_mac_blocker();
    }
 
}

function checked_disable_mac_blocker()
{
	 confirm_msg="Disable MAC ID Blocker ?";
	 if (confirm(confirm_msg))
	 {
		 cgi_url = "/server/disable_mac_blocker?token="+escape(g_token)+"&flag="+Math.random();	
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Disable_Mac_Blocker_Respponse;
		 xmlHttp.send(null);
	 }else
	{
		call_mac_blocker();
	}
	 	
}

function checked_accepted_mac_blocker()
{
	 confirm_msg="Change Mode to Accepted Mode?";
	 if (confirm(confirm_msg))
	 {
		 cgi_url = "/server/checked_accepted_mac_blocker?token="+escape(g_token)+"&flag="+Math.random();	
		 xmlHttp.open("GET", cgi_url, true);
		 xmlHttp.onreadystatechange = Checked_Accepted_Mac_Blocker_Respponse;
		 xmlHttp.send(null);
	} else
 	{
 		call_mac_blocker();
 	}
}

function get_mac_blocker()
{
 
 if (xmlHttp.readyState == 4) {


    var response = xmlHttp.responseText.split("\r\n");
    var macid;
    var szpassword;
    var user_title="<p>"+"MAC ID List"+"</p>";
    var user_list;
    var i=0;
    var user_no=1;
	var total_user_no=0;
	var HTML_str='';
	var strlength=0;
	var pos=0;
   var content = parent.document.getElementById("content");
 
  	var menustr;
  	var macblockertype;

	content.innerHTML="";
	//detail.innerHTML="";
	
	content.innerHTML="";
	 HTML_str= '<table border="0" width=100% cellpadding="3" align="center">';
	
	while (1)
	{
 	 	if (response[i]==0) break;
//		alert(response[i]);
		if (i==0)
		{
		 	strlength=response[i].length;
	   	    	macblockertype=response[i].slice(15,strlength);
	   	    	//alert(playerfiltertype);
	   	    	if (macblockertype==0)
	   	    	{
	   	    		
				 HTML_str+= '<tr><td colspan="3"><font face="Arial" size="2"><input type="radio" value="V1" checked name="R1" onclick="javascript:checked_disable_mac_blocker()"><b>Disabled Mode</b><input type="radio" name="R1" value="V4" onclick="javascript:checked_accepted_mac_blocker()"><b>Accepted Mode</b></font></td></tr>';
			        HTML_str+='</tr>'+'<tr><td  colspan="3"><hr size="1" color="#66FFFF"></td></tr>';
	   	    	}else if (macblockertype==1)
	   	    	{
				 HTML_str+= '<tr><td colspan="3"><font face="Arial" size="2"><input type="radio" value="V1" name="R1" onclick="javascript:checked_disable_mac_blocker()"><b>Disabled Mode</b><input type="radio" name="R1" value="V4" checked onclick="javascript:checked_accepted_mac_blocker()"><b>Accepted Mode</b></font></td></tr>';
			        HTML_str+='</tr>'+'<tr><td colspan="3"><hr size="1" color="#66FFFF"></td></tr>';
			      HTML_str+='<tr>'+'<td width="10%" align="center"><font face="Arial" size="2">No.</font></td>';
			      HTML_str+='<td width="50%" align="center"><font face="Arial" size="2">Accepted MAC ID (Format 12 bytes: aa:bb:cc:dd:ee:ff--->aabbccddeeff)</font></td></tr>';
	   	    	}  
	   	    	i=i+1;	
		        HTML_str+='</tr>'+'<tr><td  colspan="3"><hr size="1" color="#66FFFF"></td></tr>';
	  		
		}else
		{
		 	strlength=response[i].length;
	   	    	macid=response[i].slice(6,strlength);
	 		i=i+1;
			HTML_str=HTML_str+
			   '<tr>';
		
	 		HTML_str=HTML_str+'<td width="10%" align="center"><font face="Arial"> <font size="2">'+user_no+'</font></td>'+
		      '<td width="50%" align="center">'+
	 		' <font face="Arial" font size="2">'+
	 		' <input type="text" name="macid"'+
	 		' id=macid'+user_no+' size="36" value="'+
	 		macid+'"/></font></td>'+	
			      '<td width="40" align="center">'+
			      "<a href='javascript:void(0)'"+
			      ' onclick=call_Del_Mac_Blocker("'+user_no+'")>'+
		      	      ' <font face="Arial"" size="2">Del</font></a></td>'+
			    '</tr>';
			total_user_no++;
			user_no++;
			//alert(HTML_str);
		}
    	}
        HTML_str=HTML_str+'</table>';
       //  alert(user_list_info.innerHTML);
       if (macblockertype==0)
       {
 		menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td></tr></table>';
      	}else
	{
		menustr='<table width=99%><tr><td width=20%>'+'<font face="Arial"> <font size="2">Total: '+ total_user_no+'</td>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_mac_blocker()>"+
	      ' <font face="Arila" size="2">Refresh</font></a>'+
	      "<td width=80% align=right> <a href='javascript:void(0)' onclick=call_Add_New_Mac_Blocker()>"+
	      ' <font face="Arila" size="2">Add</font></a>'+
	
	      '</td></tr></table>';
      }
	 content.innerHTML=menustr+HTML_str+menustr;
	g_mac_blocker_no=total_user_no;
 }

 
}
function call_mac_blocker() {
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	
   var content = parent.document.getElementById("content");
	

	content.innerHTML="";

  	
  	g_token=find_cookie_value("token");
  	bSystem_Inquery_Panel=0;
	bQuery_Channel_Status=0;

 cgi_url = "/server/query_mac_blocker?token="+escape(g_token)+"&flag="+Math.random();
 content.innerHTML='<p align="center"><font face="Arial" color="#FF0000" size="4">MAC Address Loading...<p>';

 xmlHttp.open("GET", cgi_url, true);
 xmlHttp.onreadystatechange = get_mac_blocker;
 xmlHttp.send(null);

}
function Cancel_Add_Mac_Blocker()
{
	call_mac_blocker();

}

function Add_Mac_Blocker() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    //	alert("Add MAC ID Sucessfully");
    } else if (response==0)
    {
   	alert("Failed to Add MAC ID");
    } else if (response==2)
    {
    	alert("Disk is error(FULL), Please contact administrator");
    }else if (response==3)
    {
    	alert("The MAC ID is already in Database");
    }

	g_item.value=g_temp;
	g_item.style.backgroundColor = "#ffffff";
	//alert(add_id_button.innerHTML);
	call_mac_blocker();
    }
}

function call_Add_Mac_Blocker(user_no)
{

 var macid_id="macid"+user_no; 
 var macid;
 


var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
	var pos;
	var expired_time_temp;
 	var pos;
	var expired_time_temp;
	var alert_message;


	g_item=document.getElementById(macid_id);
	macid=g_item.value;
	if (macid.length==0)
	{
		alert("MAC ID is empty");
		return;
	}else if (macid.length!=12)
	{
		alert("MAC ID Lenght must be 12 bytes");
		return;		
	}
	

   	g_token=find_cookie_value("token");

 confirm_msg="Add MAC ID: "+macid+" ?";
 cgi_url = "/server/add_mac_blocker_item?token="+escape(g_token)+"&macid="+escape(macid)+"&flag="+Math.random();
 //  alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Add_Mac_Blocker;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (Adding...)";
	g_item.style.backgroundColor = "#ff0000";
 }


}

function call_Add_New_Mac_Blocker()
{

var HTML_str;
var user_no;
var len;
var paymodel;
var str;
  var content = parent.document.getElementById("content");
	

	g_mac_blocker_no++;

	HTML_str=content.innerHTML;
	//alert(HTML_str);
	//len=HTML_str.length-16;
	len=HTML_str.lastIndexOf("<TABLE");
	
	if (len==-1)
	{
		len=HTML_str.lastIndexOf("<table");
	}
		
		//HTML_str=HTML_str.slice(800,len);
		//alert(HTML_str);
//	alert(len);
	//len+=6;
	HTML_str=HTML_str.slice(0,len);

	user_no=g_mac_blocker_no;
//	alert(HTML_str);
	HTML_str=HTML_str+'<tr><td><table><tr>'+
		      '<td width="18%" align="center"><font face="Arial" size="2">'+user_no+'</font></td>';
			HTML_str+='<td width="42%" align="center">'+
	 		' <font face="Arial" size="2">'+
	 		' <input type="text" name="macid"'+
	 		' id=macid'+user_no+' size="36"/></font></td>';
 			
	
	 		
		      HTML_str+='<td id=add_id_button width="80" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=call_Add_Mac_Blocker("'+user_no+'")>'+
	      	      ' <font face="Arial" size="2">Add</font></a></td>'+
	      	      
		      '<td width="40" align="center">'+
		      "<a href='javascript:void(0)'"+
		      ' onclick=Cancel_Add_Mac_Blocker()>'+
	      	      ' <font face="Arial" size="2">Cancel</font></a></td>'+

		    '</tr></table></td></tr>';
	//alert(HTML_str);

	       content.innerHTML=HTML_str+'</table>';
  //      alert(user_list_info.innerHTML);
   
		
}
function Del_Mac_Blocker() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response==1)
    {
    	alert("Delete MAC ID Sucessfully");
    } else if (response==2)
    {
     	alert("Disk is error(FULL), Please contact administrator");  	
    } else if (response==0)
    {
   	alert("Failed to Delete MAC ID");
    }
    	call_mac_blocker();
    }
}

//nction call_Del_User(user_no,username,szpassword,expired_time,paymodel,user_point)
function call_Del_Mac_Blocker(user_no)
{
 var macid_id="macid"+user_no; 
 var macid;

var confirm_msg;
 	var cgi_url;
	var cookieStr;
	var firstpos;
	var endpos;
 
 
	g_item=document.getElementById(macid_id);
	macid=g_item.value;
	
   	g_token=find_cookie_value("token");

 confirm_msg="Delete MAC ID: "+macid+" ?";
 cgi_url = "/server/del_mac_blocker_item?token="+escape(g_token)+"&macid="+escape(macid)+"&flag="+Math.random();
  // alert(cgi_url);
 if (confirm(confirm_msg))
 {
	
	 xmlHttp.open("GET", cgi_url, true);
	 xmlHttp.onreadystatechange = Del_Mac_Blocker;
	 xmlHttp.send(null);
	 g_temp=g_item.value;
	 g_item.value=g_item.value+" (del...)";
	g_item.style.backgroundColor = "#ff0000";
 }
 

}
function Export_User_Profile() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response.length>0)  
    {
     	window.location =response; 
    }
  }
}
function call_export_user_profile()
{
	var cgi_url;
	
	
	g_token=find_cookie_value("token");
	cgi_url = "/server/export_user_profile?token="+escape(g_token)+"&flag="+Math.random();
	
	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange = Export_User_Profile;
	xmlHttp.send(null); 

}
function Export_Channel_Definition() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response.length>0)
    
    {
    	window.location =response; 
    }
}
}
function call_export_channel_definition()
{
	var cgi_url;
	
	bQuery_Channel_Status=0;
	g_token=find_cookie_value("token");
	cgi_url = "/server/export_channel_definition?token="+escape(g_token)+"&flag="+Math.random();
	
	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange = Export_Channel_Definition;
	xmlHttp.send(null); 

}
function Export_Movie_Definition() {

  if (xmlHttp.readyState == 4) {
    var response = xmlHttp.responseText;
    if (response.length>0)
    
    {
    	window.location =response; 
    }
}
}
function call_export_movie_definition()
{
	var cgi_url;
	
	
	g_token=find_cookie_value("token");
	cgi_url = "/server/export_movie_definition?token="+escape(g_token)+"&flag="+Math.random();
	
	xmlHttp.open("GET", cgi_url, true);
	xmlHttp.onreadystatechange = Export_Movie_Definition;
	xmlHttp.send(null); 

}